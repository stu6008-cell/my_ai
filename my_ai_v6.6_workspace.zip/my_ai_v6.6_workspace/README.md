# my_ai v6.5 — Web Workspace

v6.5는 v6.4 웹 작업공간을 기반으로 채팅 UX를 강화했다.

## 추가 기능
- SSE 기반 점진적 응답 스트리밍(현재 AI 엔진의 최종 답변을 생성한 뒤 청크로 전달)
- 파일 첨부(최대 15MB, 텍스트 파일은 대화 컨텍스트에 미리보기 포함)
- 채팅 전체 검색
- Markdown 기본 렌더링 및 fenced code block 렌더링
- 코드 블록 복사 버튼
- 기존 멀티 세션/모드/Tailscale 토큰 인증 유지

## 실행
Windows에서 `run_my_ai.pyw` 실행.
원격 접속은 기존 Tailscale/LAN 설정을 사용.
