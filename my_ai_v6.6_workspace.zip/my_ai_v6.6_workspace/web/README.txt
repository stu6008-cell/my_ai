my_ai v6.3 웹 프론트엔드
- index.html: 화면 구조
- style.css: 디자인
- app.js: API 호출/상호작용

서버는 server/my_ai_core.py가 제공하는 API를 사용합니다.
