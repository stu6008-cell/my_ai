# -*- coding: utf-8 -*-
from pathlib import Path
import runpy
BASE = Path(__file__).resolve().parent
runpy.run_path(str(BASE / "my_ai_core.py"), run_name="__main__")
