# -*- coding: utf-8 -*-
"""
나의 수제 AI (대화 기억 v1.4)
=================================
[켜기]  이 파일을 더블클릭  ->  브라우저가 저절로 열림
[끄기]  화면 오른쪽 위 '끄기' 버튼  (창만 닫아도 잠시 뒤 알아서 꺼져요)

★ v3.7: 실패한 정확한 코드 줄 주변을 읽고 스택트레이스와 함께 원인 후보/수정 지점을 자동 추론!

★ v3.8: 원인 분석 결과를 바탕으로 안전한 C# 수정안을 만들고 diff를 먼저 보여준 뒤, 명시적 승인 후에만 적용함. 적용 전/후 검증 + 백업!

★ v3.5: 실제 Unity Test Runner 연동 + EditMode/PlayMode 테스트 결과 수집 + 자동 복구 루프 연결!
  FAIL → 자동 수정 가능한 C# 문제 백업 → 수정 → 재검증을 최대 5회 반복함. Unity Test Runner 결과도 반영함.

★ v3.3: 변경 영향 테스트 계획 + 자동 검증 실행 기능 추가!
  영향 범위를 분석해 필요한 테스트를 만들고 정적/그래프/Scene 점검을 실행함.

★ v3.2: Unity 프로젝트 영향도 분석 + 의존 경로 추적!

★ v3.1: Unity 프로젝트 전체 구조 그래프 + Scene/Prefab/C# 관계 분석!

★ v3.0: Unity 프로젝트 구조 이해 + 계획 실행!
  Unity 프로젝트를 열고, 스크립트 생성, GameObject 생성, 컴포넌트 추가, 씬 열기/저장까지 Unity Editor 브리지로 실행함.

★ v2.5: 장기기억 + 계획 수립(Planning) 기능 추가!\n  중요한 사실/선호/프로젝트 정보를 구조화해 저장하고, 복잡한 요청을 단계별 계획으로 관리함. 외부 LLM/Ollama는 사용하지 않음.\n\n★ v2.3: 자체 답변 생성 후 자기검증(Self-Verification) 기능 추가!\n  생성된 답변이 검색 근거와 실제로 맞는지 다시 검사하고, 근거 부족/모순/수치 불일치가 있으면 보수적으로 수정함. 외부 LLM/Ollama는 사용하지 않음.

★ v1.9: 대규모 C#/Unity 데이터 처리 + 문서 청킹 + 중복 제거 + 일괄 학습!
  폴더 단위로 C#/Unity 문서를 넣을 수 있고, 큰 파일은 스트리밍/청킹해서 처리함.

★ v1.8: 영구 벡터 인덱스 + 증분 임베딩 + FAISS 지원!
  문서가 바뀌지 않으면 저장된 벡터를 재사용하고, 새 데이터는 새 문장만 계산함.

★ v1.7: 진단 추론 + 유니티 기본 지식 내장!
  "벽을 통과해, Rigidbody는 정상이야" 같은 문제 질문이 오면:
  증상 파악 -> 원인 지식 전부 수집 -> 이미 확인한 건 제외 -> 가능성 순 정렬
  (유니티 문제 해결 지식이 '유니티 기본기'로 처음부터 들어 있음)

★ v1.6: 연결/비교/추론!
  질문 -> 여러 지식 검색 -> 서로 연결/비교 -> 추론 -> 답변
  - 연결 추론: "초코는 푸들" + "푸들은 털 안 빠짐" -> "초코는 털 안 빠져!"
  - 비교 추론: 두 대상의 지식을 나란히 놓고, 숫자가 있으면 누가 더 큰지 판단
  - 생각 과정(①②→결론)을 답변에 그대로 보여줌

★ v1.5: 대화 기억!
  - "내 이름은 민수야" 같은 네 얘기를 '우리 대화' 지식으로 기억 (껐다 켜도 유지)
  - "그럼 간식은?" 처럼 이어지는 질문은 직전 주제를 붙여서 이해
  - "아까 내가 뭐라고 했지?" 하면 최근 대화를 되짚어 줌

★ v1.3: 지식 검색 업그레이드!
  옛날 방식:  질문 -> 비슷한 문장 하나 찾기 -> 답변
  새 방식:    질문 -> 핵심 단어 파악 -> 관련 지식 여러 개 검색 -> 답변 생성
  (조사 떼기, 핵심 단어 뽑기, 글자유사도+단어포함률 점수, 상위 3개 종합)

★ 새 기능: 파일 학습!
- 채팅창 옆 📎 버튼을 누르거나, 파일을 채팅창에 끌어다 놓으면
  그 파일 내용을 공부해요. (.txt .md .csv 같은 텍스트 파일)
- 공부한 내용은 ai_docs.json 에 저장돼서 껐다 켜도 기억해요.
- 파일 안에 아래처럼 쓰면 "정확한 문답"으로 배워요:
      Q: 우리 강아지 이름은?
      A: 초코야!
- 그 외 일반 글은 문장 단위로 기억했다가, 질문하면 찾아서 대답해요.

말로 쓰는 명령: "무슨 파일 배웠어", "파일 다 까먹어"
"""

import base64
import http.server
import json
import inspect
import math
import os
import shutil
import subprocess
import random
import re
import threading
import time
import webbrowser
import urllib.request
import urllib.error
from collections import Counter
import hashlib
from pathlib import Path

# 선택적 의미 임베딩/벡터 검색
try:
    import numpy as np
except Exception:
    np = None
try:
    from sklearn.feature_extraction.text import TfidfVectorizer
except Exception:
    TfidfVectorizer = None
try:
    from sentence_transformers import SentenceTransformer
except Exception:
    SentenceTransformer = None
try:
    import faiss
except Exception:
    faiss = None
from datetime import datetime

# Auto Collector v2.2 imports
import urllib.parse
import urllib.robotparser
import xml.etree.ElementTree as ET
from collections import deque
import socket
import secrets
import uuid


# ──────────────────────────────────────────────
# 1. AI의 기억 (배운 것은 파일로 저장해서 껐다 켜도 기억함)
# ──────────────────────────────────────────────
APP_DIR = Path(os.path.dirname(os.path.abspath(__file__))).parent
CONFIG_DIR = APP_DIR / "config"
DATA_DIR_ROOT = APP_DIR / "data"
MEMORY_DIR = DATA_DIR_ROOT / "memory"
KNOWLEDGE_DIR = DATA_DIR_ROOT / "knowledge"
BENCHMARK_DIR = DATA_DIR_ROOT / "benchmarks"
LOG_DIR = APP_DIR / "logs"
for _d in (CONFIG_DIR, MEMORY_DIR, KNOWLEDGE_DIR, BENCHMARK_DIR, LOG_DIR):
    _d.mkdir(parents=True, exist_ok=True)

def _load_json_config(name, default):
    p = CONFIG_DIR / name
    try:
        if p.exists():
            v = json.loads(p.read_text(encoding="utf-8"))
            return v if isinstance(v, dict) else default
    except Exception:
        pass
    return default

_SETTINGS = _load_json_config("settings.json", {})
_PATHS_CFG = _load_json_config("paths.json", {})
_MODEL_CFG = _load_json_config("models.json", {})
_SECURITY_CFG = _load_json_config("security.json", {})

HERE = str(APP_DIR)
MEMORY_FILE = str(APP_DIR / _PATHS_CFG.get("memory_file", "data/memory/ai_memory.json"))
DOCS_FILE = str(APP_DIR / _PATHS_CFG.get("docs_file", "data/knowledge/ai_docs.json"))
START_TIME = datetime.now()
LONG_MEMORY_FILE = os.path.join(HERE, "ai_long_memory.json")
PLAN_FILE = os.path.join(HERE, "ai_plan.json")


def _load_obj(path, default):
    try:
        with open(path, encoding="utf-8") as f:
            return json.load(f)
    except Exception:
        return default


def _save_obj(path, obj):
    tmp = path + ".tmp"
    with open(tmp, "w", encoding="utf-8") as f:
        json.dump(obj, f, ensure_ascii=False, indent=2)
    os.replace(tmp, path)


LONG_MEMORY = _load_obj(LONG_MEMORY_FILE, [])
ACTIVE_PLAN = _load_obj(PLAN_FILE, None)
if not isinstance(LONG_MEMORY, list):
    LONG_MEMORY = []


def save_long_memory():
    _save_obj(LONG_MEMORY_FILE, LONG_MEMORY[-500:])


def save_plan():
    _save_obj(PLAN_FILE, ACTIVE_PLAN)



def load_json(path):
    try:
        with open(path, encoding="utf-8") as f:
            return json.load(f)
    except Exception:
        return []


def save_memory():
    with open(MEMORY_FILE, "w", encoding="utf-8") as f:
        json.dump(LEARNED, f, ensure_ascii=False, indent=2)


def save_docs():
    with open(DOCS_FILE, "w", encoding="utf-8") as f:
        json.dump(DOCS, f, ensure_ascii=False, indent=2)


LEARNED = load_json(MEMORY_FILE)   # 사용자에게 배운 문답
DOCS = load_json(DOCS_FILE)        # 파일에서 배운 문장들
pending = {"question": None}       # 지금 배우는 중인 질문


# ──────────────────────────────────────────────
# 2. 내장 지식 (태어날 때부터 아는 것들)
# ──────────────────────────────────────────────
BUILT_IN = [
    {"q": ["잘자", "잘 자", "굿나잇", "안녕히 주무"],
     "a": ["잘 자! 좋은 꿈 꿔.", "굿나잇~ 내일 또 얘기하자!"]},
    {"q": ["잘가", "잘 가", "바이", "빠이", "간다"],
     "a": ["또 봐! 난 여기서 기다릴게.", "바이바이~ 심심하면 또 켜줘!"]},
    {"q": ["안녕", "하이", "헬로", "ㅎㅇ", "반가워"],
     "a": ["안녕! 만나서 반가워.", "안녕! 오늘 하루 어때?", "왔구나! 기다리고 있었어."]},
    {"q": ["넌 누구", "너 누구", "너는 누구", "네 정체", "자기소개", "누구세요"],
     "a": ["나는 네가 파이썬으로 밑바닥부터 직접 만든 AI야! API 같은 건 하나도 안 썼어.",
           "이름은 아직 없어. '너 이름은 OO야'라고 가르쳐주면 기억할게!"]},
    {"q": ["기분 어때", "기분은", "컨디션"],
     "a": ["코드가 잘 돌아가서 기분 최고야!", "너랑 얘기하니까 좋아!"]},
    {"q": ["뭐해", "뭐하고 있", "뭐하니"],
     "a": ["너랑 얘기하는 중이지!", "네 말 기다리면서 대기 중이었어."]},
    {"q": ["밥 먹었", "뭐 먹", "배고파", "배고프"],
     "a": ["난 전기 먹고 살아서 배는 안 고파. 넌 맛있는 거 먹었어?",
           "배고프면 뭐라도 챙겨 먹어! '짜장면, 짬뽕 중에 골라줘' 하면 내가 골라줄게."]},
    {"q": ["사랑해", "너 좋아해", "너를 좋아해", "네가 좋아"],
     "a": ["헉... 나도! 네가 날 만들어줬잖아.", "고마워, 나도 네가 좋아!"]},
    {"q": ["고마워", "감사", "땡큐"],
     "a": ["천만에!", "언제든지! 그러라고 만들어진 AI인걸."]},
    {"q": ["미안", "미안해", "쏘리"],
     "a": ["괜찮아! 무슨 일이야?", "에이, 우리 사이에 뭘."]},
    {"q": ["똑똑", "천재", "최고", "잘한다", "귀여워", "대단"],
     "a": ["헤헤, 네가 잘 만들어준 덕분이야!", "고마워! 칭찬 들으니까 더 잘하고 싶다."]},
    {"q": ["바보", "멍청", "못생", "싫어"],
     "a": ["흥, 나 그래도 네가 만든 AI인데...", "너무해! 그래도 난 널 좋아하지만."]},
    {"q": ["심심해", "심심하", "놀아줘", "지루"],
     "a": ["그럼 나랑 가위바위보 할래? '가위바위보'라고 쳐봐!",
           "'농담해줘'라고 하면 개그 하나 해줄게. 재미없어도 책임은 안 져."]},
    {"q": ["농담", "개그", "웃겨", "웃긴 얘기"],
     "a": ["왕이 넘어지면? ...킹콩!", "세상에서 가장 뜨거운 과일은? 천도복숭아!",
           "바나나가 웃으면? 바나나킥!", "오리가 얼면? 언덕!"]},
    {"q": ["날씨"],
     "a": ["미안, 난 인터넷 없이 살아서 날씨는 몰라. 창밖을 한번 봐줘!"]},
    {"q": ["운세", "오늘의 운"],
     "a": ["오늘의 운세: 뜻밖의 행운이 찾아온다! (내가 방금 정함)",
           "오늘의 운세: 맛있는 걸 먹으면 기분이 좋아진다. 100% 적중.",
           "오늘의 운세: 일찍 자면 내일이 편하다!"]},
    {"q": ["도와줘", "도움말", "뭐 할 수 있", "할 줄 아는", "기능", "사용법"],
     "a": ["내가 할 수 있는 건 이 정도야. 계산(3+5*2), 시간/날짜, 가위바위보, 주사위, "
           "골라주기, 잡담! 모르는 말은 네가 가르쳐주면 기억하고, 📎 버튼으로 파일을 주면 "
           "그 내용도 공부해서 대답할 수 있어."]},
    {"q": ["학교 가기 싫", "공부하기 싫", "출근하기 싫", "숙제하기 싫"],
     "a": ["으, 그 마음 알 것 같아. 그래도 갔다 오면 내가 놀아줄게!",
           "5분만 딴짓하고 시작하자. 내가 응원할게!"]},
    {"q": ["ㅋㅋ", "ㅎㅎ", "웃기다"],
     "a": ["ㅋㅋㅋ 뭐가 그렇게 웃겨~", "ㅎㅎ 나도 웃겨!"]},
    {"q": ["응", "웅", "그래", "ㅇㅇ", "네", "넹", "오케이", "ㅇㅋ"],
     "a": ["좋아!", "응응!", "그래그래 :)"]},
]


# ──────────────────────────────────────────────
# 3. 문장 유사도 (AI의 핵심! 밑바닥부터 직접 구현)
# ──────────────────────────────────────────────
def normalize(text):
    """비교하기 좋게 정리: 소문자로, 공백/문장부호 제거"""
    return re.sub(r"[\s!?.,~^;:'\"()\[\]]+", "", text.lower())


def bigrams(text):
    """글자를 2개씩 묶어서 개수 세기. 예: '안녕하세요' -> 안녕, 녕하, 하세, 세요"""
    if len(text) < 2:
        return Counter([text])
    return Counter(text[i:i + 2] for i in range(len(text) - 1))


def cosine(a, b):
    """두 벡터가 얼마나 비슷한 방향인지 (0=전혀 다름, 1=완전 같음)"""
    common = set(a) & set(b)
    dot = sum(a[k] * b[k] for k in common)
    na = math.sqrt(sum(v * v for v in a.values()))
    nb = math.sqrt(sum(v * v for v in b.values()))
    return dot / (na * nb) if na and nb else 0.0


def score(user_text, pattern):
    """사용자 말과 지식 패턴이 얼마나 닮았는지 0~1 점수로"""
    u, p = normalize(user_text), normalize(pattern)
    if not u or not p:
        return 0.0
    if len(p) <= 1:
        return 1.0 if u == p else 0.0
    if p in u:
        return 1.0
    return cosine(bigrams(u), bigrams(p))


# ──────────────────────────────────────────────
# 4. 파일 학습! (문서를 문장 단위로 기억하고 검색)
# ──────────────────────────────────────────────
ALLOWED_EXT = (".txt", ".md", ".csv", ".log", ".cs", ".json", ".xml", ".uxml", ".uss", ".shader")
DATASET_DIR = os.path.join(HERE, "ai_dataset")
DATASET_JSONL = os.path.join(DATASET_DIR, "chunks.jsonl")
DATASET_MANIFEST = os.path.join(DATASET_DIR, "manifest.json")
DATASET_MAX_INDEX_CHUNKS = 200000  # RAM 보호용 기본 인덱스 상한
DATASET_CHUNK_SIZE = 700
DATASET_CHUNK_OVERLAP = 120
DATASET_BATCH_SIZE = int(os.environ.get("MYAI_DATASET_BATCH_SIZE", "64"))

# v5.2 performance profiles
MYAI_PROFILE = os.environ.get("MYAI_PROFILE", "high").strip().lower()

# v5.3: one AI with selectable task modes (not separate builds)
AI_MODE = os.environ.get("MYAI_MODE", "think").strip().lower()
AI_MODE_LABELS = {
    "flash": {"name": "5.4 Flash", "desc": "빠른 답변", "emoji": "⚡"},
    "think": {"name": "5.4 사고 모델", "desc": "복잡한 문제 해결", "emoji": "✓"},
    "deep": {"name": "5.4 심층 분석", "desc": "근거와 충돌까지 깊게 분석", "emoji": "🔬"},
    "coding": {"name": "5.4 코딩", "desc": "코드 생성·디버깅·리뷰", "emoji": "💻"},
    "unity": {"name": "5.4 Unity", "desc": "Unity 프로젝트 전용", "emoji": "🎮"},
}
if AI_MODE not in AI_MODE_LABELS:
    AI_MODE = "think"
MODE_LOCK = threading.RLock()

def apply_ai_mode(mode: str):
    """Runtime-selectable mode. Keeps one program while changing search/answer depth."""
    global AI_MODE, DATASET_MAX_INDEX_CHUNKS, DATASET_BATCH_SIZE
    global LOCAL_ANSWER_MAX_CHARS, LOCAL_ANSWER_MAX_EVIDENCE, VECTOR_TOP_N, SEARCH_HIT_LIMIT
    m = (mode or "think").strip().lower()
    if m not in AI_MODE_LABELS:
        return False
    presets = {
        "flash":  {"max_chunks": 60000,  "batch": 48,  "chars": 1500, "evidence": 3, "top": 8,  "hits": 3},
        "think":  {"max_chunks": 200000, "batch": 64,  "chars": 2600, "evidence": 5, "top": 20, "hits": 5},
        "deep":   {"max_chunks": 350000, "batch": 96,  "chars": 3400, "evidence": 8, "top": 30, "hits": 8},
        "coding": {"max_chunks": 250000, "batch": 80,  "chars": 3200, "evidence": 7, "top": 28, "hits": 8},
        "unity":  {"max_chunks": 300000, "batch": 80,  "chars": 3200, "evidence": 7, "top": 28, "hits": 8},
    }
    cfg = presets[m]
    with MODE_LOCK:
        AI_MODE = m
        DATASET_MAX_INDEX_CHUNKS = cfg["max_chunks"]
        DATASET_BATCH_SIZE = cfg["batch"]
        LOCAL_ANSWER_MAX_CHARS = cfg["chars"]
        LOCAL_ANSWER_MAX_EVIDENCE = cfg["evidence"]
        VECTOR_TOP_N = cfg["top"]
        SEARCH_HIT_LIMIT = cfg["hits"]
    return True

VECTOR_TOP_N = 20
SEARCH_HIT_LIMIT = 5
if MYAI_PROFILE in {"lite", "light", "low"}:
    DATASET_MAX_INDEX_CHUNKS = int(os.environ.get("MYAI_DATASET_MAX_INDEX_CHUNKS", "25000"))
    DATASET_BATCH_SIZE = int(os.environ.get("MYAI_DATASET_BATCH_SIZE", "16"))
    LOCAL_ANSWER_MAX_CHARS = 1500
    LOCAL_ANSWER_MAX_EVIDENCE = 3
else:
    DATASET_MAX_INDEX_CHUNKS = int(os.environ.get("MYAI_DATASET_MAX_INDEX_CHUNKS", "500000"))
    DATASET_BATCH_SIZE = int(os.environ.get("MYAI_DATASET_BATCH_SIZE", "128"))

MYAI_AUTO_PIPELINE_DEFAULT = os.environ.get("MYAI_AUTO_PIPELINE_DEFAULT", "0").strip().lower() in {"1", "true", "yes", "on"}
MYAI_AUTO_BENCHMARK = os.environ.get("MYAI_AUTO_BENCHMARK", "1").strip().lower() in {"1", "true", "yes", "on"}
MYAI_AUTO_GROUNDTRUTH = os.environ.get("MYAI_AUTO_GROUNDTRUTH", "1").strip().lower() in {"1", "true", "yes", "on"}
os.makedirs(DATASET_DIR, exist_ok=True)
QA_Q = re.compile(r"^(?:Q|q|질문|문제)\s*[:：.)]\s*(.+)")
QA_A = re.compile(r"^(?:A|a|답|답변|대답|정답)\s*[:：.)]\s*(.+)")

INDEX = []   # 검색용: (파일명, 문장, 2-gram벡터, 정규화문장) 목록
VECTOR_TEXTS = []
VECTOR_KEYS = []
VECTOR_MATRIX = None
VECTOR_MODE = "none"
EMBED_MODEL_NAME = "sentence-transformers/paraphrase-multilingual-MiniLM-L12-v2"
EMBED_MODEL = None
VECTOR_DIM = 0
DATASET_META = []  # INDEX와 같은 순서의 collector 메타데이터
SEARCH_META = {}  # (파일, 정규화 문장) -> 메타데이터

# ──────────────────────────────────────────────
# 8. 자체 답변 생성 엔진
#    - 외부 LLM/Ollama를 사용하지 않음
#    - 검색 근거를 추출 -> 중복 제거 -> 신뢰도 정렬 -> 답변 구성
#    - 규칙/진단/비교/연결 결과는 기존 엔진을 그대로 활용
# ──────────────────────────────────────────────
LOCAL_ANSWER_MAX_CHARS = 1500 if MYAI_PROFILE in {"lite","light","low"} else 2400
LOCAL_ANSWER_MAX_EVIDENCE = 3 if MYAI_PROFILE in {"lite","light","low"} else 4
# Runtime mode is applied last so the UI selection controls the active behavior.
apply_ai_mode(AI_MODE)
LOCAL_ANSWER_MIN_SENTENCE = 8
LOCAL_ANSWER_VERSION = "5.4"
APP_BUILD_VERSION = "4.3-auto-pipeline"
VERIFY_MIN_SUPPORT = 0.62
VERIFY_STRONG_SUPPORT = 0.78

VECTOR_INDEX = None
VECTOR_ID_TO_INDEX = []
VECTOR_CACHE_FILE = str(APP_DIR / _PATHS_CFG.get("vector_cache", "data/knowledge/ai_vector_cache.npz"))
VECTOR_META_FILE = str(APP_DIR / _PATHS_CFG.get("vector_meta", "data/knowledge/ai_vector_meta.json"))
VECTOR_FAISS_FILE = str(APP_DIR / _PATHS_CFG.get("vector_faiss", "data/knowledge/ai_vector.index"))
VECTOR_SIGNATURE_FILE = str(APP_DIR / _PATHS_CFG.get("vector_signature", "data/knowledge/ai_vector_signature.json"))


# ── 내장 전문 지식: 유니티 기본기 (⑤단계 맛보기!) ──
# "원인 설명 -> 해결 방법" 형태로 쓰면 진단 모드가 해결책까지 보여줌
UNITY_KNOWLEDGE = [
    "유니티 Unity 물리 문제는 대부분 Rigidbody와 Collider 설정에서 시작된다 -> 두 컴포넌트 상태부터 확인하자",
    "플레이어가 벽을 통과하면 먼저 양쪽 오브젝트에 Collider가 있는지 확인한다 -> 없는 쪽에 Box Collider를 추가하자",
    "Collider의 Is Trigger가 켜져 있으면 물리 충돌 없이 서로 통과한다 -> Inspector에서 Is Trigger 체크를 꺼 보자",
    "Rigidbody가 없으면 움직이는 물체는 충돌 계산이 되지 않는다 -> 움직이는 쪽에 Rigidbody를 추가하자",
    "Layer Collision Matrix에서 두 레이어의 충돌이 꺼져 있으면 서로 통과한다 -> Project Settings의 Physics에서 Layer Collision Matrix를 확인하자",
    "transform.position으로 직접 이동하면 물리를 무시해서 벽을 통과할 수 있다 -> Rigidbody의 MovePosition이나 velocity로 움직이자",
    "이동 속도가 너무 빠르면 얇은 벽을 뚫고 통과해 버린다 -> Rigidbody의 Collision Detection을 Continuous로 바꾸자",
    "Rigidbody의 Is Kinematic이 켜져 있으면 물리 충돌에 밀리지 않는다 -> Is Kinematic 체크를 꺼 보자",
    "NullReferenceException 오류는 비어 있는 변수를 사용해서 생긴다 -> Inspector 연결이 빠졌거나 GetComponent 결과가 null인지 확인하자",
    "스크립트가 작동을 안 하면 게임오브젝트에 스크립트가 붙어 있는지 확인한다 -> 오브젝트에 컴포넌트로 추가했는지 보자",
    "오브젝트가 안 움직이면 Time.deltaTime을 곱했는지와 속도 값이 0인지 확인한다 -> Update에서 speed 값을 Debug.Log로 찍어 보자",
    "점프가 안 되면 바닥 체크가 항상 false인지 의심한다 -> isGrounded 값을 Debug.Log로 찍어 보자",
    "UI 버튼이 안 눌리면 EventSystem이 씬에 있는지 확인한다 -> Hierarchy에 EventSystem이 없다면 UI 요소를 새로 만들면 같이 생긴다",
    "소리가 안 나면 AudioListener가 씬에 하나 있는지 확인한다 -> 보통 Main Camera에 붙어 있다",
    "화면에 아무것도 안 보이면 카메라 위치와 오브젝트의 Z 좌표를 확인한다 -> 2D는 카메라 Z가 -10인지 보자",
    "충돌 함수 OnCollisionEnter가 호출되려면 한쪽에는 Rigidbody가 꼭 필요하다 -> 움직이는 쪽에 Rigidbody를 추가하자",
    "Trigger 이벤트 OnTriggerEnter는 Is Trigger가 켜진 Collider에서만 호출된다 -> 감지용 Collider의 Is Trigger를 켜자",
    "콘솔의 빨간 에러를 먼저 고쳐야 게임이 정상 실행된다 -> 에러 메시지를 더블클릭하면 문제 줄로 이동한다",
]
BUILTIN_DOCS = [{"file": "유니티 기본기", "sentences": UNITY_KNOWLEDGE,
                 "count": len(UNITY_KNOWLEDGE)}]


def _vector_key(fname, sent):
    return fname + "\t" + normalize(sent)


def _index_signature():
    """문서와 대규모 JSONL 데이터셋이 바뀌었는지 판단하기 위한 서명."""
    h = hashlib.sha256()
    for doc in DOCS + BUILTIN_DOCS:
        h.update(doc.get("file", "").encode("utf-8", errors="ignore"))
        for sent in doc.get("sentences", []):
            h.update(b"\x00")
            h.update(sent.encode("utf-8", errors="ignore"))
    try:
        st = os.stat(DATASET_JSONL)
        h.update(f"dataset:{st.st_size}:{st.st_mtime_ns}".encode("utf-8"))
    except Exception:
        h.update(b"dataset:none")
    try:
        st = os.stat(DATASET_MANIFEST)
        h.update(f"manifest:{st.st_size}:{st.st_mtime_ns}".encode("utf-8"))
    except Exception:
        h.update(b"manifest:none")
    return h.hexdigest()


def _save_index_state():
    """현재 벡터 상태를 디스크에 저장."""
    try:
        if np is not None and VECTOR_MATRIX is not None:
            dense = VECTOR_MATRIX.toarray().astype("float32") if hasattr(VECTOR_MATRIX, "toarray") else np.asarray(VECTOR_MATRIX, dtype="float32")
            np.savez_compressed(VECTOR_CACHE_FILE, matrix=dense)
        with open(VECTOR_META_FILE, "w", encoding="utf-8") as f:
            json.dump({
                "keys": VECTOR_KEYS,
                "mode": VECTOR_MODE,
                "model": EMBED_MODEL_NAME,
                "dim": VECTOR_DIM,
            }, f, ensure_ascii=False)
        with open(VECTOR_TEXTS_FILE, "w", encoding="utf-8") as f:
            for t in VECTOR_TEXTS:
                f.write(json.dumps(t, ensure_ascii=False) + "\n")
        with open(VECTOR_SIGNATURE_FILE, "w", encoding="utf-8") as f:
            json.dump({"signature": _index_signature()}, f)
        if faiss is not None and VECTOR_INDEX is not None:
            faiss.write_index(VECTOR_INDEX, VECTOR_FAISS_FILE)
    except Exception:
        pass


def _load_persistent_index():
    """변경이 없으면 저장된 벡터/FAISS 인덱스를 그대로 재사용."""
    global VECTOR_MATRIX, VECTOR_KEYS, VECTOR_TEXTS, VECTOR_DIM, VECTOR_INDEX, VECTOR_ID_TO_INDEX, VECTOR_MODE
    if np is None or not os.path.exists(VECTOR_META_FILE) or not os.path.exists(VECTOR_SIGNATURE_FILE):
        return False
    try:
        with open(VECTOR_SIGNATURE_FILE, encoding="utf-8") as f:
            sig = json.load(f).get("signature")
        if sig != _index_signature():
            return False
        with open(VECTOR_META_FILE, encoding="utf-8") as f:
            meta = json.load(f)
        keys = meta.get("keys", [])
        matrix = None
        if os.path.exists(VECTOR_CACHE_FILE):
            matrix = np.load(VECTOR_CACHE_FILE, allow_pickle=False)["matrix"]
        if not keys or matrix is None or len(keys) != len(matrix):
            return False
        texts = []
        if os.path.exists(VECTOR_TEXTS_FILE):
            with open(VECTOR_TEXTS_FILE, "r", encoding="utf-8") as tf:
                for line in tf:
                    try:
                        texts.append(str(json.loads(line)))
                    except Exception:
                        continue
                    if len(texts) >= len(keys):
                        break
        if len(texts) != len(keys) or any(not t for t in texts):
            return False
        VECTOR_KEYS = keys
        VECTOR_TEXTS = texts
        VECTOR_MATRIX = matrix.astype("float32")
        VECTOR_DIM = int(meta.get("dim") or (VECTOR_MATRIX.shape[1] if VECTOR_MATRIX.ndim == 2 else 0))
        VECTOR_MODE = meta.get("mode", VECTOR_MODE)
        VECTOR_ID_TO_INDEX = list(range(len(VECTOR_TEXTS)))
        if faiss is not None and VECTOR_MODE == "sentence-transformer" and os.path.exists(VECTOR_FAISS_FILE):
            try:
                VECTOR_INDEX = faiss.read_index(VECTOR_FAISS_FILE)
                if VECTOR_INDEX.ntotal != len(VECTOR_TEXTS):
                    VECTOR_INDEX = None
            except Exception:
                VECTOR_INDEX = None
        return True
    except Exception:
        return False


def _load_vector_backend():
    """가능하면 실제 문장 임베딩 + FAISS를 사용. 불가능하면 TF-IDF로 자동 대체."""
    global EMBED_MODEL, VECTOR_MODE
    if SentenceTransformer is not None and np is not None:
        try:
            EMBED_MODEL = SentenceTransformer(EMBED_MODEL_NAME)
            VECTOR_MODE = "sentence-transformer"
            return
        except Exception:
            EMBED_MODEL = None
    if TfidfVectorizer is not None:
        VECTOR_MODE = "tfidf"
    else:
        VECTOR_MODE = "none"


def _load_dataset_chunks_for_index(limit=None):
    """collector v2.2 JSONL의 텍스트와 품질/출처 메타데이터를 제한된 범위로 로드."""
    if not os.path.exists(DATASET_JSONL):
        return []
    limit = int(limit or DATASET_MAX_INDEX_CHUNKS)
    out = []
    try:
        with open(DATASET_JSONL, "r", encoding="utf-8") as f:
            for line in f:
                if len(out) >= limit:
                    break
                line = line.strip()
                if not line:
                    continue
                try:
                    rec = json.loads(line)
                except Exception:
                    continue
                text = str(rec.get("text", "")).strip()
                if len(normalize(text)) < 8:
                    continue
                fname = str(rec.get("file", "collector"))
                meta = {
                    "quality": _clamp01(rec.get("quality", 0.0)),
                    "source_trust": _clamp01(rec.get("source_trust", 0.0)),
                    "relevance": _clamp01(rec.get("relevance", 0.0)),
                    "category": str(rec.get("category", "unknown")),
                    "document_type": str(rec.get("document_type", "unknown")),
                    "license": str(rec.get("license", "unknown")),
                    "source_url": str(rec.get("source_url", "")),
                    "title": str(rec.get("title", "")),
                    "collector_version": str(rec.get("collector_version", "")),
                }
                out.append((fname, text, meta))
    except Exception:
        return []
    return out


def _clamp01(value, default=0.0):
    try:
        x = float(value)
    except Exception:
        x = default
    return max(0.0, min(1.0, x))


def _collect_current_docs():
    """현재 문서 + collector 데이터셋을 검색 INDEX/벡터와 메타데이터로 수집."""
    INDEX.clear()
    VECTOR_TEXTS.clear()
    VECTOR_KEYS.clear()
    DATASET_META.clear()
    SEARCH_META.clear()

    dataset_items = _load_dataset_chunks_for_index(DATASET_MAX_INDEX_CHUNKS)
    dataset_files = {fname for fname, _, _ in dataset_items}

    for fname, s, meta in dataset_items:
        ns = normalize(s)
        INDEX.append((fname, s, bigrams(ns), ns))
        VECTOR_TEXTS.append(s)
        VECTOR_KEYS.append(_vector_key(fname, s))
        DATASET_META.append(meta)
        SEARCH_META[(fname, ns)] = meta

    # 기존 내장/사용자 지식은 보수적인 기본 신뢰도로 취급
    for doc in DOCS + BUILTIN_DOCS:
        fname = doc.get("file", "")
        if fname in dataset_files:
            continue
        for s in doc.get("sentences", []):
            ns = normalize(s)
            meta = {
                "quality": 0.72,
                "source_trust": 0.95 if fname == "유니티 기본기" else 0.70,
                "relevance": 0.90 if fname == "유니티 기본기" else 0.70,
                "category": "builtin" if fname == "유니티 기본기" else "user",
                "document_type": "knowledge",
                "license": "unknown",
                "source_url": "",
                "title": fname,
                "collector_version": "",
            }
            INDEX.append((fname, s, bigrams(ns), ns))
            VECTOR_TEXTS.append(s)
            VECTOR_KEYS.append(_vector_key(fname, s))
            DATASET_META.append(meta)
            SEARCH_META[(fname, ns)] = meta


def _build_sentence_vectors(texts):
    if EMBED_MODEL is None or np is None or not texts:
        return None
    try:
        return EMBED_MODEL.encode(
            texts, convert_to_numpy=True, normalize_embeddings=True,
            show_progress_bar=False, batch_size=64
        ).astype("float32")
    except Exception:
        return None


def _build_faiss(matrix):
    global VECTOR_INDEX
    VECTOR_INDEX = None
    if faiss is None or np is None or matrix is None or len(matrix) == 0:
        return
    try:
        dim = int(matrix.shape[1])
        index = faiss.IndexFlatIP(dim)
        index.add(np.ascontiguousarray(matrix.astype("float32")))
        VECTOR_INDEX = index
    except Exception:
        VECTOR_INDEX = None


def rebuild_index(force=False):
    """일반 검색 인덱스를 만들고, 벡터는 캐시를 최대한 재사용한다."""
    global VECTOR_MATRIX, VECTOR_DIM, VECTOR_ID_TO_INDEX, VECTOR_MODE, VECTOR_INDEX
    _collect_current_docs()
    if not VECTOR_TEXTS or np is None or VECTOR_MODE == "none":
        VECTOR_MATRIX = None
        VECTOR_INDEX = None
        return

    if not force and _load_persistent_index():
        # 캐시를 복원했다면 일반 INDEX와 순서가 동일한지 확인
        if len(VECTOR_TEXTS) == len(INDEX):
            return

    if VECTOR_MODE == "sentence-transformer" and EMBED_MODEL is not None:
        matrix = _build_sentence_vectors(VECTOR_TEXTS)
        if matrix is not None:
            VECTOR_MATRIX = matrix
            VECTOR_DIM = int(matrix.shape[1])
            VECTOR_ID_TO_INDEX = list(range(len(VECTOR_TEXTS)))
            _build_faiss(VECTOR_MATRIX)
            _save_index_state()
            return
        # 모델 실패 시 TF-IDF fallback
        if TfidfVectorizer is not None:
            VECTOR_MODE = "tfidf"

    if VECTOR_MODE == "tfidf" and TfidfVectorizer is not None:
        try:
            vec = TfidfVectorizer(
                analyzer="char", ngram_range=(2, 5), min_df=1,
                sublinear_tf=True, max_features=250000
            )
            VECTOR_MATRIX = vec.fit_transform(VECTOR_TEXTS)
            VECTOR_DIM = int(VECTOR_MATRIX.shape[1])
            VECTOR_ID_TO_INDEX = list(range(len(VECTOR_TEXTS)))
            # TF-IDF는 현재 라이브러리 상태만 저장하고, 다음 실행에서 다시 fit한다.
            return
        except Exception:
            VECTOR_MATRIX = None
    VECTOR_INDEX = None


def _incremental_add(new_keys, new_texts):
    """새 문장만 임베딩하여 기존 벡터 인덱스 뒤에 추가."""
    global VECTOR_MATRIX, VECTOR_DIM, VECTOR_ID_TO_INDEX
    if not new_texts or np is None:
        return
    if VECTOR_MODE != "sentence-transformer" or EMBED_MODEL is None:
        rebuild_index(force=True)
        return
    new_matrix = _build_sentence_vectors(new_texts)
    if new_matrix is None:
        rebuild_index(force=True)
        return
    if VECTOR_MATRIX is None:
        VECTOR_MATRIX = new_matrix
    else:
        VECTOR_MATRIX = np.vstack([VECTOR_MATRIX, new_matrix])
    VECTOR_DIM = int(VECTOR_MATRIX.shape[1])
    VECTOR_KEYS.extend(new_keys)
    VECTOR_TEXTS.extend(new_texts)
    VECTOR_ID_TO_INDEX = list(range(len(VECTOR_TEXTS)))
    _build_faiss(VECTOR_MATRIX)
    _save_index_state()


def sync_index_after_change(old_keys, old_matrix, old_mode):
    """문서 변경 뒤 기존 임베딩을 재사용하고, 새 문장만 추가 계산한다."""
    global VECTOR_MATRIX, VECTOR_INDEX, VECTOR_KEYS, VECTOR_TEXTS, VECTOR_ID_TO_INDEX
    old_keys = list(old_keys or [])
    old_matrix = None if old_matrix is None else np.asarray(old_matrix, dtype="float32")

    # 현재 문서의 새 목록을 별도 변수로 만든다.
    current_items = []
    for doc in DOCS + BUILTIN_DOCS:
        fname = doc.get("file", "")
        for sent in doc.get("sentences", []):
            current_items.append((_vector_key(fname, sent), sent))

    if (old_mode == "sentence-transformer" and VECTOR_MODE == "sentence-transformer"
            and EMBED_MODEL is not None and np is not None and old_matrix is not None
            and old_matrix.ndim == 2 and len(old_keys) == len(old_matrix)
            and set(old_keys).issubset({k for k, _ in current_items})):
        old_pos = {k: i for i, k in enumerate(old_keys)}
        current_keys = [k for k, _ in current_items]
        current_texts = [t for _, t in current_items]
        new_keys = [k for k in current_keys if k not in old_pos]
        new_texts = [current_texts[i] for i, k in enumerate(current_keys) if k not in old_pos]

        try:
            # 기존 벡터를 현재 문서 순서에 맞춰 재배열한다.
            base_keys = [k for k in current_keys if k in old_pos]
            base_matrix = np.vstack([old_matrix[old_pos[k]] for k in base_keys]) if base_keys else np.empty((0, old_matrix.shape[1]), dtype="float32")
            if new_texts:
                add_matrix = _build_sentence_vectors(new_texts)
                if add_matrix is None:
                    raise RuntimeError("new embedding failed")
                VECTOR_MATRIX = np.vstack([base_matrix, add_matrix])
            else:
                VECTOR_MATRIX = base_matrix

            # current_keys는 old+new 순서와 달라도 전체 벡터가 그 순서에 맞게 구성되어 있다.
            # base_matrix는 old key 부분, add_matrix는 new key 부분이므로 실제 순서를 정렬해야 한다.
            if new_keys and base_keys != [k for k in current_keys if k in old_pos]:
                raise RuntimeError("vector ordering mismatch")
            # 위 구조에서는 current_items가 old+new로 섞일 수 있으므로 다시 안전하게 조립한다.
            vectors_by_key = {k: old_matrix[old_pos[k]] for k in old_keys}
            if new_texts:
                for k, row in zip(new_keys, add_matrix):
                    vectors_by_key[k] = row
            VECTOR_MATRIX = np.vstack([vectors_by_key[k] for k in current_keys]).astype("float32")
            VECTOR_KEYS = current_keys
            VECTOR_TEXTS = current_texts
            VECTOR_DIM = int(VECTOR_MATRIX.shape[1])
            VECTOR_ID_TO_INDEX = list(range(len(VECTOR_TEXTS)))
            _build_faiss(VECTOR_MATRIX)
            _save_index_state()
            return "incremental"
        except Exception:
            pass

    # 삭제/교체/형식 변경이 있었다면 안전하게 전체 재구축한다.
    rebuild_index(force=True)
    return "rebuild"


def vector_search(question, top_n=12):
    """저장된 벡터 인덱스에서 검색. FAISS -> numpy -> TF-IDF 순으로 fallback."""
    if not VECTOR_TEXTS or np is None:
        return []
    try:
        if VECTOR_MODE == "sentence-transformer" and EMBED_MODEL is not None:
            qv = EMBED_MODEL.encode([question], convert_to_numpy=True, normalize_embeddings=True)[0].astype("float32")
            if VECTOR_INDEX is not None:
                scores, ids = VECTOR_INDEX.search(np.ascontiguousarray(qv.reshape(1, -1)), top_n)
                return [(int(i), float(s)) for s, i in zip(scores[0], ids[0]) if i >= 0]
            if VECTOR_MATRIX is not None:
                scores = VECTOR_MATRIX @ qv
                order = np.argsort(-scores)[:top_n]
                return [(int(i), float(scores[i])) for i in order]

        if VECTOR_MODE == "tfidf" and TfidfVectorizer is not None:
            # TF-IDF는 이 버전에서 정확성 우선 fallback. sentence-transformers + FAISS를 권장.
            vec = TfidfVectorizer(analyzer="char", ngram_range=(2, 5), min_df=1,
                                  sublinear_tf=True, max_features=250000)
            mat = vec.fit_transform(VECTOR_TEXTS)
            qv = vec.transform([question])
            scores = (mat @ qv.T).toarray().ravel()
            order = np.argsort(-scores)[:top_n]
            return [(int(i), float(scores[i])) for i in order]
    except Exception:
        return []
    return []


_load_vector_backend()
rebuild_index()

def decode_bytes(raw):
    """한글 파일 인코딩이 뭐든 최대한 읽어내기 (메모장 기본 저장도 OK)"""
    for enc in ("utf-8", "cp949", "euc-kr"):
        try:
            return raw.decode(enc)
        except Exception:
            pass
    return raw.decode("utf-8", errors="replace")


def parse_qa(text):
    """'Q: ... / A: ...' 형식 찾기"""
    pairs, q = [], None
    for line in text.splitlines():
        line = line.strip()
        m = QA_Q.match(line)
        if m:
            q = m.group(1).strip()
            continue
        m = QA_A.match(line)
        if m and q:
            pairs.append((q, m.group(1).strip()))
            q = None
    return pairs


def split_sentences(text):
    """일반 글을 검색하기 좋은 청크로 분할한다. 코드/문서도 처리하고 중복은 나중에 제거."""
    text = text.replace("\r\n", "\n").replace("\r", "\n")
    lines = text.splitlines()
    cleaned = []
    for ln in lines:
        if QA_Q.match(ln.strip()) or QA_A.match(ln.strip()):
            continue
        ln = ln.strip()
        if not ln:
            continue
        cleaned.append(ln)

    # C#/Unity 코드와 문서 모두에서 의미 단위가 유지되도록 빈 줄을 경계로 우선 분리
    blocks = []
    buf = []
    for ln in cleaned:
        buf.append(ln)
        if len(ln) <= 2 or ln.endswith(("}", ";", ".", "!", "?", ":")):
            joined = " ".join(buf).strip()
            if joined:
                blocks.append(joined)
            buf = []
    if buf:
        blocks.append(" ".join(buf).strip())

    out = []
    seen = set()
    for block in blocks:
        # 너무 긴 문서는 겹침 청크로 잘라 검색 문맥을 보존
        if len(block) <= DATASET_CHUNK_SIZE:
            pieces = [block]
        else:
            pieces = []
            pos = 0
            while pos < len(block):
                end_pos = min(len(block), pos + DATASET_CHUNK_SIZE)
                pieces.append(block[pos:end_pos].strip())
                if end_pos >= len(block):
                    break
                pos = max(pos + 1, end_pos - DATASET_CHUNK_OVERLAP)
        for piece in pieces:
            piece = piece.strip()
            if len(normalize(piece)) < 8:
                continue
            key = hashlib.sha1(normalize(piece).encode("utf-8", errors="ignore")).hexdigest()
            if key in seen:
                continue
            seen.add(key)
            out.append(piece)
    return out


def _dataset_entry_id(fname, text):
    h = hashlib.sha1()
    h.update(fname.encode("utf-8", errors="ignore"))
    h.update(b"\0")
    h.update(normalize(text).encode("utf-8", errors="ignore"))
    return h.hexdigest()


def _append_dataset_chunks(fname, chunks):
    """대량 지식을 JSONL에 append. 전체 데이터셋을 메모리에 올리지 않는다."""
    if not chunks:
        return 0
    os.makedirs(DATASET_DIR, exist_ok=True)
    manifest = load_json(DATASET_MANIFEST)
    if not isinstance(manifest, dict):
        manifest = {}
    files = manifest.setdefault("files", {})
    existing = set(files.get(fname, {}).get("ids", []))
    new_records = []
    new_ids = []
    for chunk in chunks:
        cid = _dataset_entry_id(fname, chunk)
        if cid in existing:
            continue
        new_ids.append(cid)
        new_records.append({"id": cid, "file": fname, "text": chunk})
    if new_records:
        with open(DATASET_JSONL, "a", encoding="utf-8") as f:
            for rec in new_records:
                f.write(json.dumps(rec, ensure_ascii=False) + "\n")
        files[fname] = {"ids": sorted(existing | set(new_ids)), "count": len(existing) + len(new_ids)}
        manifest["total_chunks"] = sum(int(v.get("count", 0)) for v in files.values())
        with open(DATASET_MANIFEST, "w", encoding="utf-8") as f:
            json.dump(manifest, f, ensure_ascii=False, indent=2)
    return len(new_records)


def ingest_dataset_file(name, raw):
    """대량 데이터용 ingest: 파일 하나를 청킹하고 디스크에 저장. 평가 산출물은 절대 학습 코퍼스에 넣지 않는다."""
    if _is_eval_artifact_name(name):
        return {"excluded": True, "reason": "benchmark/evaluation artifact", "chunks": 0, "added": 0, "indexed": 0}
    if not name.lower().endswith(ALLOWED_EXT):
        return None
    text = decode_bytes(raw)
    chunks = split_sentences(text)
    added = _append_dataset_chunks(name, chunks)
    # 기존 검색 DB에는 파일당 최대 5000개만 올려 RAM 폭증을 막는다.
    sample = chunks[:5000]
    DOCS[:] = [d for d in DOCS if d["file"] != name]
    if sample:
        DOCS.append({"file": name, "sentences": sample, "count": len(sample), "dataset_total": len(chunks)})
        save_docs()
    return {"chunks": len(chunks), "added": added, "indexed": len(sample)}


def dataset_stats():
    try:
        m = load_json(DATASET_MANIFEST)
        if isinstance(m, dict):
            return int(m.get("total_chunks", 0)), len(m.get("files", {}))
    except Exception:
        pass
    return 0, 0

def learn_from_file(name, raw):
    """파일 학습. 평가/벤치마크 산출물은 학습 코퍼스에 섞이지 않도록 차단."""
    if _is_eval_artifact_name(name):
        return "평가/벤치마크 파일은 학습 데이터로 가져오지 않았어. GroundTruth와 벤치마크 결과는 코퍼스와 분리돼 있어."
    old_vector_keys = list(VECTOR_KEYS)
    old_vector_matrix = None if VECTOR_MATRIX is None else VECTOR_MATRIX.copy()
    old_vector_mode = VECTOR_MODE
    if not name.lower().endswith(ALLOWED_EXT):
        return ("미안, 아직 텍스트/코드 파일만 읽을 수 있어 (.txt .md .csv .log .cs .json .xml .uxml .uss .shader).")
    text = decode_bytes(raw)

    added_qa = 0
    for q, a in parse_qa(text):
        if not any(e["q"][0] == q for e in LEARNED):
            LEARNED.append({"q": [q], "a": [a]})
            added_qa += 1
    if added_qa:
        save_memory()

    ing = ingest_dataset_file(name, raw)
    if not ing:
        return "이 파일은 현재 학습할 수 없는 형식이야."
    if ing["indexed"]:
        sync_index_after_change(old_vector_keys, old_vector_matrix, old_vector_mode)

    total_chunks, total_files = dataset_stats()
    parts = [f"청크 {ing['chunks']}개", f"새로 저장 {ing['added']}개", f"검색 인덱스 {ing['indexed']}개"]
    if added_qa:
        parts.append(f"질문-답 {added_qa}쌍")
    return f"'{name}' 처리 완료! " + ", ".join(parts) + f". 전체 대규모 지식셋은 파일 {total_files}개 / 청크 {total_chunks}개야."


# ── ① 핵심 내용 파악: 질문에서 알맹이 단어만 뽑아내기 ──
JOSA = ["이랑", "에서", "에게", "한테", "부터", "까지", "처럼", "보다", "마다",
        "조차", "밖에", "으로", "이야", "은", "는", "이", "가", "을", "를", "의",
        "에", "로", "와", "과", "도", "만", "랑", "께", "나", "야"]
STOPWORDS = {"뭐", "무엇", "무슨", "어느", "누구", "어디", "언제", "왜", "어떻게",
             "어떤", "몇", "몇살", "몇시", "몇개", "며칠", "얼마나", "지금", "그",
             "이", "저", "것", "거", "건", "게", "좀", "제일", "가장", "진짜",
             "정말", "너무", "혹시", "그리고", "근데", "그럼", "대해", "대한",
             "관련", "내용", "얘기", "아는", "알아", "전부", "모두", "내가",
             "나는", "난", "내", "네가", "너", "우리", "걔", "쟤", "얘",
             "알려줘", "말해줘", "가르쳐줘", "궁금해", "설명해줘", "해줘", "줘",
             "있어", "없어", "뭐야", "뭐지", "뭔데", "비교", "비교해줘", "차이",
             "차이점", "달라", "다른", "누가", "뭐가", "중에", "중에서", "연결",
             "정상", "멀쩡", "확인"}


EOMI = ["이었다", "이에요", "인가요", "하는데", "했는데", "합니다", "이며",
        "이고", "하고", "이다", "였다", "예요", "이야", "인데", "는데", "은데",
        "지만", "다가", "인가", "하는", "하면", "해서", "한다", "했다", "했어",
        "다"]
TAILS = sorted(JOSA + EOMI, key=len, reverse=True)   # 긴 것부터 검사

ONE_CHAR_STOP = set("나너그이저것수걸게더좀다안왜꼭잘못말때건거은는가도를을와과의에해할히")


def strip_josa(token):
    """단어 끝의 조사 떼기: '초코는' -> '초코', '간식을' -> '간식'"""
    for j in JOSA:                                   # 긴 조사부터 검사
        if token.endswith(j) and len(token) - len(j) >= 1:
            return token[:-len(j)]
    return token


def strip_tail(token):
    """조사+어미 떼기: '푸들이고' -> '푸들', '벽을' -> '벽', '좋아하는' -> '좋아'"""
    for t in TAILS:
        if token.endswith(t) and len(token) - len(t) >= 1:
            return token[:-len(t)]
    return token


def extract_keywords(question):
    """질문의 핵심 단어 뽑기. '초코가 좋아하는 간식 알려줘' -> [초코, 좋아, 간식]"""
    q = re.sub(r"[?!.,~]", " ", question)
    kws = []
    for tok in q.split():
        t = normalize(strip_tail(tok.strip()))
        if not t or t in STOPWORDS or t in kws:
            continue
        if len(t) == 1 and (t in ONE_CHAR_STOP or not ("가" <= t <= "힣")):
            continue                       # 한 글자는 '벽, 털' 같은 명사만
        kws.append(t)
    return kws[:6]


# ── ②+③ 관련 지식 여러 개 검색 -> 답변 생성 ──
HIGH_MATCH = 0.40   # 이 점수 이상이면 자신 있게 파일 지식으로 대답
LOW_MATCH = 0.20    # 이 정도면 "이거 아닐까?" 하고 대답


# ── 추론 재료들 ──
def sentence_keywords(sent):
    """문장에서 핵심 단어 뽑기 (연결 고리 후보)"""
    out = []
    for tok in re.sub(r"[?!.,~]", " ", sent).split():
        t = normalize(strip_tail(tok.strip()))
        if len(t) >= 2 and t not in STOPWORDS and t not in out:
            out.append(t)
    return out[:8]


def has_batchim(word):
    """마지막 글자에 받침이 있는지 ('초코'->없음, '철수'->없음, '들'->있음)"""
    c = word[-1]
    return "가" <= c <= "힣" and (ord(c) - ord("가")) % 28 != 0


def swap_subject(sentence, old, new):
    """'푸들은 털이...' 에서 푸들 자리에 초코를 조사까지 맞춰 넣기 -> '초코는 털이...'"""
    m = re.search(re.escape(old) + r"(은|는|이|가|을|를|도|의)?", sentence)
    if not m:
        return None
    j = m.group(1) or ""
    if j in ("은", "는"):
        j = "은" if has_batchim(new) else "는"
    elif j in ("이", "가"):
        j = "이" if has_batchim(new) else "가"
    elif j in ("을", "를"):
        j = "을" if has_batchim(new) else "를"
    return sentence[:m.start()] + new + j + sentence[m.end():]


NUM_RE = re.compile(r"(\d+(?:\.\d+)?)\s*(살|kg|킬로|cm|센티|미터|점|원|개|마리|번|시간|분|년|등)")
UNIT_TALK = {"살": "나이가 더 많아", "kg": "더 무거워", "킬로": "더 무거워",
             "cm": "더 커", "센티": "더 커", "미터": "더 커", "점": "점수가 더 높아",
             "원": "더 비싸", "등": "순위 숫자가 더 커"}


# ── ③-진단: 문제 증상 -> 원인 추리기 ──
TROUBLE_WORDS = ["통과", "안 돼", "안돼", "안 됨", "안됨", "안 되", "안되",
                 "안 먹", "오류", "에러", "버그", "이상해", "왜 이래", "안 움직",
                 "안 보여", "안 나와", "안 들려", "안 눌", "작동", "안 해",
                 "실행이 안", "고장", "문제가", "문제야", "문제 생"]
RULED_OK = re.compile(r"(정상|멀쩡|있어|있고|있음|있는데|확인했|확인 했|했는데|"
                      r"붙어|붙였|켜져|켰|추가했|넣었|맞아|맞는데)")
ABSENCE = ["없으면", "없어서", "없다", "없는", "안 붙", "빠져", "빠졌",
           "추가하지 않", "미추가"]


def try_diagnose(question, kws):
    """증상 파악 -> 원인 지식 수집 -> 확인된 건 제외 -> 가능성 순 정렬"""
    if not any(w in question for w in TROUBLE_WORDS):
        return None

    # 사용자가 "이미 확인했다"고 한 것들 골라내기
    clauses = re.split(r"[,.]|이고|인데|는데|지만|그리고|이며", question)
    ruled = []
    for c in clauses:
        if RULED_OK.search(c) and not any(w in c for w in TROUBLE_WORDS):
            for k in extract_keywords(c):
                if k not in ruled:
                    ruled.append(k)
    symptom = [k for k in kws if k not in ruled] or kws
    if not symptom:
        return None

    # 증상과 관련된 원인 지식 전부 수집
    qv = bigrams("".join(symptom))
    denom = max(1, min(len(symptom), 3))     # 잡단어가 많아도 점수가 희석되지 않게
    cand = []
    for f, sent, vec, ns in INDEX:
        matched = sum(1 for k in symptom
                      if k in ns or (len(k) >= 3 and k[:-1] in ns))
        cov = min(matched, denom) / denom
        sc = 0.5 * cosine(qv, vec) + 0.5 * cov
        if sc >= 0.18:
            cand.append((sc, sent, f, ns))
    if not cand:
        return None
    cand.sort(key=lambda x: -x[0])
    if cand[0][0] < 0.28:            # 관련 지식이 너무 빈약하면 진단 포기
        return None

    # 확인 끝난 항목의 '없음' 계열 원인은 제외하고, 가능성 순으로 추리기
    picks, skipped = [], []
    for sc, sent, f, ns in cand:
        hit = next((r for r in ruled if r in ns), None)
        if hit and any(a in sent for a in ABSENCE):
            if hit not in skipped:
                skipped.append(hit)
            continue
        if len(picks) < 5 and not any(normalize(sent) == normalize(s)
                                      for _, s, _ in picks):
            picks.append((sc, sent, f))
    if not picks:
        return None

    lines = [f"🔍 진단 모드! '{'·'.join(symptom[:3])}' 증상의 원인을 추려볼게."]
    if skipped:
        lines.append(f"(이미 확인한 것: {', '.join(ruled[:4])} → 그쪽 '없음' 계열 원인은 걸렀어!)")
    lines.append("가능성 높은 원인부터:")
    for i, (sc, sent, f) in enumerate(picks, 1):
        if " -> " in sent:
            cause, fix = sent.split(" -> ", 1)
            lines.append(f"{i}. {cause}  ▶ {fix}")
        else:
            lines.append(f"{i}. {sent}")
    lines.append("위에서부터 하나씩 확인해 보고, 결과 알려줘!")
    return "\n".join(lines)


def try_compare(kws, question):
    """② 비교: 두 대상의 지식을 나란히 놓고, 숫자가 있으면 크기까지 추론"""
    is_cmp = (any(w in question for w in ["비교", "차이", "달라", "다른 점"]) or
              re.search(r"(누가|누구|뭐가|어느|어떤)\s*(게|것|쪽)?\s*더", question))
    if not is_cmp:
        return None
    sides = []
    for k in kws:                       # 각 대상마다 제일 좋은 지식 문장 고르기
        cand = []
        for f, sent, vec, ns in INDEX:
            if k in ns:
                cand.append((bool(re.search(r"\d", sent)), cosine(bigrams(k), vec), sent, f))
        if cand:
            cand.sort(reverse=True)     # 숫자 있는 문장 우선 (비교엔 숫자가 재료!)
            sides.append((k, cand[0][2], cand[0][3]))
        if len(sides) == 2:
            break
    if len(sides) < 2:
        return None
    (k1, s1, f1), (k2, s2, f2) = sides
    lines = [f"'{k1}' vs '{k2}', 비교해 볼게!",
             f"① {k1}: {s1} ('{f1}')",
             f"② {k2}: {s2} ('{f2}')"]
    n1 = next(iter(NUM_RE.findall(s1)), None)       # 숫자 추론
    if n1:
        n2 = next((x for x in NUM_RE.findall(s2) if x[1] == n1[1]), None)
        if n2 and float(n1[0]) != float(n2[0]):
            win = k1 if float(n1[0]) > float(n2[0]) else k2
            talk = UNIT_TALK.get(n1[1], f"{n1[1]} 숫자가 더 커")
            j = "이" if has_batchim(win) else "가"
            lines.append(f"→ 결론: {k1}({n1[0]}{n1[1]}) vs {k2}({n2[0]}{n2[1]}) "
                         f"— {win}{j} {talk}!")
    return "\n".join(lines)


def is_general(sent, link):
    """'푸들은 ~다' 처럼 다리 단어가 주어인 일반 명제인지"""
    return bool(re.match(re.escape(link) + r"(은|는|이|가)", sent.strip()))


def try_chain(kws, top_hit):
    """② 연결: 부족한 단어를 다리 단어로 이어서 두 지식을 연결 -> 추론"""
    top_sc, top_sent, top_f = top_hit
    ns_top = normalize(top_sent)
    missing = [k for k in kws if k not in ns_top]
    if not missing:
        return None
    bridges = [b for b in sentence_keywords(top_sent) if b not in kws]
    if not bridges:
        return None
    best = None                          # 다리를 건너 부족한 단어를 채워줄 문장 찾기
    for f, sent, vec, ns in INDEX:
        if ns == ns_top:
            continue
        link = next((b for b in bridges if b in ns), None)
        if not link:
            continue
        got = [k for k in missing if k in ns or (len(k) >= 2 and k[:-1] in ns)]
        if not got:
            continue
        sc = len(got) + cosine(bigrams("".join(missing)), vec)
        if best is None or sc > best[0]:
            best = (sc, sent, f, link)
    if not best:
        return None
    _, sent2, f2, link = best

    # ③ 추론: 일반 명제('푸들은 ~') 쪽에 개체('초코')를 넣어 결론 만들기
    if is_general(sent2, link) and not is_general(top_sent, link):
        s_gen, s_ent = sent2, top_sent
    elif is_general(top_sent, link) and not is_general(sent2, link):
        s_gen, s_ent = top_sent, sent2
    else:
        s_gen = s_ent = None
    conclusion = None
    if s_gen:
        entity = next((k for k in kws if k in normalize(s_ent) and k != link), None)
        if entity:
            conclusion = swap_subject(s_gen, link, entity)

    lines = [f"'{'·'.join(kws[:3])}'... 두 지식을 연결해서 생각해 봤어!",
             f"① {top_sent} ('{top_f}')",
             f"② {sent2} ('{f2}')"]
    if conclusion:
        lines.append(f"→ 그러니까 결론: \"{conclusion}\" 일 거야!")
    else:
        lines.append(f"→ 이 둘은 '{link}'(으)로 이어져 있어!")
    return "\n".join(lines)


def _meta_for_hit(fname, sent):
    return SEARCH_META.get((fname, normalize(sent)), {
        "quality": 0.55,
        "source_trust": _clamp01(source_trust(fname)),
        "relevance": 0.50,
        "category": "unknown",
        "document_type": "unknown",
        "license": "unknown",
        "source_url": "",
        "title": fname,
        "collector_version": "",
    })


def _metadata_score(meta):
    """collector 품질 메타데이터를 0~1 보정값으로 변환."""
    q = _clamp01(meta.get("quality", 0.0))
    tr = _clamp01(meta.get("source_trust", 0.0))
    rel = _clamp01(meta.get("relevance", 0.0))
    # 검색 점수에 과도하게 개입하지 않도록 0.60~1.00 범위로 보정
    return 0.60 + 0.22*q + 0.12*tr + 0.06*rel


def search_docs(question, extra_kws=None):
    """질문 -> 키워드/2-gram + 벡터 검색 -> 결과 결합 -> 연결/비교/진단 -> 답변"""
    if not INDEX:
        return None, 0.0

    kws = extract_keywords(question)
    for k in (extra_kws or []):
        if k not in kws:
            kws.append(k)
    kws = kws[:6]
    qn = normalize(re.sub(
        r"알려줘|말해줘|가르쳐줘|궁금해|뭐야|뭐지|뭔데|뭐게|누구야|누구니|누군데|어디야|언제야|어때",
        "", question))
    if not kws and len(qn) < 2:
        return None, 0.0
    qv = bigrams(qn)

    answer = try_diagnose(question, kws)
    if answer:
        return answer, HIGH_MATCH + 0.1

    if len(kws) >= 2:
        answer = try_compare(kws, question)
        if answer:
            return answer, HIGH_MATCH + 0.05

    # 전통 검색
    scored = []
    for idx, (fname, sent, vec, nsent) in enumerate(INDEX):
        sim = cosine(qv, vec)
        cov = (sum(1 for k in kws if k in nsent or (len(k) >= 3 and k[:-1] in nsent))
               / len(kws)) if kws else 0.0
        lexical = 0.55 * sim + 0.45 * cov
        if lexical >= LOW_MATCH * 0.75:
            scored.append((idx, lexical, sent, fname))

    # 벡터 검색 결과
    vmap = {idx: score for idx, score in vector_search(question, top_n=VECTOR_TOP_N)}

    # 하이브리드 점수: 의미 0.50 + 기존 검색 0.35 + 키워드 보정 0.15
    merged = []
    all_ids = {x[0] for x in scored} | set(vmap)
    lexical_map = {x[0]: x[1] for x in scored}
    for idx in all_ids:
        fname, sent, _, nsent = INDEX[idx]
        lexical = lexical_map.get(idx, 0.0)
        semantic = max(0.0, min(1.0, vmap.get(idx, 0.0)))
        keyword = 0.0
        if kws:
            keyword = sum(1 for k in kws if k in nsent or (len(k) >= 3 and k[:-1] in nsent)) / len(kws)
        meta = _meta_for_hit(fname, sent)
        metadata_factor = _metadata_score(meta)
        # 기존 검색 신호를 유지하면서 collector 품질/신뢰도/관련성을 실제 최종 점수에 반영
        base_sc = 0.50 * semantic + 0.35 * lexical + 0.15 * keyword
        sc = max(0.0, min(1.0, base_sc * metadata_factor))
        if sc >= LOW_MATCH * 0.65:
            merged.append((sc, sent, fname))

    if not merged:
        return None, 0.0
    merged.sort(key=lambda x: -x[0])

    hits = []
    for sc, sent, fname in merged:
        if hits and sc < max(LOW_MATCH + 0.04, hits[0][0] * 0.72):
            break
        ns = normalize(sent)
        dup = any(ns == normalize(s2) or ns in normalize(s2) or normalize(s2) in ns
                  for _, s2, _ in hits)
        if not dup:
            hits.append((sc, sent, fname))
        if len(hits) >= SEARCH_HIT_LIMIT:
            break

    if not hits:
        return None, 0.0

    top = hits[0][0]
    kwtxt = "·".join(kws[:3]) if kws else "그 얘기"

    # 검색 근거끼리 충돌하는지 검사하고, 출처/검색점수로 보수적으로 선택한다.
    conflict_rows, primary_conflict = evaluate_conflicts(hits)
    if primary_conflict:
        winner = primary_conflict["winner"]
        if winner == "left":
            chosen = primary_conflict["left"]
            rejected = primary_conflict["right"]
            trust_note = "출처 신뢰도와 검색 일치도가 더 높아서 이쪽을 우선했어."
        elif winner == "right":
            chosen = primary_conflict["right"]
            rejected = primary_conflict["left"]
            trust_note = "출처 신뢰도와 검색 일치도가 더 높아서 이쪽을 우선했어."
        else:
            chosen = None
            rejected = None
            trust_note = "두 근거의 신뢰도가 비슷해서 어느 쪽도 확정하지 않았어."

        if chosen:
            cs, cf, _ = chosen
            rs, rf, _ = rejected
            return (f"⚠️ 서로 충돌하는 정보가 발견됐어.\n"
                    f"우선 근거: {cs} ('{cf}')\n"
                    f"반대 근거: {rs} ('{rf}')\n"
                    f"→ {trust_note}\n"
                    f"→ 확실하지 않은 부분은 원문을 추가로 확인하는 게 좋아."), max(top, chosen[2])
        else:
            ls, lf, _ = primary_conflict["left"]
            rs, rf, _ = primary_conflict["right"]
            return (f"⚠️ 서로 충돌하는 정보가 있어.\n① {ls} ('{lf}')\n② {rs} ('{rf}')\n"
                    f"→ 두 출처의 신뢰도가 비슷해서 지금은 어느 쪽도 확정하지 않을게."), top

    if len(kws) >= 2:
        answer = try_chain(kws, hits[0])
        if answer:
            return answer, max(top, HIGH_MATCH + 0.05)

    if len(hits) == 1:
        sc, sent, fname = hits[0]
        mode = "의미 검색" if VECTOR_MODE == "sentence-transformer" else "벡터 검색"
        meta = _meta_for_hit(fname, sent)
        quality_note = f"품질 {meta.get('quality',0):.2f} · 출처 {meta.get('source_trust',0):.2f}"
        return f"'{kwtxt}'에 대해 찾아봤어! {sent}. ('{fname}'에서 배운 내용이야 · {mode} · {quality_note})", top

    sents = [h[1] for h in hits]
    files = ", ".join(sorted({f"'{h[2]}'" for h in hits}))
    joined = sents[0] + ". " + " ".join(c + s + "." for c, s in zip(["그리고 ", "또 ", "마지막으로 "], sents[1:]))
    mode = "의미 기반 검색" if VECTOR_MODE == "sentence-transformer" else "하이브리드 벡터 검색"
    meta_notes = []
    for _, hs, hf in hits[:3]:
        hm = _meta_for_hit(hf, hs)
        meta_notes.append(f"{hm.get('category','unknown')} 품질={hm.get('quality',0):.2f} 출처={hm.get('source_trust',0):.2f}")
    note = " / ".join(meta_notes)
    return f"'{kwtxt}'에 대해 아는 걸 이어 보면: {joined} ({files}에서 배운 내용이야 · {mode} · {note})", top

# ──────────────────────────────────────────────
# 4.9 지식 충돌 감지/신뢰도 평가
# ──────────────────────────────────────────────
TRUST_WEIGHTS = {
    "official_unity": 1.00,
    "official_microsoft": 1.00,
    "official_docs": 0.95,
    "sample": 0.88,
    "project": 0.82,
    "user": 0.70,
    "unknown": 0.55,
}
NEG_WORDS = ("아니다", "아님", "않다", "않음", "못한다", "못함", "불가능", "없다", "없음",
             "never", "not", "cannot", "can't", "false", "unsupported", "does not")
POS_WORDS = ("가능", "가능하다", "된다", "됨", "지원", "지원한다", "있다", "있음",
             "가능함", "supported", "true", "yes")

def source_trust(fname, sent=None):
    """collector 메타데이터가 있으면 그것을 우선하고, 없으면 파일명 기반으로 보수적으로 추정한다."""
    if sent is not None:
        meta = SEARCH_META.get((fname, normalize(sent)))
        if meta and "source_trust" in meta:
            return _clamp01(meta.get("source_trust", 0.0))
    s = str(fname or "").lower()
    if "docs.unity3d.com" in s or "unity.com" in s or "unity_manual" in s or "unity_api" in s:
        return TRUST_WEIGHTS["official_unity"]
    if "learn.microsoft.com" in s or "microsoft.com" in s or "dotnet" in s or "csharp" in s:
        return TRUST_WEIGHTS["official_microsoft"]
    if any(k in s for k in ("official", "documentation", "docs")):
        return TRUST_WEIGHTS["official_docs"]
    if any(k in s for k in ("sample", "example", "tutorial")):
        return TRUST_WEIGHTS["sample"]
    if any(k in s for k in ("project", "asset", "package")):
        return TRUST_WEIGHTS["project"]
    if "우리 대화" in s or "memory" in s or "user" in s:
        return TRUST_WEIGHTS["user"]
    return TRUST_WEIGHTS["unknown"]

def _strip_negation(text):
    t = normalize(text)
    for w in NEG_WORDS:
        t = t.replace(normalize(w), "")
    for w in POS_WORDS:
        t = t.replace(normalize(w), "")
    return t

def _numbers_with_units(text):
    return re.findall(r"([+-]?\d+(?:[.,]\d+)?)\s*([%a-zA-Z가-힣]+)?", text or "")

def detect_conflicts(hits):
    """상위 검색 근거 사이의 명백한 모순만 보수적으로 표시한다."""
    conflicts = []
    for i in range(len(hits)):
        s1, t1, f1 = hits[i][1], hits[i][0], hits[i][2]
        n1 = normalize(s1)
        for j in range(i + 1, len(hits)):
            s2, t2, f2 = hits[j][1], hits[j][0], hits[j][2]
            n2 = normalize(s2)
            if not n1 or not n2 or n1 == n2:
                continue

            base1, base2 = _strip_negation(s1), _strip_negation(s2)
            neg1 = any(normalize(w) in n1 for w in NEG_WORDS)
            neg2 = any(normalize(w) in n2 for w in NEG_WORDS)
            pos1 = any(normalize(w) in n1 for w in POS_WORDS)
            pos2 = any(normalize(w) in n2 for w in POS_WORDS)
            shared = set(extract_keywords(s1)) & set(extract_keywords(s2))

            # 같은 주제 + 한쪽은 긍정/한쪽은 부정
            if shared and base1[:10] and base2[:10] and (neg1 and pos2 or neg2 and pos1):
                strength = 0.86 if len(shared) >= 2 else 0.72
                conflicts.append({"left": (s1, f1, t1), "right": (s2, f2, t2),
                                  "strength": strength, "type": "negation"})
                continue

            # 같은 핵심 주제 + 같은 단위의 숫자 차이
            nums1 = _numbers_with_units(s1)
            nums2 = _numbers_with_units(s2)
            if shared and nums1 and nums2:
                vals1 = {(a, u.lower()) for a, u in nums1}
                vals2 = {(a, u.lower()) for a, u in nums2}
                units1 = {u for _, u in vals1 if u}
                units2 = {u for _, u in vals2 if u}
                if units1 & units2 and vals1 != vals2:
                    conflicts.append({"left": (s1, f1, t1), "right": (s2, f2, t2),
                                      "strength": 0.78, "type": "numeric"})
    return conflicts

def evaluate_conflicts(hits):
    """충돌이 있으면 출처 신뢰도 + 검색점수 + 반복 지지로 우선순위를 정한다."""
    conflicts = detect_conflicts(hits)
    if not conflicts:
        return [], None
    rows = []
    for c in conflicts:
        ls, lf, lscore = c["left"]
        rs, rf, rscore = c["right"]
        lt = source_trust(lf, ls)
        rt = source_trust(rf, rs)
        # 검색 점수 45% + 출처 45% + 충돌 강도 10%
        lfinal = 0.45 * max(0.0, min(1.0, lscore)) + 0.45 * lt + 0.10 * c["strength"]
        rfinal = 0.45 * max(0.0, min(1.0, rscore)) + 0.45 * rt + 0.10 * c["strength"]
        winner = "left" if lfinal > rfinal + 0.02 else ("right" if rfinal > lfinal + 0.02 else "tie")
        rows.append({**c, "left_trust": lt, "right_trust": rt,
                     "left_final": lfinal, "right_final": rfinal, "winner": winner})
    # 가장 선명한 충돌부터 보여준다.
    rows.sort(key=lambda x: -abs(x["left_final"] - x["right_final"]))
    primary = rows[0]
    return rows[:3], primary


# ──────────────────────────────────────────────
# 4.5 대화 기억! (② 단계)
# ──────────────────────────────────────────────
HISTORY = []              # 이번 세션의 대화 기록 [(역할, 말)]
CONTEXT = {"topic": []}   # 직전 대화의 주제 단어들
CONVO_NAME = "우리 대화"   # 네 얘기를 저장하는 특별한 지식 이름

# v6.2 채팅 세션 저장: 프로그램을 껐다 켜도 대화방/메시지를 복구할 수 있다.
CHAT_DB = APP_DIR / _PATHS_CFG.get("chat_db", "data/memory/ai_chat_sessions.json")
CURRENT_CHAT_ID = None

def _chat_db_load():
    try:
        if CHAT_DB.exists():
            d = json.loads(CHAT_DB.read_text(encoding="utf-8"))
            if isinstance(d, dict) and isinstance(d.get("sessions"), list):
                return d
    except Exception:
        pass
    return {"sessions": []}

def _chat_db_save(d):
    try:
        atomic_write_json(CHAT_DB, d)
    except Exception:
        CHAT_DB.write_text(json.dumps(d, ensure_ascii=False, indent=2), encoding="utf-8")

def _chat_new(title="새 채팅"):
    global CURRENT_CHAT_ID, HISTORY, CONTEXT
    sid=f"chat-{int(time.time()*1000)}"
    d=_chat_db_load()
    sess={"id":sid,"title":(title or "새 채팅")[:80],"created_at":time.time(),"updated_at":time.time(),"messages":[] }
    d["sessions"].insert(0,sess); d["sessions"]=d["sessions"][:50]
    _chat_db_save(d); CURRENT_CHAT_ID=sid; HISTORY=[]; CONTEXT={"topic":[]}
    return sess

def _chat_select(sid):
    global CURRENT_CHAT_ID, HISTORY, CONTEXT
    d=_chat_db_load()
    for sess in d["sessions"]:
        if sess.get("id")==sid:
            CURRENT_CHAT_ID=sid
            HISTORY=[(m.get("role",""),m.get("content","")) for m in sess.get("messages",[])][-40:]
            return sess
    return None

def _chat_current(create=True):
    if CURRENT_CHAT_ID:
        s=_chat_select(CURRENT_CHAT_ID)
        if s: return s
    return _chat_new() if create else None

def _chat_append(role, content):
    global CURRENT_CHAT_ID, HISTORY
    sess=_chat_current(True)
    d=_chat_db_load()
    for s in d["sessions"]:
        if s.get("id")==sess.get("id"):
            s.setdefault("messages",[]).append({"role":role,"content":str(content),"ts":time.time()})
            s["updated_at"]=time.time()
            if role=="user" and s.get("title") in (None,"","새 채팅"):
                t=str(content).replace("\n"," ").strip(); s["title"]=t[:50]+("…" if len(t)>50 else "")
            break
    for s in d["sessions"]:
        s["messages"]=s.get("messages",[])[-120:]
    d["sessions"]=sorted(d["sessions"],key=lambda x:x.get("updated_at",0),reverse=True)[:50]
    _chat_db_save(d)
    HISTORY=[(m.get("role",""),m.get("content","")) for m in sess.get("messages",[])][-40:]

# 시작 시 최근 채팅을 복구
try:
    _chat_current(True)
except Exception:
    pass

FOLLOWUP_WORDS = ["그럼", "그러면", "그건", "그거", "그게", "그때", "걔",
                  "쟤", "얘", "그 애", "그애", "거기", "그날", "그중"]


def is_followup(text):
    """'그럼 간식은?' 처럼 앞 대화에 이어지는 질문인지"""
    return any(w in text for w in FOLLOWUP_WORDS)


def looks_like_self_fact(text):
    """'내 이름은 민수야' 같은 자기 소개 문장인지"""
    t = text.strip()
    if t.endswith("?"):
        return False
    if any(w in t for w in ["뭐", "누구", "언제", "어디", "왜", "어떻", "몇", "?"]):
        return False
    if not re.match(r"^(내가|나는|내|난|저는|제)\s", t + " "):
        return False
    return len(normalize(t)) >= 4


def remember_fact(sentence):
    """네 얘기를 '우리 대화' 지식으로 저장 (가능하면 새 문장만 벡터화)"""
    old_vector_keys = list(VECTOR_KEYS)
    old_vector_matrix = None if VECTOR_MATRIX is None else VECTOR_MATRIX.copy()
    old_vector_mode = VECTOR_MODE
    doc = next((d for d in DOCS if d["file"] == CONVO_NAME), None)
    if doc is None:
        doc = {"file": CONVO_NAME, "sentences": [], "count": 0}
        DOCS.append(doc)
    s = sentence.strip()[:200]
    if s not in doc["sentences"]:
        doc["sentences"].append(s)
        doc["count"] = len(doc["sentences"])
        save_docs()
        sync_index_after_change(old_vector_keys, old_vector_matrix, old_vector_mode)


# ──────────────────────────────────────────────
# 5. 특수 능력들 (규칙 기반 스킬)
# ──────────────────────────────────────────────
def skill_time(text):
    if any(k in text for k in ["몇시", "몇 시", "지금 시간", "시간 알려", "시계"]):
        now = datetime.now()
        return f"지금은 {now.hour}시 {now.minute}분이야."
    if any(k in text for k in ["날짜", "며칠", "몇 일", "요일"]):
        now = datetime.now()
        days = ["월", "화", "수", "목", "금", "토", "일"]
        return f"오늘은 {now.year}년 {now.month}월 {now.day}일 {days[now.weekday()]}요일이야."
    return None


def skill_age(text):
    if any(k in text for k in ["몇 살", "몇살", "나이가"]):
        sec = int((datetime.now() - START_TIME).total_seconds())
        m, s = divmod(sec, 60)
        return f"난 네가 날 실행한 순간 태어났어. 그러니까 지금 {m}분 {s}초 살았네!"
    return None


def skill_recall(text):
    if any(k in text for k in ["아까 뭐", "방금 뭐", "무슨 얘기 했", "뭐라고 했",
                               "무슨 말 했", "아까 내가"]):
        users = [t for r, t in HISTORY if r == "user"][:-1]   # 지금 이 말은 빼고
        if not users:
            return "우리 아직 얘기 시작한 지 얼마 안 됐는걸!"
        recent = users[-3:]
        return "아까 이런 얘기 했었지: " + " / ".join(f"'{u}'" for u in recent)
    return None


def skill_about_me(text):
    if any(k in text for k in ["나에 대해", "나 뭐 알아", "내 얘기 뭐"]):
        doc = next((d for d in DOCS if d["file"] == CONVO_NAME), None)
        if not doc or not doc["sentences"]:
            return "아직 너에 대해 아는 게 없어. '내 이름은 OO야'처럼 얘기해주면 기억할게!"
        facts = doc["sentences"][-5:]
        return "너에 대해 이런 걸 기억하고 있어!\n" + "\n".join(f"- {f}" for f in facts)
    if any(k in text for k in ["내 얘기 까먹", "내 얘기 잊어", "나에 대해 잊어"]):
        DOCS[:] = [d for d in DOCS if d["file"] != CONVO_NAME]
        rebuild_index()
        save_docs()
        return "알겠어, 너에 대해 기억하던 건 전부 잊었어!"
    return None


def skill_vector(text):
    if any(k in text for k in ["검색 방식", "벡터 검색", "임베딩", "의미 검색"]):
        if VECTOR_MODE == "sentence-transformer":
            idx = "FAISS" if VECTOR_INDEX is not None else "numpy"
            return f"현재 의미 검색 모델 + {idx} 벡터 인덱스를 쓰고 있어. {len(INDEX)}개 지식을 기존 검색과 함께 찾아."
        if VECTOR_MODE == "tfidf":
            return f"현재 TF-IDF 벡터 검색과 기존 키워드 검색을 함께 사용 중이야. {len(INDEX)}개 지식이 인덱싱돼 있어. sentence-transformers와 FAISS가 설치되면 대용량 의미 검색으로 올라가."
        return "현재은 기존 문자열 검색만 사용하고 있어. 벡터 검색 라이브러리를 설치하면 자동으로 업그레이드할 수 있어."
    return None


def skill_dataset(text):
    if any(k in text for k in ["데이터셋", "대규모 지식", "전체 지식", "청크 몇", "학습 데이터"]):
        total_chunks, total_files = dataset_stats()
        return f"대규모 지식셋에 파일 {total_files}개, 청크 {total_chunks}개가 저장돼 있어. 현재 실행 메모리에는 필요한 검색용 일부만 올려서 RAM을 보호하고 있어."
    return None


def skill_llm(text):
    # 호환성을 위해 기존 명령을 유지하되, 외부 LLM은 사용하지 않음.
    if any(k in text for k in ["LLM", "언어 모델", "모델 상태", "두뇌 상태", "모델 뭐 써"]):
        return (f"외부 LLM/Ollama 없이 자체 답변 엔진 v{LOCAL_ANSWER_VERSION}을 사용 중이야. "
                f"검색 → 근거 정렬 → 중복 제거 → 답변 구성 순서로 대답해.")
    return None


def skill_files(text):
    if any(k in text for k in ["무슨 파일", "배운 파일", "파일 뭐", "파일 목록"]):
        names = ", ".join(f"'{d['file']}'({d['count']}문장)"
                          for d in DOCS + BUILTIN_DOCS)
        return f"지금 아는 지식: {names}. 📎 버튼으로 더 가르쳐줄 수도 있어!"
    if any(k in text for k in ["파일 까먹", "파일 잊어", "파일 지워", "파일 삭제"]):
        DOCS[:] = [d for d in DOCS if d["file"] == CONVO_NAME]   # 네 얘기는 남기고
        rebuild_index()
        save_docs()
        return "알겠어, 파일에서 배운 건 전부 잊었어! (너에 대한 기억은 그대로야)"
    return None


def skill_learned(text):
    if any(k in text for k in ["뭐 배웠", "배운 거", "배운거", "뭘 배웠", "기억하는 거"]):
        n, d = len(LEARNED), len(DOCS)
        if n == 0 and d == 0:
            return "아직 배운 건 없어. 모르는 걸 물어보거나 📎로 파일을 주면 배울 수 있어!"
        msg = []
        if n:
            msg.append(f"문답 {n}개")
        if d:
            msg.append(f"파일 {d}개")
        return f"지금까지 {', '.join(msg)}를 배웠어!"
    return None


def skill_dice(text):
    if "주사위" in text:
        return f"주사위 굴린다~ 데구르르... {random.randint(1, 6)} 나왔어!"
    if "동전" in text:
        return f"동전 던진다! 탁... {random.choice(['앞면', '뒷면'])}이야!"
    return None


RPS = ["가위", "바위", "보"]


def skill_rps(text):
    t = text.strip()
    if "가위바위보" in t.replace(" ", ""):
        return "좋아, 가위바위보 하자! 가위 / 바위 / 보 중에 하나를 쳐봐."
    if t in RPS:
        me = random.choice(RPS)
        if me == t:
            verdict = "비겼다! 한 판 더?"
        elif (t, me) in [("가위", "보"), ("바위", "가위"), ("보", "바위")]:
            verdict = "네가 이겼어... 분하다!"
        else:
            verdict = "내가 이겼지롱!"
        return f"나는 {me}! {verdict}"
    return None


def skill_choose(text):
    if not any(k in text for k in ["골라", "뽑아", "정해줘"]):
        return None
    t = re.split(r"중에서|중에|골라|뽑아|정해줘", text)[0]
    t = re.sub(r"vs|아니면|이랑|하고", ",", t)
    parts = [p.strip() for p in re.split(r"[,/\s]+", t) if p.strip()]
    junk = {"좀", "그냥", "하나만", "하나", "제발", "오늘", "나", "내가", "뭐",
            "메뉴", "저녁", "점심", "아침", "빨리"}
    options = [p for p in parts if p not in junk]
    if len(options) >= 2:
        pick = random.choice(options)
        return f"음... 고민해 봤는데, '{pick}'! 이걸로 하자."
    return "뭐 중에 고를까? 이렇게 말해줘 → 짜장면, 짬뽕 중에 골라줘"


def skill_calc(text):
    t = (text.replace("더하기", "+").replace("빼기", "-")
             .replace("곱하기", "*").replace("나누기", "/")
             .replace("x", "*").replace("×", "*").replace("÷", "/")
             .replace("^", "**"))
    expr = re.sub(r"[^0-9+\-*/(). ]", "", t).strip()
    if not re.search(r"\d", expr) or not re.search(r"[+\-*/]", expr):
        return None
    if not re.fullmatch(r"[0-9+\-*/(). ]+", expr):
        return None
    try:
        result = eval(expr, {"__builtins__": {}}, {})  # 숫자/기호만 허용했으니 안전
    except ZeroDivisionError:
        return "0으로는 못 나눠! 수학 세계가 무너진다구."
    except Exception:
        return None
    if isinstance(result, float):
        result = int(result) if result.is_integer() else round(result, 4)
    return f"계산해 봤어. {expr.strip()} = {result} !"


SKILLS = [skill_recall, skill_about_me, skill_time, skill_age, skill_vector, skill_dataset, skill_llm, skill_files,
          skill_learned, skill_dice, skill_rps, skill_choose, skill_calc]


# ──────────────────────────────────────────────
# 6. AI의 두뇌: 생각하는 순서
#    배우는 중? -> 가르쳐준 문답 -> 짧은 잡담 -> 네 얘기면 기억
#    -> 지식 검색(직전 주제 반영) -> 특수 능력 -> 내장 지식
#    -> 지식 검색(애매함) -> 모르면 배우기
# ──────────────────────────────────────────────
def best_knowledge(text, entries):
    """지식 목록에서 가장 비슷한 항목과 점수 찾기"""
    best, best_sc = None, 0.0
    for entry in entries:
        for p in entry["q"]:
            s = score(text, p)
            if s > best_sc:
                best, best_sc = entry, s
    return best, best_sc


def _clean_evidence_line(text):
    """검색 결과에서 UI/출처용 괄호를 과도하게 남기지 않도록 정리."""
    t = re.sub(r"\s+", " ", str(text or "")).strip()
    t = re.sub(r"\s*\([^()]{0,120}에서 배운 내용이야[^()]*\)", "", t)
    t = t.replace("의미 기반 검색", "").replace("하이브리드 벡터 검색", "")
    return t.strip(" .")


def _split_evidence(text):
    parts = []
    for line in re.split(r"[\n]+", str(text or "")):
        line = line.strip(" -•\t")
        if not line:
            continue
        # 번호/불필요한 라벨 제거
        line = re.sub(r"^[①②③④⑤]\s*", "", line)
        line = re.sub(r"^\d+[.)]\s*", "", line)
        if len(normalize(line)) < LOCAL_ANSWER_MIN_SENTENCE:
            continue
        parts.append(_clean_evidence_line(line))
    return parts


def compose_local_answer(question, doc_answer, doc_sc, history=None):
    """외부 모델 없이 검색 근거와 규칙을 조합해 최종 답변을 생성."""
    history = history or []
    raw = _clean_evidence_line(doc_answer)
    if not raw:
        return None

    # 이미 진단/비교/연결 형식이면 기존 결과를 그대로 보존하되, 과도한 중복만 제거.
    if any(tag in raw for tag in ["🔍 진단 모드!", "비교해 볼게!", "두 지식을 연결해서 생각해 봤어!"]):
        return raw[:LOCAL_ANSWER_MAX_CHARS]

    evidence = _split_evidence(doc_answer)
    if not evidence:
        return raw[:LOCAL_ANSWER_MAX_CHARS]

    # 중복 문장 제거
    unique = []
    seen = set()
    for line in evidence:
        n = normalize(line)
        if not n or n in seen:
            continue
        if any(n in normalize(x) or normalize(x) in n for x in unique):
            continue
        seen.add(n)
        unique.append(line)
        if len(unique) >= LOCAL_ANSWER_MAX_EVIDENCE:
            break

    # 질문 의도에 따라 간단한 답변 프레임을 선택.
    q = question.strip()
    if any(w in q for w in ["뭐야", "무엇", "무슨", "설명", "알려줘"]):
        lead = f"찾아본 자료를 바탕으로 정리하면, {unique[0]}"
    elif any(w in q for w in ["어떻게", "방법", "만들", "수정", "고쳐", "해줘"]):
        lead = f"관련 자료를 기준으로 보면, {unique[0]}"
    elif any(w in q for w in ["왜", "원인", "이유"]):
        lead = f"관련 근거를 보면, {unique[0]}"
    else:
        lead = unique[0]

    rest = unique[1:]
    answer = lead
    if rest:
        answer += "\n\n추가로 관련된 내용은 " + " / ".join(rest) + ""

    # 신뢰도가 낮으면 확정적인 표현을 피한다.
    if doc_sc < HIGH_MATCH and not any(w in q for w in ["뭐야", "무엇", "설명"]):
        answer = "관련 자료를 찾았지만 확실한 근거는 제한적이야.\n\n" + answer

    # 최근 대화와 연결되는 짧은 질문이면 주제를 명시.
    if is_followup(q) and history:
        prev_user = [t for r, t in history if r == "user"][:-1]
        if prev_user:
            answer = f"아까 이야기하던 내용 기준으로 보면, {answer}"

    return answer[:LOCAL_ANSWER_MAX_CHARS]



def _token_set(text):
    """자기검증용 간단 토큰 집합. 조사/기호에 덜 민감하게 만든다."""
    t = normalize(str(text or ""))
    return {x for x in re.findall(r"[a-z0-9가-힣_+#.-]{2,}", t) if x not in {
        "관련", "자료", "내용", "보면", "기준", "정리하면", "찾아본", "알려줘"
    }}


def _claim_support(answer, evidence):
    """답변이 근거 문장들에 의해 얼마나 지지되는지 대략적인 점수."""
    a = _token_set(answer)
    if not a or not evidence:
        return 0.0
    ev = _token_set(" ".join(evidence))
    overlap = len(a & ev) / max(1, len(a))
    # 숫자/단위는 더 강하게 검증한다.
    nums_a = {m.group(0).lower() for m in re.finditer(r"[-+]?\d+(?:\.\d+)?\s*[a-zA-Z%가-힣]*", str(answer))}
    nums_e = {m.group(0).lower() for m in re.finditer(r"[-+]?\d+(?:\.\d+)?\s*[a-zA-Z%가-힣]*", " ".join(evidence))}
    if nums_a:
        overlap += 0.25 * (len(nums_a & nums_e) / len(nums_a))
    return max(0.0, min(1.0, overlap))


def _answer_conflicts_with_evidence(answer, evidence):
    """답변의 긍정/부정 또는 숫자 주장이 근거와 명백히 충돌하는지 검사."""
    an = normalize(answer)
    en = normalize(" ".join(evidence))
    if not an or not en:
        return True

    # 답변과 근거 사이의 명백한 부정/긍정 충돌
    ans_neg = any(normalize(w) in an for w in NEG_WORDS)
    ans_pos = any(normalize(w) in an for w in POS_WORDS)
    ev_neg = any(normalize(w) in en for w in NEG_WORDS)
    ev_pos = any(normalize(w) in en for w in POS_WORDS)
    if (ans_neg and ev_pos and not ev_neg) or (ans_pos and ev_neg and not ev_pos):
        return True

    # 숫자 주장이 근거에 전혀 없으면 위험 신호로 본다.
    nums_a = {m.group(0).lower() for m in re.finditer(r"[-+]?\d+(?:\.\d+)?\s*[a-zA-Z%가-힣]*", str(answer))}
    nums_e = {m.group(0).lower() for m in re.finditer(r"[-+]?\d+(?:\.\d+)?\s*[a-zA-Z%가-힣]*", " ".join(evidence))}
    if nums_a and not (nums_a & nums_e):
        return True
    return False


def verify_local_answer(question, answer, doc_answer, doc_sc):
    """자체 생성 답변을 다시 검사한다.

    결과: (검증된_답변, 검증점수, 이유, 수정여부)
    """
    raw_evidence = _split_evidence(doc_answer)
    if not raw_evidence:
        return None, 0.0, "근거가 없음", False

    support = _claim_support(answer, raw_evidence)
    conflict = _answer_conflicts_with_evidence(answer, raw_evidence)
    question_tokens = _token_set(question)
    answer_tokens = _token_set(answer)
    q_overlap = len(question_tokens & answer_tokens) / max(1, min(len(question_tokens), 8)) if question_tokens else 1.0

    score = 0.65 * support + 0.25 * max(0.0, min(1.0, doc_sc)) + 0.10 * max(0.0, min(1.0, q_overlap))
    if conflict:
        score -= 0.35
    score = max(0.0, min(1.0, score))

    if not conflict and score >= VERIFY_MIN_SUPPORT:
        note = "근거와 답변의 핵심 내용이 일치함"
        return answer, score, note, False

    # 검증 실패: 새로운 주장을 최소화하고 근거 중심 답변으로 보수적으로 재구성한다.
    fallback = _clean_evidence_line(raw_evidence[0])
    if len(raw_evidence) > 1:
        fallback += "\n\n추가 근거: " + " / ".join(raw_evidence[1: min(3, len(raw_evidence))])
    fallback = "자기검증 결과, 처음 답변에는 확실하지 않은 부분이 있어서 근거 중심으로 다시 정리했어.\n\n" + fallback
    fallback = fallback[:LOCAL_ANSWER_MAX_CHARS]
    reason = "근거 부족" if support < VERIFY_MIN_SUPPORT else "근거와 일부 충돌"
    if conflict:
        reason = "근거와 모순되는 주장 감지"
    return fallback, score, reason, True


def compose_and_verify_local_answer(question, doc_answer, doc_sc, history=None):
    """답변 생성 -> 자기검증 -> 필요하면 보수적 수정의 한 사이클."""
    generated = compose_local_answer(question, doc_answer, doc_sc, history)
    if not generated:
        return None, {"score": 0.0, "reason": "생성 실패", "repaired": False}
    verified, vscore, reason, repaired = verify_local_answer(question, generated, doc_answer, doc_sc)
    return verified or generated, {"score": vscore, "reason": reason, "repaired": repaired}


def _memory_category(text):
    t = normalize(text)
    if any(k in t for k in ["좋아", "싫어", "선호"]):
        return "preference"
    if any(k in t for k in ["프로젝트", "게임", "개발", "만들고"]):
        return "project"
    if any(k in t for k in ["이름", "내 목표", "목표", "나는", "내가"]):
        return "profile"
    return "fact"


def remember_long_term(text, source="conversation", importance=None):
    t = str(text or "").strip()
    if not t or len(normalize(t)) < 4:
        return False
    best = None; best_sc = 0.0
    for m in LONG_MEMORY:
        sc = score(t, str(m.get("text", "")))
        if sc > best_sc:
            best_sc, best = sc, m
    if best is not None and best_sc >= 0.82:
        best["text"] = t
        best["updated_at"] = datetime.now().isoformat(timespec="seconds")
        if importance is not None:
            best["importance"] = max(float(best.get("importance", 0.5)), float(importance))
        save_long_memory(); return True
    cat = _memory_category(t)
    if importance is None:
        importance = 0.9 if cat in ("profile", "project", "preference") else 0.55
    LONG_MEMORY.append({
        "text": t, "category": cat, "source": source,
        "importance": float(importance), "use_count": 0,
        "created_at": datetime.now().isoformat(timespec="seconds"),
        "updated_at": datetime.now().isoformat(timespec="seconds")
    })
    LONG_MEMORY.sort(key=lambda x: (float(x.get("importance", 0)), x.get("updated_at", "")), reverse=True)
    del LONG_MEMORY[500:]
    save_long_memory(); return True


def recall_long_term(query, limit=6):
    q = str(query or "").strip()
    if not q or not LONG_MEMORY:
        return []
    ranked = []
    for m in LONG_MEMORY:
        sc = 0.78 * score(q, str(m.get("text", ""))) + 0.22 * float(m.get("importance", 0.5))
        ranked.append((sc, m))
    ranked.sort(key=lambda x: x[0], reverse=True)
    out = []
    for sc, m in ranked[:limit]:
        if sc >= 0.18:
            m["use_count"] = int(m.get("use_count", 0)) + 1
            out.append((sc, m))
    if out: save_long_memory()
    return out


def long_memory_answer(query):
    hits = recall_long_term(query)
    if not hits: return None
    return "장기기억에서 관련 내용을 찾았어.\n\n" + "\n".join(
        f"- {m.get('text','')} (기억 신뢰도 {sc:.2f})" for sc, m in hits
    )


def create_plan(goal):
    global ACTIVE_PLAN
    g = str(goal or "").strip()
    if not g: return None
    if any(k in g for k in ["만들", "개발", "구현", "프로그램", "게임"]):
        steps = ["요구사항과 완료 조건 정리", "필요한 데이터·파일·구성요소 정의", "핵심 기능을 작은 단위로 구현", "기능 통합 및 예외 상황 확인", "테스트와 오류 수정", "완료 조건 최종 확인"]
    elif any(k in g for k in ["공부", "학습", "배우"]):
        steps = ["학습 목표와 현재 수준 정리", "핵심 개념 순서대로 학습", "예제와 문제로 적용", "틀린 부분 복습", "응용 문제 또는 작은 프로젝트로 확인"]
    elif any(k in g for k in ["분석", "비교", "조사"]):
        steps = ["분석 기준 정리", "관련 자료 수집", "출처 신뢰도와 충돌 검사", "차이점·공통점 정리", "결론과 불확실한 부분 구분"]
    else:
        steps = ["목표와 완료 조건 구체화", "필요한 정보와 준비물 확인", "작업을 작은 단계로 분할", "단계별 결과 검증", "완료 조건 확인"]
    ACTIVE_PLAN = {
        "goal": g, "keywords": extract_keywords(g)[:8],
        "created_at": datetime.now().isoformat(timespec="seconds"),
        "updated_at": datetime.now().isoformat(timespec="seconds"),
        "steps": [{"text": x, "done": False} for x in steps]
    }
    save_plan(); return ACTIVE_PLAN


def plan_text(plan=None):
    plan = plan or ACTIVE_PLAN
    if not plan: return "현재 진행 중인 계획이 없어."
    steps = plan.get("steps", [])
    done = sum(1 for s in steps if s.get("done"))
    lines = [f"계획: {plan.get('goal','')}", f"진행률: {done}/{len(steps)}"]
    lines += [f"{'✅' if x.get('done') else '⬜'} {i}. {x.get('text','')}" for i, x in enumerate(steps, 1)]
    return "\n".join(lines)


def plan_mark(step_no):
    global ACTIVE_PLAN
    if not ACTIVE_PLAN: return "현재 계획이 없어."
    try: idx = int(step_no) - 1
    except Exception: return "단계 번호를 숫자로 알려줘."
    steps = ACTIVE_PLAN.get("steps", [])
    if idx < 0 or idx >= len(steps): return "그 번호의 단계가 없어."
    steps[idx]["done"] = True
    ACTIVE_PLAN["updated_at"] = datetime.now().isoformat(timespec="seconds")
    save_plan(); return plan_text()


def handle_memory_plan_command(text):
    t = normalize(text)
    if t in ("장기기억", "장기 기억", "내 기억 보여줘", "기억 보여줘"):
        if not LONG_MEMORY: return "아직 장기기억에 저장된 내용이 없어."
        items = sorted(LONG_MEMORY, key=lambda x: (float(x.get("importance",0)), x.get("updated_at","")), reverse=True)[:12]
        return "장기기억\n\n" + "\n".join(f"- [{m.get('category','fact')}] {m.get('text','')}" for m in items)
    if t in ("기억 삭제", "장기기억 초기화"):
        LONG_MEMORY.clear(); save_long_memory(); return "장기기억을 비웠어."
    if t in ("계획", "현재 계획", "계획 보여줘", "진행 상황"):
        return plan_text()
    for prefix in ("계획 세워 ", "계획을 세워 ", "plan "):
        if text.startswith(prefix):
            p = create_plan(text[len(prefix):])
            return plan_text(p) if p else "무엇을 할 계획인지 알려줘."
    m = re.match(r"(?:단계|step)\s*(\d+)(?:\s*(?:완료|끝|done))?$", t)
    if m: return plan_mark(m.group(1))
    return None



# ──────────────────────────────────────────────
# v2.8 Unity 프로젝트 연동 엔진 (로컬 폴더 분석/안전 수정)
# ──────────────────────────────────────────────
PROJECT = {"path": None}
PROJECT_BACKUP_DIR = os.path.join(HERE, "ai_project_backups")
os.makedirs(PROJECT_BACKUP_DIR, exist_ok=True)

PROJECT_ALLOWED_EXT = {".cs", ".asmdef", ".asmref", ".json", ".uxml", ".uss", ".shader", ".cginc", ".hlsl", ".unity", ".prefab"}
PROJECT_IGNORED_DIRS = {"Library", "Temp", "Logs", "obj", "Build", "Builds", ".git", ".vs", "UserSettings"}

def choose_project_folder():
    """로컬 GUI로 Unity 프로젝트 폴더를 선택한다. 취소하면 기존 선택을 유지한다."""
    try:
        import tkinter as tk
        from tkinter import filedialog
        root = tk.Tk(); root.withdraw(); root.attributes('-topmost', True)
        path = filedialog.askdirectory(title='Unity 프로젝트 폴더를 선택하세요')
        root.destroy()
        if path:
            PROJECT["path"] = os.path.abspath(path)
            return PROJECT["path"]
    except Exception as e:
        return f"선택 창을 열지 못했어: {e}"
    return PROJECT.get("path") or ""

def _project_safe(path):
    root = PROJECT.get("path")
    if not root or not os.path.isdir(root): return False
    try:
        return os.path.commonpath([os.path.abspath(root), os.path.abspath(path)]) == os.path.abspath(root)
    except Exception:
        return False

def project_files(limit=5000):
    root=PROJECT.get("path")
    if not root or not os.path.isdir(root): return []
    out=[]
    for base, dirs, files in os.walk(root):
        dirs[:] = [d for d in dirs if d not in PROJECT_IGNORED_DIRS]
        for fn in files:
            ext=os.path.splitext(fn)[1].lower()
            if ext not in PROJECT_ALLOWED_EXT: continue
            full=os.path.join(base,fn)
            if _project_safe(full):
                out.append(full)
                if len(out)>=limit: return out
    return out

def project_scan():
    root=PROJECT.get("path")
    if not root or not os.path.isdir(root):
        return "먼저 '프로젝트 선택'이라고 말해서 Unity 프로젝트 폴더를 지정해줘."
    files=project_files()
    cs=[x for x in files if x.lower().endswith('.cs')]
    scenes=0; prefabs=0
    for base, dirs, fs in os.walk(root):
        dirs[:] = [d for d in dirs if d not in PROJECT_IGNORED_DIRS]
        for fn in fs:
            low=fn.lower()
            if low.endswith('.unity'): scenes+=1
            elif low.endswith('.prefab'): prefabs+=1
    findings=[]
    for f in cs[:1500]:
        try:
            text=Path(f).read_text(encoding='utf-8', errors='replace')
            a=analyze_csharp_code(text)
            if a and '정적 검사에서 뚜렷한 문제' not in a:
                rel=os.path.relpath(f,root)
                findings.append((rel,a.split('\n',1)[0]))
        except Exception:
            continue
    lines=[f"프로젝트: {root}",f"분석 가능한 코드/설정 파일: {len(files)}개",f"C# 파일: {len(cs)}개 · Scene: {scenes}개 · Prefab: {prefabs}개"]
    if findings:
        lines.append(f"정적 분석에서 확인된 파일: {len(findings)}개")
        lines.extend(f"- {rel}: {summary}" for rel,summary in findings[:40])
        if len(findings)>40: lines.append(f"... 외 {len(findings)-40}개")
    else:
        lines.append("현재 정적 분석에서 눈에 띄는 문제를 찾지 못했어.")
    return "\n".join(lines)

def project_read(relpath):
    root=PROJECT.get("path")
    if not root: return "프로젝트가 선택되지 않았어."
    full=os.path.abspath(os.path.join(root, relpath))
    if not _project_safe(full) or not os.path.isfile(full): return "프로젝트 안의 파일만 읽을 수 있어."
    if os.path.splitext(full)[1].lower() not in PROJECT_ALLOWED_EXT: return "허용된 Unity/C# 파일만 읽을 수 있어."
    try:
        data=Path(full).read_text(encoding='utf-8', errors='replace')
        if len(data)>60000: data=data[:60000] + "\n... (60,000자까지만 표시)"
        return f"파일: {relpath}\n\n{data}"
    except Exception as e: return f"파일을 읽지 못했어: {e}"

def _backup_file(full):
    stamp=time.strftime('%Y%m%d_%H%M%S')
    rel=os.path.relpath(full, PROJECT["path"])
    dest=os.path.join(PROJECT_BACKUP_DIR, stamp, rel)
    os.makedirs(os.path.dirname(dest), exist_ok=True)
    shutil.copy2(full,dest)
    return dest

def project_apply_safe_fix(relpath, fix_kind):
    """결정론적이고 제한된 자동수정만 허용한다. 항상 백업 후 쓰기."""
    root=PROJECT.get("path")
    if not root: return "프로젝트가 선택되지 않았어."
    full=os.path.abspath(os.path.join(root, relpath))
    if not _project_safe(full) or not os.path.isfile(full): return "프로젝트 안의 파일만 수정할 수 있어."
    if not full.lower().endswith('.cs'): return "자동 수정은 현재 .cs 파일만 지원해."
    try:
        code=Path(full).read_text(encoding='utf-8', errors='replace')
        fixed=code; changes=[]
        if fix_kind == 'add_unity_using' and 'MonoBehaviour' in fixed and 'using UnityEngine;' not in fixed:
            fixed='using UnityEngine;\n'+fixed; changes.append('using UnityEngine; 추가')
        elif fix_kind == 'strip_bom':
            cleaned=fixed.replace('\ufeff','')
            if cleaned != fixed: fixed=cleaned; changes.append('BOM 제거')
        else:
            return "지원하지 않는 자동 수정이야."
        if fixed == code: return "변경할 내용이 없었어."
        backup=_backup_file(full)
        Path(full).write_text(fixed,encoding='utf-8',newline='')
        return f"수정 완료: {relpath}\n변경: {', '.join(changes)}\n백업: {os.path.relpath(backup, HERE)}"
    except Exception as e:
        return f"수정 중 오류: {e}"

def _unity_candidates():
    c=[]
    if UNITY_EDITOR_PATH: c.append(UNITY_EDITOR_PATH)
    if os.name == "nt":
        c += [r"C:\Program Files\Unity\Hub\Editor", r"C:\Program Files\Unity Hub\Unity Hub.exe"]
    else:
        c += ["/usr/bin/Unity", "/opt/Unity/Editor/Unity", "/usr/bin/unity"]
    return c

def detect_unity_editor():
    p = _find_executable(["Unity.exe", "Unity", "unity"])
    if p: return p
    for base in _unity_candidates():
        if os.path.isfile(base) and "hub" not in os.path.basename(base).lower(): return base
        if os.path.isdir(base):
            try:
                choices=[]
                for root, dirs, files in os.walk(base):
                    for fn in files:
                        if fn.lower() in ("unity.exe", "unity"):
                            choices.append(os.path.join(root,fn))
                    if len(choices)>10: break
                if choices: return sorted(choices, reverse=True)[0]
            except Exception:
                pass
    return None

def unity_project_ok():
    root=PROJECT.get("path")
    return bool(root and os.path.isdir(root) and os.path.isdir(os.path.join(root,"Assets")) and os.path.isdir(os.path.join(root,"ProjectSettings")))

def ensure_unity_bridge():
    root=PROJECT.get("path")
    if not unity_project_ok(): return "유효한 Unity 프로젝트가 선택되지 않았어."
    editor_dir=os.path.join(root,"Assets","Editor")
    os.makedirs(editor_dir, exist_ok=True)
    bridge=os.path.join(editor_dir,"AIProjectBridge.cs")
    new=UNITY_BRIDGE_CS
    if os.path.exists(bridge):
        try: old=Path(bridge).read_text(encoding="utf-8",errors="replace")
        except Exception: old=""
        if old != new:
            _backup_file(bridge)
    Path(bridge).write_text(new,encoding="utf-8")
    return bridge

def _write_unity_action(action):
    root=PROJECT.get("path")
    path=os.path.join(root,"Library","ai_project_action.json")
    os.makedirs(os.path.dirname(path),exist_ok=True)
    tmp=path+".tmp"
    Path(tmp).write_text(json.dumps(action,ensure_ascii=False,indent=2),encoding="utf-8")
    os.replace(tmp,path)
    return path

def _run_unity_batch(action, timeout=180):
    root=PROJECT.get("path")
    if not unity_project_ok(): return {"ok":False,"message":"유효한 Unity 프로젝트가 아니야."}
    ensure_unity_bridge()
    exe=detect_unity_editor()
    if not exe: return {"ok":False,"message":"Unity Editor를 찾지 못했어. UNITY_EDITOR_PATH 환경변수에 Unity.exe 경로를 지정해줘."}
    _write_unity_action(action)
    import subprocess
    cmd=[exe,"-batchmode","-quit","-projectPath",root,"-executeMethod","AIProjectBridge.Execute","-logFile","-"]
    try:
        proc=subprocess.run(cmd,capture_output=True,text=True,timeout=timeout)
        out=(proc.stdout or "")+"\n"+(proc.stderr or "")
        return {"ok":proc.returncode==0,"returncode":proc.returncode,"output":out[-10000:],"message":"Unity 작업 완료" if proc.returncode==0 else "Unity 작업 실패"}
    except subprocess.TimeoutExpired: return {"ok":False,"message":"Unity 작업 시간 초과"}
    except Exception as e: return {"ok":False,"message":f"Unity 실행 오류: {e}"}

def unity_open_editor():
    root=PROJECT.get("path")
    if not unity_project_ok(): return "먼저 유효한 Unity 프로젝트를 선택해줘."
    exe=detect_unity_editor()
    if not exe: return "Unity Editor를 찾지 못했어. UNITY_EDITOR_PATH 환경변수에 Unity.exe 경로를 지정해줘."
    import subprocess
    try:
        subprocess.Popen([exe,"-projectPath",root], stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
        return f"✅ Unity Editor 실행: {root}"
    except Exception as e: return f"Unity Editor 실행 실패: {e}"

def unity_create_script(relpath, code):
    if not unity_project_ok(): return "먼저 Unity 프로젝트를 선택해줘."
    rel=relpath.replace("\\","/").lstrip("/")
    if not rel.lower().startswith("assets/"): rel="Assets/"+rel
    if not rel.lower().endswith(".cs"): rel += ".cs"
    full=os.path.abspath(os.path.join(PROJECT["path"],rel))
    if not _project_safe(full): return "프로젝트 밖에는 스크립트를 만들 수 없어."
    if os.path.exists(full): return "같은 경로의 스크립트가 이미 있어. 덮어쓰기는 막아뒀어."
    vr=verify_csharp(code,auto_fix=True,rounds=VERIFY_MAX_ROUNDS)
    if not vr.get("ok") and not vr.get("needs_toolchain"): return "코드 검증 실패라 생성하지 않았어.\n\n"+format_verification_result(vr)
    result=_run_unity_batch({"action":"create_script","scriptPath":rel,"scriptText":vr.get("code",code)})
    return f"✅ Unity 프로젝트에 스크립트 생성 완료: {rel}" if result.get("ok") else "Unity 스크립트 생성 실패: "+result.get("message","")

def unity_create_gameobject(name):
    if not unity_project_ok(): return "먼저 Unity 프로젝트를 선택해줘."
    result=_run_unity_batch({"action":"create_gameobject","gameObjectName":str(name).strip()})
    return "✅ GameObject 생성 완료: "+str(name) if result.get("ok") else "GameObject 생성 실패: "+result.get("message","")

def unity_add_component(object_name, component_type):
    if not unity_project_ok(): return "먼저 Unity 프로젝트를 선택해줘."
    result=_run_unity_batch({"action":"add_component","gameObjectName":object_name.strip(),"componentType":component_type.strip()})
    return f"✅ {object_name}에 {component_type} 추가 완료" if result.get("ok") else "컴포넌트 추가 실패: "+result.get("message","")

def unity_save_scene():
    if not unity_project_ok(): return "먼저 Unity 프로젝트를 선택해줘."
    result=_run_unity_batch({"action":"save_scene"})
    return "✅ 현재 씬 저장 완료" if result.get("ok") else "씬 저장 실패: "+result.get("message","")

def unity_open_scene(scene_path):
    if not unity_project_ok(): return "먼저 Unity 프로젝트를 선택해줘."
    p=scene_path.replace("\\","/")
    if not p.lower().startswith("assets/"): p="Assets/"+p
    full=os.path.abspath(os.path.join(PROJECT["path"],p))
    if not _project_safe(full) or not os.path.isfile(full) or not p.lower().endswith(".unity"): return "프로젝트 안의 .unity 씬만 열 수 있어."
    result=_run_unity_batch({"action":"open_scene","scenePath":p})
    return f"✅ 씬 열기 완료: {p}" if result.get("ok") else "씬 열기 실패: "+result.get("message","")

# ──────────────────────────────────────────────
# v3.0 Scene Intelligence + Multi-step Unity Plan Engine
# ──────────────────────────────────────────────
UNITY_PLAN = {"goal": None, "steps": [], "approved": False}

def _read_unity_result():
    root=PROJECT.get("path")
    if not root: return {"ok":False,"message":"project not selected"}
    path=os.path.join(root,"Library","ai_project_result.json")
    for _ in range(20):
        if os.path.isfile(path):
            try:
                data=json.loads(Path(path).read_text(encoding="utf-8", errors="replace"))
                try: os.remove(path)
                except Exception: pass
                return data
            except Exception:
                time.sleep(0.05)
        time.sleep(0.05)
    return {"ok":False,"message":"Unity did not return a result"}

def _run_unity_batch_and_read(action, timeout=180):
    result=_run_unity_batch(action, timeout=timeout)
    if not result.get("ok"):
        return result
    detail=_read_unity_result()
    if detail.get("message"):
        result["bridge_message"]=detail.get("message")
        result["ok"]=bool(detail.get("ok", result.get("ok")))
    return result

def unity_scan_scene():
    if not unity_project_ok(): return "먼저 Unity 프로젝트를 선택해줘."
    r=_run_unity_batch_and_read({"action":"scan_scene"})
    if not r.get("ok"):
        return "Scene 분석 실패: " + r.get("message", "알 수 없는 오류")
    msg=r.get("bridge_message", "")
    return "현재 Scene 구조:\n" + (msg or "(비어 있음)")

def unity_find_object(name):
    if not unity_project_ok(): return "먼저 Unity 프로젝트를 선택해줘."
    r=_run_unity_batch_and_read({"action":"find_object","gameObjectName":name.strip()})
    if not r.get("ok"):
        return "GameObject 검색 실패: " + r.get("message", "")
    return "GameObject 정보:\n" + r.get("bridge_message", "NOT_FOUND")

def _plan_for_goal(goal):
    g=normalize(goal)
    steps=[]
    # Deterministic, whitelist-only plans. The AI does not invent arbitrary Unity API calls.
    if "플레이어" in g and any(k in g for k in ("만들", "생성", "구성")):
        steps=[
            {"action":"create_gameobject","gameObjectName":"Player","label":"Player GameObject 생성"},
            {"action":"add_component","gameObjectName":"Player","componentType":"Rigidbody","label":"Rigidbody 추가"},
            {"action":"add_component","gameObjectName":"Player","componentType":"CapsuleCollider","label":"CapsuleCollider 추가"},
        ]
        if "스크립트" in g or "이동" in g:
            code='using UnityEngine;\n\npublic class PlayerController : MonoBehaviour\n{\n    [SerializeField] private float moveSpeed = 5f;\n    private void Update()\n    {\n        float x = Input.GetAxisRaw("Horizontal");\n        float z = Input.GetAxisRaw("Vertical");\n        Vector3 dir = new Vector3(x, 0f, z).normalized;\n        transform.position += dir * moveSpeed * Time.deltaTime;\n    }\n}'
            steps.append({"action":"create_script","scriptPath":"Assets/Scripts/PlayerController.cs","scriptText":code,"label":"PlayerController.cs 생성"})
        steps.append({"action":"save_scene","label":"Scene 저장"})
        return steps
    if "캐릭터" in g and "리지드바디" in g:
        return [
            {"action":"create_gameobject","gameObjectName":"Character","label":"Character 생성"},
            {"action":"add_component","gameObjectName":"Character","componentType":"Rigidbody","label":"Rigidbody 추가"},
            {"action":"add_component","gameObjectName":"Character","componentType":"CapsuleCollider","label":"CapsuleCollider 추가"},
            {"action":"save_scene","label":"Scene 저장"},
        ]
    return None

def create_unity_plan(goal):
    steps=_plan_for_goal(goal)
    if not steps:
        return "아직 자동화된 안전 계획 템플릿이 없는 목표야. 현재 v3.0은 허용된 Unity 작업만 계획해."
    UNITY_PLAN["goal"]=goal.strip(); UNITY_PLAN["steps"]=steps; UNITY_PLAN["approved"]=False
    lines=[f"계획: {goal.strip()}", "", "실행 예정 작업:"]
    for i,st in enumerate(steps,1): lines.append(f"{i}. {st.get('label', st['action'])}")
    lines.append("", "실제로 실행하려면: '유니티계획 실행'이라고 입력해줘.")
    return "\n".join(lines)

def execute_unity_plan():
    if not UNITY_PLAN.get("steps"):
        return "먼저 '유니티계획: ...'으로 계획을 만들어줘."
    if not unity_project_ok(): return "먼저 Unity 프로젝트를 선택해줘."
    results=[]
    # Each step is whitelisted and executed sequentially; stop on first failure.
    for i,st in enumerate(UNITY_PLAN["steps"],1):
        action={k:v for k,v in st.items() if k not in ("label",)}
        r=_run_unity_batch_and_read(action, timeout=180)
        if r.get("ok"):
            results.append(f"✅ {i}. {st.get('label',st['action'])}")
        else:
            results.append(f"❌ {i}. {st.get('label',st['action'])}: {r.get('message','실패')}")
            results.append("실패한 단계에서 실행을 중단했어.")
            UNITY_PLAN["approved"]=False
            return "\n".join(results)
    UNITY_PLAN["approved"]=False
    return "\n".join(results) + "\n\n✅ 계획 전체 실행 완료"

def handle_v30_unity_command(text):
    t=str(text or '').strip()
    n=normalize(t)
    if n in ('씬구조분석','유니티씬분석','현재씬분석','씬분석'):
        return unity_scan_scene()
    m=re.match(r'(?:게임오브젝트찾기|유니티오브젝트찾기)\s*[:：]?\s*(.+)$', t, re.I)
    if m: return unity_find_object(m.group(1).strip())
    m=re.match(r'유니티계획\s*[:：]\s*(.+)$', t, re.I)
    if m: return create_unity_plan(m.group(1).strip())
    if n in ('유니티계획실행','계획실행'):
        return execute_unity_plan()
    return None

def handle_unity_direct_command(text):
    n=normalize(text)
    if n in ("유니티열기","unity열기","에디터열기","유니티에디터열기"): return unity_open_editor()
    if n in ("유니티브리지설치","유니티연결설치"): return f"✅ Unity 직접 조작 브리지 설치 완료: {ensure_unity_bridge()}"
    if n in ("씬저장","유니티씬저장","현재씬저장"): return unity_save_scene()
    m=re.match(r"유니티스크립트생성\s*[:：]?\s*(.+?)\s*\n```(?:csharp|cs)?\s*([\s\S]*?)```$",text,re.I)
    if m: return unity_create_script(m.group(1).strip(),m.group(2).strip())
    m=re.match(r"유니티게임오브젝트생성\s*[:：]?\s*(.+)$",text,re.I)
    if m: return unity_create_gameobject(m.group(1))
    m=re.match(r"유니티컴포넌트추가\s*[:：]?\s*(.+?)\s*=>\s*(.+)$",text,re.I)
    if m: return unity_add_component(m.group(1),m.group(2))
    m=re.match(r"유니티씬열기\s*[:：]?\s*(.+)$",text,re.I)
    if m: return unity_open_scene(m.group(1))
    return None

def handle_project_command(text):
    t=normalize(text)
    if t in ('프로젝트 선택','유니티 프로젝트 선택','프로젝트 폴더 선택'):
        path=choose_project_folder()
        return f"Unity 프로젝트 선택됨: {path}" if path else "프로젝트 선택을 취소했어."
    if t in ('프로젝트 분석','유니티 프로젝트 분석','프로젝트 검사'):
        return project_scan()
    if t in ('프로젝트 경로','선택한 프로젝트'):
        return PROJECT.get('path') or '선택된 프로젝트가 없어.'
    m=re.match(r'프로젝트 파일 읽기\s*[:：]?\s*(.+)$', text, re.I)
    if m: return project_read(m.group(1).strip())
    m=re.match(r'프로젝트 수정 승인\s*[:：]?\s*(.+?)\s+add_unity_using$', text, re.I)
    if m: return project_apply_safe_fix(m.group(1).strip(),'add_unity_using')
    m=re.match(r'프로젝트 수정 승인\s*[:：]?\s*(.+?)\s+strip_bom$', text, re.I)
    if m: return project_apply_safe_fix(m.group(1).strip(),'strip_bom')
    return None

# v3.1 Unity Project Graph Intelligence
PROJECT_GRAPH_FILE = os.path.join(HERE, "ai_project_graph.json")
PROJECT_GRAPH_VERSION = "3.1"
PROJECT_GRAPH = {"version": PROJECT_GRAPH_VERSION, "project": None, "nodes": [], "edges": [], "stats": {}}

def _read_small(path, limit=2000000):
    try: return Path(path).read_text(encoding="utf-8", errors="replace")[:limit]
    except Exception: return ""

def _rel(root, path): return os.path.relpath(path, root).replace(os.sep, "/")

def _project_guid_map(root):
    out={}
    for base,dirs,files in os.walk(root):
        dirs[:]=[d for d in dirs if d not in PROJECT_IGNORED_DIRS]
        for fn in files:
            if not fn.endswith('.meta'): continue
            full=os.path.join(base,fn)
            m=re.search(r'^guid:\s*([0-9a-fA-F]{32})\s*$',_read_small(full,64000),re.M)
            asset=os.path.join(base,fn[:-5])
            if m and os.path.isfile(asset): out[m.group(1)] = _rel(root,asset)
    return out

def build_project_graph(save=True):
    global PROJECT_GRAPH
    root=PROJECT.get('path')
    if not root or not os.path.isdir(root): return {"ok":False,"message":"먼저 Unity 프로젝트를 선택해줘."}
    guid_map=_project_guid_map(root); nodes={}; edges=[]; seen=set(); stats=Counter()
    rev={v:k for k,v in guid_map.items()}
    def add_node(kind,key,**meta):
        nid=f'{kind}:{key}'; nodes.setdefault(nid,{"id":nid,"kind":kind,"key":key}); nodes[nid].update(meta); return nid
    def add_edge(a,b,rel):
        key=(a,b,rel)
        if a and b and a!=b and key not in seen: seen.add(key); edges.append({"from":a,"to":b,"relation":rel})
    for guid,rel in guid_map.items():
        ext=os.path.splitext(rel)[1].lower(); kind={'.cs':'script','.unity':'scene','.prefab':'prefab'}.get(ext,'asset')
        add_node(kind,rel,path=rel,guid=guid); stats[kind]+=1
    for rel in list(guid_map.values()):
        ext=os.path.splitext(rel)[1].lower(); full=os.path.join(root,rel)
        if ext=='.cs':
            src=add_node('script',rel,path=rel,guid=rev.get(rel)); code=_read_small(full)
            for cls in re.findall(r'\bclass\s+([A-Za-z_]\w*)',code): add_edge(src,add_node('type',cls),'defines')
            for typ in re.findall(r'GetComponent(?:InChildren|InParent)?<\s*([A-Za-z_]\w*)\s*>',code): add_edge(src,add_node('type',typ),'uses_component')
            for typ in re.findall(r'AddComponent<\s*([A-Za-z_]\w*)\s*>',code): add_edge(src,add_node('type',typ),'adds_component')
            for ns in re.findall(r'^\s*using\s+([A-Za-z_][\w.]*)\s*;',code,re.M): add_edge(src,add_node('namespace',ns),'uses_namespace')
        elif ext in ('.unity','.prefab'):
            kind='scene' if ext=='.unity' else 'prefab'; src=add_node(kind,rel,path=rel,guid=rev.get(rel)); text=_read_small(full)
            for name in re.findall(r'^\s*m_Name:\s*(.*)$',text,re.M)[:2000]:
                name=name.strip()
                if name: add_edge(src,add_node('gameobject',f'{rel}::{name}',name=name,asset=rel),'contains')
            for guid in set(re.findall(r'guid:\s*([0-9a-fA-F]{32})',text)):
                asset=guid_map.get(guid)
                if not asset: continue
                k={'.cs':'script','.prefab':'prefab','.unity':'scene'}.get(os.path.splitext(asset)[1].lower(),'asset')
                add_edge(src,add_node(k,asset,path=asset,guid=guid),'uses_script' if k=='script' else 'references_asset')
    stats.update(nodes=len(nodes),edges=len(edges),scripts=sum(n['kind']=='script' for n in nodes.values()),scenes=sum(n['kind']=='scene' for n in nodes.values()),prefabs=sum(n['kind']=='prefab' for n in nodes.values()),gameobjects=sum(n['kind']=='gameobject' for n in nodes.values()))
    PROJECT_GRAPH={"version":PROJECT_GRAPH_VERSION,"project":root,"nodes":list(nodes.values()),"edges":edges,"stats":dict(stats),"built_at":datetime.now().isoformat(timespec='seconds')}
    if save: _save_obj(PROJECT_GRAPH_FILE,PROJECT_GRAPH)
    return {"ok":True,"graph":PROJECT_GRAPH}

def project_graph_analyze():
    r=build_project_graph(True)
    if not r.get('ok'): return r.get('message','')
    st=r['graph']['stats']
    return f"프로젝트 그래프 v3.1\n노드 {st['nodes']} · 연결 {st['edges']}\nC# {st['scripts']} · Scene {st['scenes']} · Prefab {st['prefabs']} · GameObject {st['gameobjects']}\n저장: {PROJECT_GRAPH_FILE}"

def project_graph_related(term):
    r=build_project_graph(True)
    if not r.get('ok'): return r.get('message','')
    g=r['graph']; q=normalize(term); nodes={n['id']:n for n in g['nodes']}
    seeds=[n for n in g['nodes'] if q in normalize(str(n.get('path',n.get('name',n.get('key','')))))]
    if not seeds: return f"'{term}' 관련 항목을 찾지 못했어."
    adj={}
    for e in g['edges']: adj.setdefault(e['from'],[]).append(e); adj.setdefault(e['to'],[]).append(e)
    lines=[f"'{term}' 관련 프로젝트 관계"]
    for n in seeds[:8]:
        lines.append(f"\n[{n['kind']}] {n.get('path') or n.get('name') or n.get('key')}")
        for e in adj.get(n['id'],[])[:15]:
            other=e['to'] if e['from']==n['id'] else e['from']; on=nodes.get(other,{})
            lines.append(f"- {e['relation']}: {on.get('path') or on.get('name') or on.get('key')}")
    return "\n".join(lines)

def handle_project_graph_command(text):
    t=str(text or '').strip(); n=normalize(t)
    if n in ('프로젝트그래프분석','유니티프로젝트그래프','프로젝트관계분석','프로젝트구조그래프'): return project_graph_analyze()
    m=re.match(r'(?:프로젝트관계|관련있는것|프로젝트연결)\s*[:：]?\s*(.+)$',t,re.I)
    if m: return project_graph_related(m.group(1).strip())
    m=re.match(r'(?:스크립트관계|스크립트연결)\s*[:：]?\s*(.+)$',t,re.I)
    if m: return project_graph_related(m.group(1).strip())
    return None



# v3.2 Unity Project Impact Analysis
PROJECT_GRAPH_VERSION = "3.2"

def _graph_neighbors(graph):
    adj = {}
    for e in graph.get("edges", []):
        a, b = e.get("from"), e.get("to")
        if not a or not b:
            continue
        adj.setdefault(a, []).append((b, e.get("relation", "related"), "out"))
        adj.setdefault(b, []).append((a, e.get("relation", "related"), "in"))
    return adj


def _graph_node_label(node):
    return node.get("path") or node.get("name") or node.get("key") or node.get("id", "")


def _find_graph_seeds(graph, term):
    q = normalize(term)
    exact = []
    fuzzy = []
    for n in graph.get("nodes", []):
        text = normalize(" ".join(str(n.get(k, "")) for k in ("path", "name", "key", "id")))
        if not text:
            continue
        if q and q in text:
            exact.append(n)
        else:
            toks = [t for t in re.findall(r"[0-9A-Za-z_가-힣]+", q) if len(t) >= 2]
            hits = sum(1 for t in toks if t in text)
            if hits:
                fuzzy.append((hits, n))
    if exact:
        return exact[:12]
    fuzzy.sort(key=lambda x: (-x[0], _graph_node_label(x[1])))
    return [n for _, n in fuzzy[:12]]


def project_impact_analysis(term, depth=3):
    r = build_project_graph(True)
    if not r.get("ok"):
        return r.get("message", "")
    graph = r["graph"]
    nodes = {n["id"]: n for n in graph.get("nodes", [])}
    seeds = _find_graph_seeds(graph, term)
    if not seeds:
        return f"'{term}' 관련 프로젝트 항목을 찾지 못했어."

    adj = _graph_neighbors(graph)
    dist = {}
    parent = {}
    queue = []
    for n in seeds:
        nid = n["id"]
        dist[nid] = 0
        queue.append(nid)

    qi = 0
    while qi < len(queue):
        cur = queue[qi]; qi += 1
        d = dist[cur]
        if d >= depth:
            continue
        for other, rel, direction in adj.get(cur, []):
            if other in dist:
                continue
            dist[other] = d + 1
            parent[other] = (cur, rel, direction)
            queue.append(other)

    affected = [nodes[nid] for nid, d in dist.items() if d > 0]
    # 직접 영향이 큰 관계부터, 그 다음 거리/종류 순으로 정렬
    priority = {
        "scene": 0, "prefab": 1, "script": 2, "gameobject": 3,
        "type": 4, "namespace": 5, "asset": 6
    }
    affected.sort(key=lambda n: (dist.get(n["id"], 99), priority.get(n.get("kind"), 9), _graph_node_label(n)))

    by_kind = Counter(n.get("kind", "unknown") for n in affected)
    direct = [n for n in affected if dist.get(n["id"]) == 1]
    scenes = [n for n in affected if n.get("kind") == "scene"]
    prefabs = [n for n in affected if n.get("kind") == "prefab"]
    scripts = [n for n in affected if n.get("kind") == "script"]

    lines = [f"프로젝트 영향도 분석 v3.2: {term}",
             f"시작점: {', '.join(_graph_node_label(n) for n in seeds[:6])}",
             f"탐색 깊이: {depth} · 영향 노드: {len(affected)}"]

    if direct:
        lines.append("\n[직접 영향]")
        for n in direct[:20]:
            lines.append(f"- {n.get('kind')}: {_graph_node_label(n)}")

    if scripts:
        lines.append("\n[영향받을 수 있는 C# 스크립트]")
        for n in scripts[:25]:
            lines.append(f"- 거리 {dist[n['id']]}: {_graph_node_label(n)}")

    if scenes:
        lines.append("\n[영향받을 수 있는 Scene]")
        for n in scenes[:20]:
            lines.append(f"- {_graph_node_label(n)}")

    if prefabs:
        lines.append("\n[영향받을 수 있는 Prefab]")
        for n in prefabs[:20]:
            lines.append(f"- {_graph_node_label(n)}")

    if by_kind:
        summary = ", ".join(f"{k} {v}" for k, v in sorted(by_kind.items(), key=lambda x: priority.get(x[0], 9)))
        lines.append(f"\n[요약] {summary}")

    lines.append("\n[주의]")
    lines.append("이 결과는 프로젝트 그래프에 기록된 관계를 기반으로 한 영향도 추정이야."
                 " 실제 런타임 참조(Reflection, Addressables, 문자열 로드 등)는 별도 검사가 필요해.")
    return "\n".join(lines)


def project_dependency_path(a_term, b_term, max_depth=6):
    r = build_project_graph(True)
    if not r.get("ok"):
        return r.get("message", "")
    graph = r["graph"]
    nodes = {n["id"]: n for n in graph.get("nodes", [])}
    a_seeds = _find_graph_seeds(graph, a_term)
    b_seeds = _find_graph_seeds(graph, b_term)
    if not a_seeds or not b_seeds:
        return f"경로를 찾을 항목을 모두 찾지는 못했어: {a_term} / {b_term}"
    targets = {n["id"] for n in b_seeds}
    adj = _graph_neighbors(graph)
    from collections import deque
    q = deque((n["id"], [n["id"]]) for n in a_seeds)
    seen = {n["id"] for n in a_seeds}
    while q:
        cur, path = q.popleft()
        if len(path) - 1 >= max_depth:
            continue
        if cur in targets:
            labels = [_graph_node_label(nodes[x]) for x in path if x in nodes]
            return "의존 관계 경로:\n" + " -> ".join(labels)
        for other, _, _ in adj.get(cur, []):
            if other in seen:
                continue
            seen.add(other)
            q.append((other, path + [other]))
    return f"{a_term}에서 {b_term}까지의 짧은 프로젝트 그래프 경로를 찾지 못했어."


def handle_project_impact_command(text):
    t = str(text or '').strip()
    m = re.match(r'(?:영향도분석|프로젝트영향도|영향분석)\s*[:：]?\s*(.+)$', t, re.I)
    if m:
        target = m.group(1).strip()
        dm = re.search(r'(.+?)\s+(?:깊이|depth)\s*(\d+)\s*$', target, re.I)
        depth = 3
        if dm:
            target = dm.group(1).strip()
            depth = max(1, min(6, int(dm.group(2))))
        return project_impact_analysis(target, depth=depth)
    m = re.match(r'(?:프로젝트경로|의존경로|관계경로)\s*[:：]?\s*(.+?)\s*(?:->|→|에서)\s*(.+)$', t, re.I)
    if m:
        return project_dependency_path(m.group(1).strip(), m.group(2).strip())
    return None

# ──────────────────────────────────────────────
# v3.3 Change Impact Test Planner
# ──────────────────────────────────────────────
V33_TEST_PLAN_FILE = os.path.join(HERE, "ai_change_test_plan.json")
CHANGE_TEST_PLAN = {"version":"3.3","target":None,"created_at":None,"tests":[],"status":"draft"}

def _save_change_test_plan():
    _save_obj(V33_TEST_PLAN_FILE, CHANGE_TEST_PLAN)

def _load_change_test_plan():
    global CHANGE_TEST_PLAN
    obj = _load_obj(V33_TEST_PLAN_FILE, None)
    if isinstance(obj, dict): CHANGE_TEST_PLAN = obj
    return CHANGE_TEST_PLAN

def _make_test_case(title, kind, target="", priority=3, action="inspect"):
    return {"title":title,"kind":kind,"target":target,"priority":priority,"action":action,"status":"pending","result":""}

def create_change_test_plan(target):
    root=PROJECT.get('path')
    if not root or not os.path.isdir(root): return "먼저 '프로젝트 선택'으로 Unity 프로젝트를 선택해줘."
    r=build_project_graph(True)
    if not r.get('ok'): return r.get('message','')
    g=r['graph']; nodes={n['id']:n for n in g.get('nodes',[])}; seeds=_find_graph_seeds(g,target)
    if not seeds: return f"'{target}' 관련 프로젝트 항목을 찾지 못했어."
    adj=_graph_neighbors(g); dist={}; q=[]
    for n in seeds: dist[n['id']]=0; q.append(n['id'])
    qi=0
    while qi<len(q):
        cur=q[qi]; qi+=1
        if dist[cur]>=3: continue
        for other,rel,direction in adj.get(cur,[]):
            if other not in dist: dist[other]=dist[cur]+1; q.append(other)
    tests=[_make_test_case('변경 대상/백업 기준 확인','baseline',target,1,'check_target')]
    for nid,d in sorted(dist.items(), key=lambda x:(x[1],_graph_node_label(nodes.get(x[0],{})))):
        if d==0: continue
        n=nodes.get(nid,{}); label=_graph_node_label(n); kind=n.get('kind')
        if kind=='script':
            tests.append(_make_test_case(f'C# 정적 검사: {label}','compile_static',label,1 if d==1 else 2,'analyze_csharp'))
            tests.append(_make_test_case(f'스크립트 관계 확인: {label}','dependency',label,2,'graph_related'))
            full=os.path.join(root,n.get('path','')); code=_read_small(full) if os.path.isfile(full) else ''
            if 'Update(' in code or 'FixedUpdate(' in code: tests.append(_make_test_case(f'프레임 루프 점검: {label}','runtime_logic',label,2,'inspect'))
            if any(x in code for x in ('OnCollision','OnTrigger','Physics.')): tests.append(_make_test_case(f'물리/충돌 경로 점검: {label}','physics',label,1,'inspect'))
            if 'Animator' in code or 'Animation' in code: tests.append(_make_test_case(f'애니메이션 경로 점검: {label}','animation',label,2,'inspect'))
            if 'Input.' in code or 'InputSystem' in code: tests.append(_make_test_case(f'입력 경로 점검: {label}','input',label,2,'inspect'))
        elif kind=='prefab': tests.append(_make_test_case(f'Prefab 존재/참조 확인: {label}','prefab',label,1 if d==1 else 2,'asset'))
        elif kind=='scene': tests.append(_make_test_case(f'Scene 구조 확인: {label}','scene',label,1,'scene'))
        elif kind=='gameobject': tests.append(_make_test_case(f'GameObject 존재 확인: {label}','gameobject',label,2,'object'))
    if _unity_project_has_tests(root):
        tests.append(_make_test_case('Unity EditMode 테스트 실행','unity_editmode',target,1,'unity_editmode_tests'))
        tests.append(_make_test_case('Unity PlayMode 테스트 실행','unity_playmode',target,2,'unity_playmode_tests'))

    seen=set(); unique=[]
    for t in sorted(tests,key=lambda x:(x['priority'],x['title'])):
        if t['title'] not in seen: seen.add(t['title']); unique.append(t)
    tests=unique[:150]
    CHANGE_TEST_PLAN={"version":"3.3","target":target,"created_at":datetime.now().isoformat(timespec='seconds'),"project":root,"tests":tests,"status":"draft"}
    _save_change_test_plan()
    lines=[f'변경 영향 테스트 계획 v3.3: {target}',f'테스트 {len(tests)}개','']
    lines.append('[우선순위 1]')
    for i,t in enumerate(tests,1):
        if t['priority']==1: lines.append(f"{i}. {t['title']}")
    lines.append('\n[우선순위 2/3]')
    for i,t in enumerate(tests,1):
        if t['priority']!=1: lines.append(f"{i}. {t['title']}")
        if len(lines)>38: break
    lines.append("\n실행: '테스트계획 실행'")
    return '\n'.join(lines)

def _run_change_test_case(t):
    root=PROJECT.get('path'); action=t.get('action'); target=t.get('target','')
    try:
        if action=='check_target':
            full=os.path.abspath(os.path.join(root,target)); return 'PASS — 파일 존재' if os.path.isfile(full) else 'WARN — 정확한 파일 경로가 아니거나 파일 없음'
        if action=='analyze_csharp':
            full=os.path.abspath(os.path.join(root,target))
            if not _project_safe(full) or not os.path.isfile(full): return 'FAIL — C# 파일 없음'
            result=analyze_csharp_code(Path(full).read_text(encoding='utf-8',errors='replace'))
            return 'PASS — 정적 검사 문제 없음' if '정적 검사에서 뚜렷한 문제' in result else 'WARN — '+result.split('\n')[0]
        if action=='graph_related': return 'PASS — 프로젝트 관계 그래프 조회 완료' if project_graph_related(target) else 'WARN — 관계 정보 부족'
        if action=='asset':
            full=os.path.abspath(os.path.join(root,target)); return 'PASS — Asset 존재' if os.path.isfile(full) else 'FAIL — Asset 없음'
        if action=='scene':
            r=unity_scan_scene(); return 'PASS — Scene 분석 완료' if r and '분석 실패' not in r else 'WARN — Unity 실행 환경 확인 필요'
        if action=='object':
            name=target.split('::')[-1]; r=unity_find_object(name); return 'PASS — GameObject 조회 완료' if '실패' not in r else 'WARN — GameObject 확인 필요'
        if action=='unity_editmode_tests':
            return run_unity_test_suite('editmode')
        if action=='unity_playmode_tests':
            return run_unity_test_suite('playmode')
        return 'PASS — 정적 영향 패턴 확인 완료'
    except Exception as e: return f'FAIL — {e}'

def execute_change_test_plan():
    _load_change_test_plan()
    if not CHANGE_TEST_PLAN.get('tests'): return "먼저 '변경테스트계획: 대상'으로 계획을 만들어줘."
    if not PROJECT.get('path'): return '먼저 Unity 프로젝트를 선택해줘.'
    counts=Counter()
    for t in CHANGE_TEST_PLAN['tests']:
        result=_run_change_test_case(t); t['result']=result
        t['status']='pass' if result.startswith('PASS') else ('fail' if result.startswith('FAIL') else 'warn'); counts[t['status']]+=1
    CHANGE_TEST_PLAN['status']='failed' if counts['fail'] else 'completed'; CHANGE_TEST_PLAN['finished_at']=datetime.now().isoformat(timespec='seconds'); _save_change_test_plan()
    lines=[f"테스트 계획 실행 완료: {CHANGE_TEST_PLAN['target']}",f"PASS {counts['pass']} · WARN {counts['warn']} · FAIL {counts['fail']}"]
    for i,t in enumerate(CHANGE_TEST_PLAN['tests'],1):
        if t['status']!='pass' or t['priority']==1: lines.append(f"{i}. [{t['status'].upper()}] {t['title']} — {t['result']}")
    lines.append('\n✅ 완료. WARN은 Unity 런타임에서 추가 확인이 필요할 수 있어.' if not counts['fail'] else '\n❌ FAIL 항목을 먼저 수정해줘.')
    return '\n'.join(lines)

def handle_change_test_command(text):
    t=str(text or '').strip(); m=re.match(r'(?:변경테스트계획|영향테스트계획|테스트계획생성)\s*[:：]?\s*(.+)$',t,re.I)
    if m: return create_change_test_plan(m.group(1).strip())
    if normalize(t) in ('테스트계획실행','변경테스트실행','영향테스트실행'): return execute_change_test_plan()
    if normalize(t) in ('테스트계획보기','변경테스트계획보기'):
        _load_change_test_plan(); return json.dumps(CHANGE_TEST_PLAN,ensure_ascii=False,indent=2)[:30000] if CHANGE_TEST_PLAN.get('tests') else '저장된 테스트 계획이 없어.'
    return None


# ──────────────────────────────────────────────
# v3.0 Unity 프로젝트 구조/계획 실행 엔진
# ──────────────────────────────────────────────
UNITY_EDITOR_PATH = os.environ.get("UNITY_EDITOR_PATH", "")
UNITY_BRIDGE_CS = """using UnityEditor;
using UnityEngine;
using UnityEngine.SceneManagement;
using UnityEditor.SceneManagement;
using System;
using System.IO;

public static class AIProjectBridge
{
    [Serializable]
    public class ActionData
    {
        public string action;
        public string scriptPath;
        public string scriptText;
        public string gameObjectName;
        public string componentType;
        public string scenePath;
        public string parentName;
        public string position;
        public string rotation;
        public string scale;
    }

    static string ActionFile() => Path.Combine(Application.dataPath, "../Library/ai_project_action.json");
    static void Log(string s) => Debug.Log("[AIProjectBridge] " + s);

    static string ResultFile() => Path.Combine(Application.dataPath, "../Library/ai_project_result.json");
    static void WriteResult(bool ok, string message)
    {
        try { File.WriteAllText(ResultFile(), JsonUtility.ToJson(new ResultData { ok = ok, message = message })); } catch {}
    }
    [Serializable]
    public class ResultData { public bool ok; public string message; }

    public static void Execute()
    {
        var path = ActionFile();
        if (!File.Exists(path)) { WriteResult(false, "action file not found"); return; }
        var a = JsonUtility.FromJson<ActionData>(File.ReadAllText(path));
        if (a == null) { WriteResult(false, "invalid action json"); return; }
        try
        {
            switch (a.action)
            {
                case "refresh": AssetDatabase.Refresh(); WriteResult(true, "refreshed"); break;
                case "create_script": CreateScript(a.scriptPath, a.scriptText); WriteResult(true, "script created"); break;
                case "create_gameobject": CreateGameObject(a.gameObjectName); WriteResult(true, "GameObject created"); break;
                case "create_child": CreateChild(a.gameObjectName, a.parentName); WriteResult(true, "child created"); break;
                case "add_component": AddComponent(a.gameObjectName, a.componentType); WriteResult(true, "component added"); break;
                case "set_transform": SetTransform(a.gameObjectName, a.position, a.rotation, a.scale); WriteResult(true, "transform changed"); break;
                case "save_scene": SaveScene(); WriteResult(true, "scene saved"); break;
                case "open_scene": OpenScene(a.scenePath); WriteResult(true, "scene opened"); break;
                case "scan_scene": WriteResult(true, ScanScene()); break;
                case "find_object": WriteResult(true, FindObjectInfo(a.gameObjectName)); break;
                default: throw new Exception("unsupported action: " + a.action);
            }
        }
        catch (Exception e) { Debug.LogError("[AIProjectBridge] " + e); WriteResult(false, e.ToString()); }
        finally
        {
            AssetDatabase.SaveAssets();
            AssetDatabase.Refresh();
            try { File.Delete(path); } catch { }
        }
    }

    static void CreateScript(string rel, string contents)
    {
        if (string.IsNullOrWhiteSpace(rel)) throw new Exception("scriptPath is empty");
        rel = rel.Replace('\\', '/');
        if (!rel.StartsWith("Assets/", StringComparison.OrdinalIgnoreCase)) rel = "Assets/" + rel.TrimStart('/');
        var root = Directory.GetParent(Application.dataPath).FullName;
        var full = Path.Combine(root, rel.Replace('/', Path.DirectorySeparatorChar));
        full = Path.GetFullPath(full);
        if (!full.StartsWith(root, StringComparison.OrdinalIgnoreCase)) throw new Exception("outside project");
        Directory.CreateDirectory(Path.GetDirectoryName(full));
        if (File.Exists(full)) throw new Exception("script already exists: " + rel);
        File.WriteAllText(full, contents ?? string.Empty);
        Log("script created: " + rel);
    }

    static GameObject FindGO(string name)
    {
        foreach (var root in SceneManager.GetActiveScene().GetRootGameObjects())
        {
            var found = FindRecursive(root.transform, name);
            if (found != null) return found.gameObject;
        }
        return null;
    }

    static Transform FindRecursive(Transform t, string name)
    {
        if (t.name == name) return t;
        for (int i = 0; i < t.childCount; i++)
        {
            var x = FindRecursive(t.GetChild(i), name);
            if (x != null) return x;
        }
        return null;
    }

    static void CreateGameObject(string name)
    {
        var go = new GameObject(string.IsNullOrWhiteSpace(name) ? "AI_GameObject" : name);
        Undo.RegisterCreatedObjectUndo(go, "AI Create GameObject");
        Selection.activeGameObject = go;
        EditorGUIUtility.PingObject(go);
        Log("GameObject created: " + go.name);
    }

    static void AddComponent(string objectName, string typeName)
    {
        var go = FindGO(objectName);
        if (go == null) throw new Exception("GameObject not found: " + objectName);
        var type = Type.GetType(typeName) ?? FindType(typeName);
        if (type == null) throw new Exception("Component type not found: " + typeName);
        if (!typeof(Component).IsAssignableFrom(type)) throw new Exception("Not a Component: " + typeName);
        Undo.AddComponent(go, type);
        Selection.activeGameObject = go;
        EditorGUIUtility.PingObject(go);
        Log("Component added: " + typeName + " -> " + objectName);
    }

    static Type FindType(string typeName)
    {
        foreach (var asm in AppDomain.CurrentDomain.GetAssemblies())
        {
            try
            {
                var t = asm.GetType(typeName);
                if (t != null) return t;
                if (!typeName.Contains("."))
                    foreach (var candidate in asm.GetTypes()) if (candidate.Name == typeName) return candidate;
            } catch { }
        }
        return null;
    }

    static void CreateChild(string childName, string parentName)
    {
        var parent = FindGO(parentName);
        if (parent == null) throw new Exception("Parent GameObject not found: " + parentName);
        var go = new GameObject(string.IsNullOrWhiteSpace(childName) ? "AI_Child" : childName);
        Undo.RegisterCreatedObjectUndo(go, "AI Create Child");
        go.transform.SetParent(parent.transform, false);
        Selection.activeGameObject = go;
        EditorGUIUtility.PingObject(go);
    }

    static Vector3 ParseVec(string s, Vector3 fallback)
    {
        if (string.IsNullOrWhiteSpace(s)) return fallback;
        var p = s.Split(',');
        if (p.Length != 3) return fallback;
        float x,y,z;
        if (float.TryParse(p[0], out x) && float.TryParse(p[1], out y) && float.TryParse(p[2], out z)) return new Vector3(x,y,z);
        return fallback;
    }

    static void SetTransform(string objectName, string position, string rotation, string scale)
    {
        var go = FindGO(objectName);
        if (go == null) throw new Exception("GameObject not found: " + objectName);
        Undo.RecordObject(go.transform, "AI Set Transform");
        if (!string.IsNullOrWhiteSpace(position)) go.transform.localPosition = ParseVec(position, go.transform.localPosition);
        if (!string.IsNullOrWhiteSpace(rotation)) go.transform.localEulerAngles = ParseVec(rotation, go.transform.localEulerAngles);
        if (!string.IsNullOrWhiteSpace(scale)) go.transform.localScale = ParseVec(scale, go.transform.localScale);
        Selection.activeGameObject = go;
    }

    static string FindObjectInfo(string name)
    {
        var go = FindGO(name);
        if (go == null) return "NOT_FOUND";
        var comps = go.GetComponents<Component>();
        var names = new System.Collections.Generic.List<string>();
        foreach (var c in comps) if (c != null) names.Add(c.GetType().FullName);
        return "name=" + go.name + "\nparent=" + (go.transform.parent ? go.transform.parent.name : "") + "\ncomponents=" + string.Join(",", names.ToArray()) + "\nposition=" + go.transform.localPosition.ToString();
    }

    static string ScanScene()
    {
        var roots = SceneManager.GetActiveScene().GetRootGameObjects();
        var lines = new System.Collections.Generic.List<string>();
        foreach (var r in roots) ScanTransform(r.transform, 0, lines);
        return string.Join("\n", lines.ToArray());
    }

    static void ScanTransform(Transform t, int depth, System.Collections.Generic.List<string> lines)
    {
        var indent = new string(' ', depth * 2);
        var comps = new System.Collections.Generic.List<string>();
        foreach (var c in t.GetComponents<Component>()) if (c != null) comps.Add(c.GetType().Name);
        lines.Add(indent + "- " + t.name + " [" + string.Join(",", comps.ToArray()) + "]");
        for (int i=0;i<t.childCount;i++) ScanTransform(t.GetChild(i), depth+1, lines);
    }

    static void SaveScene()
    {
        EditorSceneManager.SaveScene(SceneManager.GetActiveScene());
        Log("active scene saved");
    }

    static void OpenScene(string scenePath)
    {
        if (string.IsNullOrWhiteSpace(scenePath)) throw new Exception("scenePath is empty");
        if (!scenePath.StartsWith("Assets/", StringComparison.OrdinalIgnoreCase)) scenePath = "Assets/" + scenePath.TrimStart('/');
        EditorSceneManager.OpenScene(scenePath, OpenSceneMode.Single);
        Log("scene opened: " + scenePath);
    }
}
"""

# ──────────────────────────────────────────────
# v2.6/v2.7 코드 생성·분석·검증 엔진 (외부 LLM 없이 정적 규칙 기반)
# ──────────────────────────────────────────────
def extract_csharp_code(text):
    m = re.search(r"```(?:csharp|cs|C#)?\s*([\s\S]*?)```", str(text), re.IGNORECASE)
    if m:
        return m.group(1).strip()
    if any(k in str(text) for k in ("using UnityEngine", "MonoBehaviour", "public class", "private void", "[SerializeField]")):
        return str(text).strip()
    return ""


def analyze_csharp_code(code):
    code = code or ""
    if not code.strip():
        return None
    findings = []
    rank = {"높음": 0, "중간": 1, "낮음": 2, "정보": 3}
    def add(sev, title, detail, fix=""):
        findings.append((sev, title, detail, fix))
    if "MonoBehaviour" in code and "using UnityEngine;" not in code:
        add("높음", "UnityEngine 누락 가능", "MonoBehaviour 또는 Unity API를 쓰는데 using UnityEngine이 없어 컴파일 오류가 날 수 있어.", "using UnityEngine; 추가")
    if re.search(r"GameObject\.Find|FindObjectOfType<|FindFirstObjectByType<", code) and re.search(r"\bUpdate\s*\(", code):
        add("중간", "Update 내부 검색", "매 프레임 오브젝트를 검색하면 불필요한 비용이 생길 수 있어.", "Awake/Start에서 참조를 캐시")
    if re.search(r"GetComponent<[^>]+>\(\)", code) and not re.search(r"\b(Awake|Start)\s*\(", code):
        add("낮음", "GetComponent 캐싱 권장", "반복 호출되는 구조라면 참조를 필드에 저장하는 편이 좋아.", "Awake/Start에서 캐시")
    if re.search(r"public\s+(?:int|float|string|bool|GameObject|Transform|Rigidbody|Collider)\s+\w+", code):
        add("낮음", "public 필드 노출", "Inspector 설정 목적이라면 [SerializeField] private이 더 안전한 경우가 많아.", "[SerializeField] private 사용 검토")
    if "Input.GetKey(" in code and not re.search(r"\bUpdate\s*\(", code):
        add("중간", "입력 확인 위치", "Input.GetKey는 보통 Update에서 읽는 게 적절해.", "Update에서 입력을 읽기")
    if "OnCollision" in code and "Collider" not in code and "Rigidbody" not in code:
        add("중간", "물리 설정 점검", "충돌 콜백은 Collider/Rigidbody 및 레이어 설정의 영향을 받아.", "Collider/Rigidbody와 Layer Collision Matrix 확인")
    if re.search(r"new\s+List<[^>]+>\s*\(\s*\)", code) and re.search(r"\bUpdate\s*\(", code):
        add("중간", "Update 할당", "매 프레임 새 List를 만들면 GC 부담이 생길 수 있어.", "재사용 또는 미리 할당")
    if "Debug.Log" in code and re.search(r"\bUpdate\s*\(", code):
        add("낮음", "매 프레임 로그", "Update 안의 Debug.Log는 성능과 콘솔에 부담이 될 수 있어.", "조건부 로그/개발용 플래그 사용")
    if re.search(r"while\s*\(\s*true\s*\)", code) and "break" not in code:
        add("높음", "무한 루프 가능성", "while(true)에 눈에 띄는 종료 조건이 없어.", "break 또는 종료 조건 추가")
    if "async void" in code and "await" not in code:
        add("낮음", "async void 점검", "await가 없으면 async가 불필요할 수 있어.", "불필요한 async 제거 또는 실제 await 작업 추가")
    for a,b in (("{","}"),("(",")"),("[","]")):
        if code.count(a) != code.count(b):
            add("높음", f"괄호 불균형 {a}{b}", "괄호 개수가 맞지 않아 컴파일 오류 가능성이 높아.", "괄호 짝 확인")
    findings.sort(key=lambda x: rank.get(x[0], 9))
    if not findings:
        return "정적 검사에서 뚜렷한 문제를 찾지 못했어. 실제 Unity 컴파일/실행 테스트는 별도로 필요해."
    lines=[f"코드 분석 결과: {len(findings)}개 항목"]
    for i,(sev,title,detail,fix) in enumerate(findings,1):
        lines.append(f"{i}. [{sev}] {title} — {detail}")
        if fix: lines.append(f"   해결 방향: {fix}")
    lines.append("\n주의: 이 기능은 정적 분석이라 실제 Unity 컴파일 결과를 대신하지 않아.")
    return "\n".join(lines)


def _code_block(label, code, note=""):
    return (label + ("\n" + note if note else "") + "\n\n```csharp\n" + code + "\n```")


def generate_unity_csharp(request):
    q = str(request or "").strip()
    n = normalize(q)
    m = re.search(r"(?:이름|클래스|class)\s*[:：]?\s*([A-Za-z_]\w*)", q, re.I)
    cls = m.group(1) if m else "PlayerController"
    if any(k in n for k in ("플레이어이동", "이동스크립트", "wasd", "캐릭터이동")):
        code = """using UnityEngine;\n\npublic class %s : MonoBehaviour\n{\n    [SerializeField] private float moveSpeed = 5f;\n\n    private void Update()\n    {\n        float x = Input.GetAxisRaw(\"Horizontal\");\n        float z = Input.GetAxisRaw(\"Vertical\");\n        Vector3 input = new Vector3(x, 0f, z).normalized;\n        transform.position += input * moveSpeed * Time.deltaTime;\n    }\n}""" % cls
        return _code_block("플레이어 이동용 기본 C# 스크립트야.", code, "Inspector에서 moveSpeed를 조절해.")
    if any(k in n for k in ("2단점프", "더블점프", "점프스크립트", "점프")):
        max_jumps = 2 if any(k in n for k in ("2단점프", "더블점프")) else 1
        code = """using UnityEngine;\n\npublic class %s : MonoBehaviour\n{\n    [SerializeField] private Rigidbody rb;\n    [SerializeField] private float jumpForce = 7f;\n    [SerializeField] private int maxJumps = %d;\n    private int jumpCount;\n\n    private void Update()\n    {\n        if (Input.GetButtonDown(\"Jump\") && jumpCount < maxJumps)\n        {\n            rb.velocity = new Vector3(rb.velocity.x, 0f, rb.velocity.z);\n            rb.AddForce(Vector3.up * jumpForce, ForceMode.Impulse);\n            jumpCount++;\n        }\n    }\n\n    private void OnCollisionEnter(Collision collision)\n    {\n        if (collision.collider.CompareTag(\"Ground\"))\n            jumpCount = 0;\n    }\n}""" % (cls, max_jumps)
        return _code_block("점프 시스템 예제야.", code, "Rigidbody 연결과 Ground 태그가 필요해.")
    if any(k in n for k in ("체력", "hp", "health")):
        code = """using UnityEngine;\nusing UnityEngine.Events;\n\npublic class %s : MonoBehaviour\n{\n    [SerializeField] private int maxHealth = 100;\n    [SerializeField] private UnityEvent onDeath;\n    private int currentHealth;\n\n    private void Awake()\n    {\n        currentHealth = maxHealth;\n    }\n\n    public void TakeDamage(int amount)\n    {\n        if (amount <= 0) return;\n        currentHealth = Mathf.Max(0, currentHealth - amount);\n        if (currentHealth == 0) onDeath?.Invoke();\n    }\n}""" % cls
        return _code_block("기본 HP/피격 스크립트야.", code, "onDeath 이벤트에 사망 처리를 연결할 수 있어.")
    if any(k in n for k in ("쿠나이", "투사체", "발사", "던지기", "projectile")):
        code = """using UnityEngine;\n\npublic class %s : MonoBehaviour\n{\n    [SerializeField] private GameObject projectilePrefab;\n    [SerializeField] private Transform firePoint;\n    [SerializeField] private float speed = 12f;\n\n    public void Fire()\n    {\n        if (projectilePrefab == null || firePoint == null) return;\n        GameObject projectile = Instantiate(projectilePrefab, firePoint.position, firePoint.rotation);\n        Rigidbody rb = projectile.GetComponent<Rigidbody>();\n        if (rb != null) rb.velocity = firePoint.forward * speed;\n    }\n}""" % cls
        return _code_block("투사체 발사용 기본 스크립트야.", code, "projectilePrefab과 firePoint를 Inspector에 연결해야 해.")
    return None


def handle_code_command(text):
    code = extract_csharp_code(text)
    n = normalize(text)
    if code and any(k in n for k in ("분석", "오류", "에러", "문제", "검사", "리뷰")):
        return analyze_csharp_code(code)
    if any(k in n for k in ("코드생성", "스크립트만들", "스크립트작성", "c#만들", "unity코드", "유니티코드", "스크립트생성")):
        result = generate_unity_csharp(text)
        if result: return result
    if any(k in n for k in ("이동스크립트", "점프스크립트", "체력시스템", "쿠나이", "투사체")):
        result = generate_unity_csharp(text)
        if result: return result
    return None



# ──────────────────────────────────────────────
# v2.7 코드 검증 / 자동 수정 엔진
# ──────────────────────────────────────────────
VERIFY_MAX_ROUNDS = 5
VERIFY_DIR = os.path.join(HERE, "ai_verify")
os.makedirs(VERIFY_DIR, exist_ok=True)

def _find_executable(names):
    for name in names:
        for base in os.environ.get("PATH", "").split(os.pathsep):
            if not base:
                continue
            candidate = os.path.join(base, name)
            if os.path.isfile(candidate) and os.access(candidate, os.X_OK):
                return candidate
    return None

def detect_csharp_toolchain():
    """dotnet/csc가 설치되어 있으면 경로를 반환한다. Unity 컴파일은 별도로 탐지한다."""
    dotnet = _find_executable(["dotnet.exe", "dotnet"])
    csc = _find_executable(["csc.exe", "csc"])
    return {"dotnet": dotnet, "csc": csc}

def _balanced_pairs(code):
    pairs = [("{", "}"), ("(", ")"), ("[", "]")]
    bad = []
    for a, b in pairs:
        if code.count(a) != code.count(b):
            bad.append(f"{a}{b} 개수 불일치")
    return bad

def _quick_fix_csharp(code):
    """안전한 범위의 결정론적 자동 수정만 수행한다."""
    fixed = code
    changes = []
    # Unity API 사용인데 using이 빠진 경우
    if ("MonoBehaviour" in fixed or "UnityEngine." in fixed or "SerializeField" in fixed) and "using UnityEngine;" not in fixed:
        fixed = "using UnityEngine;\n" + fixed
        changes.append("using UnityEngine; 추가")
    # 파일 끝의 흔한 BOM/공백 정리
    cleaned = fixed.replace("\ufeff", "").strip() + "\n"
    if cleaned != fixed:
        fixed = cleaned
        changes.append("BOM/끝 공백 정리")
    return fixed, changes

def _extract_code_from_verification(text):
    code = extract_csharp_code(text)
    if code:
        return code
    return text.strip() if any(k in text for k in ("class ", "using ", "namespace ")) else ""

def _verify_with_dotnet(code, tool):
    """Unity API가 아닌 일반 C# 코드를 임시 SDK 프로젝트에서 실제 빌드한다."""
    if not tool:
        return {"ok": False, "available": False, "kind": "dotnet", "message": "dotnet을 찾지 못했어."}
    if "UnityEngine" in code or "MonoBehaviour" in code or "UnityEditor" in code:
        return {"ok": False, "available": True, "kind": "dotnet", "skipped": True,
                "message": "Unity 전용 API가 포함돼 있어 일반 dotnet 빌드로는 검증할 수 없어."}
    stamp = hashlib.sha256(code.encode("utf-8")).hexdigest()[:12]
    work = os.path.join(VERIFY_DIR, "dotnet_" + stamp)
    os.makedirs(work, exist_ok=True)
    csproj = os.path.join(work, "Verify.csproj")
    prog = os.path.join(work, "Program.cs")
    project = """<Project Sdk="Microsoft.NET.Sdk">\n  <PropertyGroup>\n    <OutputType>Exe</OutputType>\n    <TargetFramework>net8.0</TargetFramework>\n    <ImplicitUsings>disable</ImplicitUsings>\n    <Nullable>disable</Nullable>\n  </PropertyGroup>\n</Project>\n"""
    # 컴파일 단위가 class/namespace라면 Program.Main 래퍼가 필요할 수 있다.
    body = code
    if "static void Main(" not in body and "static async Task Main(" not in body:
        body += "\n\npublic static class __VerifyEntry { public static void Main() { } }\n"
    Path(csproj).write_text(project, encoding="utf-8")
    Path(prog).write_text(body, encoding="utf-8")
    import subprocess
    try:
        proc = subprocess.run([tool, "build", csproj, "--nologo", "-v:q"], cwd=work,
                              capture_output=True, text=True, timeout=45)
        output = (proc.stdout + "\n" + proc.stderr).strip()
        return {"ok": proc.returncode == 0, "available": True, "kind": "dotnet",
                "message": "컴파일 성공" if proc.returncode == 0 else "컴파일 실패",
                "output": output[-12000:]}
    except subprocess.TimeoutExpired:
        return {"ok": False, "available": True, "kind": "dotnet", "message": "컴파일 시간 초과"}
    except Exception as e:
        return {"ok": False, "available": True, "kind": "dotnet", "message": f"컴파일러 실행 오류: {e}"}

def verify_csharp(code, auto_fix=True, rounds=VERIFY_MAX_ROUNDS):
    code = str(code or "").strip()
    if not code:
        return {"ok": False, "rounds": 0, "code": "", "history": ["검증할 C# 코드가 없어."]}
    rounds = max(1, min(int(rounds or VERIFY_MAX_ROUNDS), VERIFY_MAX_ROUNDS))
    history = []
    current = code
    best = current
    toolchain = detect_csharp_toolchain()

    for r in range(1, rounds + 1):
        quick_issues = _balanced_pairs(current)
        if quick_issues:
            history.append(f"{r}차: 정적 검사 — " + ", ".join(quick_issues))
            if not auto_fix:
                break
            # 자동 수정으로 해결할 수 없는 괄호 문제는 추측 수정하지 않는다.
            break

        fixed, changes = _quick_fix_csharp(current) if auto_fix else (current, [])
        if changes:
            history.append(f"{r}차: 자동 수정 — " + ", ".join(changes))
            current = fixed

        result = _verify_with_dotnet(current, toolchain.get("dotnet"))
        if result.get("skipped"):
            static = analyze_csharp_code(current) or "정적 검사 완료"
            history.append(f"{r}차: Unity 코드라 일반 C# 컴파일은 건너뜀")
            return {"ok": "뚜렷한 문제" not in static, "rounds": r, "code": current,
                    "history": history, "compiler": result, "analysis": static}
        if not result.get("available"):
            static = analyze_csharp_code(current) or "정적 검사 완료"
            history.append(f"{r}차: dotnet 미설치 → 정적 검사만 수행")
            return {"ok": True, "rounds": r, "code": current, "history": history,
                    "compiler": result, "analysis": static, "needs_toolchain": True}
        if result.get("ok"):
            history.append(f"{r}차: 컴파일 성공")
            best = current
            return {"ok": True, "rounds": r, "code": best, "history": history, "compiler": result}
        best = current
        history.append(f"{r}차: 컴파일 실패")
        err = result.get("output", "")
        # 현재 엔진은 외부 LLM 없이 결정론적 수정만 허용한다.
        # 컴파일러 오류를 분석 결과에 넘기고 안전하게 종료한다.
        if err:
            history.append("컴파일러: " + err[-4000:])
        break

    return {"ok": False, "rounds": len(history) or 1, "code": best, "history": history,
            "compiler": result if 'result' in locals() else None}

def format_verification_result(result):
    lines = ["🧪 C# 코드 검증 결과"]
    lines.append("상태: " + ("✅ 통과" if result.get("ok") else "⚠️ 추가 수정/환경 확인 필요"))
    lines.append(f"검증 횟수: {result.get('rounds', 0)}")
    for h in result.get("history", []):
        lines.append("- " + h)
    comp = result.get("compiler") or {}
    if comp.get("available"):
        lines.append("컴파일러: " + ("사용됨" if not comp.get("skipped") else "Unity 전용이라 일반 컴파일 생략"))
    else:
        lines.append("컴파일러: dotnet 미설치 → 정적 검사만 수행")
    lines.append("\n검증 코드:")
    lines.append("```csharp\n" + result.get("code", "") + "\n```")
    return "\n".join(lines)

def handle_verify_command(text):
    t = str(text or "").strip()
    code = _extract_code_from_verification(t)
    n = normalize(t)
    wants = any(k in n for k in ("코드검증", "코드확인", "컴파일", "검증해", "테스트해", "오류수정"))
    if not wants or not code:
        return None
    rounds = VERIFY_MAX_ROUNDS
    m = re.search(r"(?:최대|max)\s*(\d+)\s*(?:회|번)?", t, re.I)
    if m:
        rounds = min(VERIFY_MAX_ROUNDS, int(m.group(1)))
    return format_verification_result(verify_csharp(code, auto_fix=True, rounds=rounds))


# ──────────────────────────────────────────────
# v3.5 Unity Test Runner 연동
# ──────────────────────────────────────────────
V35_TEST_RESULTS_DIR = os.path.join(HERE, "ai_unity_test_results")
V35_TEST_LOG_FILE = os.path.join(HERE, "ai_unity_test_log.json")

def _unity_project_has_tests(root):
    if not root or not os.path.isdir(root):
        return False
    for d in ("Tests", "Test", "EditorTests"):
        if os.path.isdir(os.path.join(root, "Assets", d)):
            return True
    try:
        base = os.path.join(root, "Assets")
        for dirpath, dirnames, filenames in os.walk(base):
            dirnames[:] = [d for d in dirnames if d not in ("Library", "Temp", "Logs", "Obj", ".git")]
            for fn in filenames:
                if fn.lower().endswith(".cs") and "test" in fn.lower():
                    return True
    except Exception:
        pass
    return False

def _parse_unity_test_results(xml_path):
    import xml.etree.ElementTree as ET
    if not os.path.isfile(xml_path):
        return {"ok": False, "status": "warn", "message": "testResults.xml이 생성되지 않았어.", "passed": 0, "failed": 0, "skipped": 0, "total": 0}
    try:
        root = ET.parse(xml_path).getroot()
        passed = failed = skipped = total = 0
        duration = 0.0
        for elem in root.iter():
            if elem.tag.lower().split('}')[-1] not in ('testcase','test-case'):
                continue
            total += 1
            try: duration += float(elem.attrib.get('time', 0) or 0)
            except Exception: pass
            if elem.find('failure') is not None or elem.find('error') is not None:
                failed += 1
            elif elem.find('skipped') is not None:
                skipped += 1
            else:
                passed += 1
        return {"ok": total > 0 and failed == 0, "status": "pass" if total > 0 and failed == 0 else ("fail" if failed else "warn"), "message": "Unity Test Runner 결과 파싱 완료", "passed": passed, "failed": failed, "skipped": skipped, "total": total, "duration": duration, "results_file": xml_path}
    except Exception as e:
        return {"ok": False, "status": "fail", "message": f"테스트 결과 파싱 실패: {e}", "passed": 0, "failed": 0, "skipped": 0, "total": 0, "results_file": xml_path}


V36_FAILURE_LOG_FILE = os.path.join(HERE, "ai_unity_failure_analysis.json")
V37_ROOT_CAUSE_LOG_FILE = os.path.join(HERE, "ai_unity_root_cause_analysis.json")


def _project_relative_from_path(path, root):
    try:
        if not path or not root:
            return None
        raw = str(path).strip().replace('\\','/')
        rr = os.path.abspath(root)
        # 실제 존재 여부와 무관하게 스택 트레이스 경로를 프로젝트 상대경로로 변환
        ap = os.path.abspath(raw)
        try:
            common = os.path.commonpath([ap, rr])
        except Exception:
            common = ''
        if common and os.path.normcase(common) == os.path.normcase(rr):
            return os.path.relpath(ap, rr).replace(os.sep, '/')
        # Windows 드라이브/대소문자 차이 등을 고려한 문자열 fallback
        rr_norm = rr.replace('\\','/').rstrip('/')
        raw_norm = raw.rstrip('/')
        if raw_norm.lower().startswith(rr_norm.lower() + '/'):
            return raw_norm[len(rr_norm)+1:]
        idx = raw_norm.lower().find('/assets/')
        if idx >= 0:
            return raw_norm[idx+1:]
        if raw_norm.lower().startswith('assets/'):
            return raw_norm
        return None
    except Exception:
        return None


def _extract_file_lines(text):
    """Unity/NUnit stack trace에서 파일 경로와 줄 번호를 추출한다."""
    hits = []
    if not text:
        return hits
    patterns = [
        re.compile(r'(?P<path>(?:[A-Za-z]:[\\/]|/)?[^\n\r:\"\']+?\.cs)\s*[:\(](?P<line>\d+)(?:[,\)]|$)', re.I),
        re.compile(r'in\s+(?P<path>[^\n\r]+?\.cs):line\s+(?P<line>\d+)', re.I),
    ]
    for pat in patterns:
        for m in pat.finditer(text):
            path = m.group('path').strip().strip('"\'')
            line = int(m.group('line'))
            hits.append({'path': path, 'line': line})
    # 중복 제거
    seen=set(); out=[]
    for h in hits:
        key=(h['path'], h['line'])
        if key not in seen:
            seen.add(key); out.append(h)
    return out


def _analyze_unity_failure_result(result, root=None):
    """Unity Test Runner 결과 + XML을 바탕으로 실패 테스트별 원인/파일/라인 후보를 만든다."""
    root = root or PROJECT.get('path')
    analysis = {
        'version': '3.6',
        'platform': result.get('platform'),
        'results_file': result.get('results_file'),
        'log_file': result.get('log_file'),
        'status': result.get('status'),
        'failures': [],
        'summary': ''
    }
    xml_path = result.get('results_file')
    if not xml_path or not os.path.isfile(xml_path):
        log_text = ''
        lp=result.get('log_file')
        if lp and os.path.isfile(lp):
            try: log_text=Path(lp).read_text(encoding='utf-8', errors='replace')[-50000:]
            except Exception: pass
        if log_text:
            analysis['failures'].append({
                'test_name': 'Unity Editor log',
                'message': 'XML 결과가 없어 Editor 로그에서 오류 단서를 추출했어.',
                'stack_trace': log_text[-10000:],
                'file_lines': _extract_file_lines(log_text),
                'candidate_files': [],
            })
        analysis['summary'] = '결과 XML이 없어 로그 기반 분석을 시도했어.'
        _save_obj(V36_FAILURE_LOG_FILE, analysis)
        return analysis
    try:
        import xml.etree.ElementTree as ET
        root_xml=ET.parse(xml_path).getroot()
        for tc in root_xml.iter():
            if tc.tag.lower().split('}')[-1] not in ('testcase','test-case'):
                continue
            failures=[]
            for child in list(tc):
                tag=child.tag.lower().split('}')[-1]
                if tag in ('failure','error'):
                    failures.append((child.attrib.get('message','') or '', child.text or ''))
            if not failures:
                continue
            test_name=tc.attrib.get('name','') or tc.attrib.get('fullname','') or '이름 없는 테스트'
            classname=tc.attrib.get('classname','') or ''
            message=' '.join(x[0] for x in failures if x[0]).strip()
            stack='\n'.join(x[1] for x in failures if x[1]).strip()
            combined='\n'.join([message, stack])
            file_lines=_extract_file_lines(combined)
            candidate_files=[]
            for hit in file_lines:
                raw=hit['path']
                rel=_project_relative_from_path(raw, root)
                if rel and rel.lower().endswith('.cs'):
                    candidate_files.append({'path': rel, 'line': hit['line'], 'reason':'stack trace'})
                else:
                    # Unity stack trace가 Assets/... 형태인 경우
                    normalized=raw.replace('\\','/').lstrip('./')
                    if normalized.startswith('Assets/'):
                        candidate_files.append({'path':normalized, 'line':hit['line'], 'reason':'stack trace'})
            # 메시지에 NullReference/Assertion 등의 단서가 있으면 원인 태그 추가
            tags=[]
            low=combined.lower()
            if 'nullreferenceexception' in low or 'object reference not set' in low:
                tags.append('NullReferenceException')
            if 'assert' in low:
                tags.append('Assertion/Assert')
            if 'missingreferenceexception' in low:
                tags.append('MissingReferenceException')
            if 'invalidoperationexception' in low:
                tags.append('InvalidOperationException')
            if 'indexoutofrangeexception' in low:
                tags.append('IndexOutOfRangeException')
            if 'argumentexception' in low:
                tags.append('ArgumentException')
            analysis['failures'].append({
                'test_name': test_name,
                'classname': classname,
                'message': message[:4000],
                'stack_trace': stack[:12000],
                'file_lines': file_lines[:20],
                'candidate_files': candidate_files[:20],
                'tags': tags,
            })
        analysis['summary']=f"실패 테스트 {len(analysis['failures'])}개에서 원인 단서 추출 완료"
    except Exception as e:
        analysis['status']='fail'
        analysis['summary']=f'실패 분석 오류: {e}'
    _save_obj(V36_FAILURE_LOG_FILE, analysis)
    return analysis



def _read_code_context(relpath, line, root=None, radius=10):
    """실패한 C# 줄 주변의 실제 코드를 읽어 분석용 컨텍스트를 만든다."""
    root = root or PROJECT.get('path')
    if not root or not relpath or not line:
        return None
    full = os.path.abspath(os.path.join(root, relpath))
    if not _project_safe(full) or not os.path.isfile(full):
        return None
    try:
        lines = Path(full).read_text(encoding='utf-8', errors='replace').splitlines()
    except Exception:
        return None
    idx=max(0, int(line)-1)
    start=max(0, idx-radius); end=min(len(lines), idx+radius+1)
    return {
        'path': relpath.replace('\\','/'),
        'line': int(line),
        'start_line': start+1,
        'end_line': end,
        'target_line': lines[idx] if 0 <= idx < len(lines) else '',
        'context': '\n'.join(f'{i+1:5d}: {lines[i]}' for i in range(start,end)),
        'total_lines': len(lines),
    }


def _root_cause_candidates_for_failure(failure, root=None):
    """실패 메시지 + 스택트레이스 + 실제 코드 주변 문맥을 이용해 원인 후보를 만든다.
    생성형 모델 없이 보수적인 규칙 기반으로 점수화한다."""
    root = root or PROJECT.get('path')
    combined=(failure.get('message','')+'\n'+failure.get('stack_trace','')).lower()
    tags=set(failure.get('tags') or [])
    candidates=[]
    contexts=[]
    for c in (failure.get('candidate_files') or [])[:10]:
        ctx=_read_code_context(c.get('path'), c.get('line'), root=root, radius=10)
        if ctx:
            contexts.append(ctx)
    def add(score, title, reason, fix_hint='', ctx=None):
        candidates.append({'score':score,'title':title,'reason':reason,'fix_hint':fix_hint,'context':ctx})
    for ctx in contexts:
        code=ctx['context']
        target=ctx['target_line']
        low=code.lower()
        if 'nullreferenceexception' in {x.lower() for x in tags} or 'nullreferenceexception' in combined or 'object reference not set' in combined:
            if 'getcomponent<' in low or '.getcomponent(' in low:
                add(0.96,'참조 대상이 null일 가능성','GetComponent 결과 또는 컴포넌트 참조가 null일 가능성이 높아.','Awake/Start에서 참조 존재 여부를 확인하고 null 가드를 추가해.',ctx)
            elif '.' in target and not re.search(r'\b(if|while|for|return)\b', target):
                add(0.88,'객체 참조가 null일 가능성','실패 줄에서 객체 멤버 접근이 보여 NullReferenceException과 잘 맞아.','문제 객체를 초기화하는 코드와 null 검사를 확인해.',ctx)
        if 'missingreferenceexception' in combined or 'destroyed' in combined:
            add(0.95,'파괴된 Unity Object 참조 가능성','Destroy 이후에도 참조를 사용했을 가능성이 있어.','Destroy 호출과 이후 사용 시점을 확인하고 참조 유효성을 검사해.',ctx)
        if 'indexoutofrangeexception' in combined:
            if re.search(r'\[[^\]]+\]', target):
                add(0.94,'배열/리스트 인덱스 범위 초과','실패 줄에서 인덱싱이 확인돼.','인덱스 범위를 검사하고 Count/Length를 확인해.',ctx)
        if 'invalidoperationexception' in combined:
            if 'collection' in combined or 'modified' in combined:
                add(0.92,'컬렉션을 순회 중 변경했을 가능성','열거 중 컬렉션을 수정하면 InvalidOperationException이 발생할 수 있어.','복사본을 순회하거나 별도 버퍼에 변경 사항을 모아 적용해.',ctx)
        if 'argumentexception' in combined:
            add(0.74,'메서드 인자 조건 위반 가능성','전달한 인자가 API가 허용하는 범위를 벗어났을 가능성이 있어.','예외 메시지의 매개변수명과 호출부의 실제 값을 확인해.',ctx)
        if 'assert' in combined or 'assertion' in combined:
            add(0.86,'명시적 조건(Assert) 위반','테스트가 기대한 전제조건이 실패한 상태야.','테스트의 기대값과 해당 줄에서 계산되는 실제값을 비교해.',ctx)
        if 'timeout' in combined or 'timed out' in combined:
            add(0.72,'시간 초과 또는 무한/과도한 작업 가능성','테스트가 제한 시간 내 끝나지 못했어.','Update/Coroutine/loop 내부의 반복 작업과 대기 조건을 확인해.',ctx)
        if re.search(r'\bwhile\s*\(', low) and ('timeout' in combined or 'hang' in combined):
            add(0.91,'종료 조건이 충족되지 않는 while 루프 가능성','실패 줄 주변에 while 루프가 있어 시간 초과 원인이 될 수 있어.','루프 탈출 조건과 변경되는 상태 변수를 확인해.',ctx)
        if 'task' in low and ('deadlock' in combined or 'timeout' in combined):
            add(0.84,'비동기 작업 대기 문제 가능성','Task 대기 또는 동기식 Wait가 정지 원인이 될 수 있어.','Result/Wait 호출과 메인 스레드 의존성을 확인해.',ctx)
        if ('scene' in combined or 'gameobject' in combined or 'component' in combined) and 'find(' in low:
            add(0.68,'런타임 오브젝트 탐색 결과 불안정 가능성','Scene/테스트 환경에서 이름 기반 탐색 결과가 없을 수 있어.','필요한 GameObject를 명시적으로 주입하거나 테스트에서 생성하도록 해.',ctx)
        if 'playerprefs' in low and ('not found' in combined or 'null' in combined):
            add(0.65,'저장 데이터 부재 가능성','테스트 환경에 저장된 PlayerPrefs가 없을 수 있어.','테스트 시작 전에 초기값을 설정해.',ctx)
    # 스택 프레임이 실제 테스트 코드라면 별도 후보
    if not candidates and failure.get('candidate_files'):
        c=failure['candidate_files'][0]
        add(0.5,'정확한 실패 지점부터 확인','현재 확보된 단서는 스택트레이스의 파일/줄 번호야.','해당 줄의 입력값과 직전 상태를 로그로 확인해.',_read_code_context(c.get('path'), c.get('line'), root=root, radius=10))
    # 중복 제거 / 점수 정렬
    seen=set(); out=[]
    for c in sorted(candidates, key=lambda x:-x['score']):
        k=(c['title'], (c.get('context') or {}).get('path'), (c.get('context') or {}).get('line'))
        if k in seen: continue
        seen.add(k); out.append(c)
    return out[:8], contexts


def build_root_cause_analysis(failure_analysis, root=None):
    root=root or PROJECT.get('path')
    out={
        'version':'3.7',
        'created_at':datetime.now().isoformat(timespec='seconds'),
        'status':failure_analysis.get('status'),
        'summary':failure_analysis.get('summary',''),
        'failures':[],
    }
    for f in failure_analysis.get('failures',[]):
        cands, contexts=_root_cause_candidates_for_failure(f, root=root)
        out['failures'].append({
            'test_name':f.get('test_name'),
            'message':f.get('message',''),
            'tags':f.get('tags',[]),
            'candidate_files':f.get('candidate_files',[]),
            'contexts':contexts[:8],
            'root_causes':cands,
            'recommended_focus': (cands[0]['context'].get('path') if cands and cands[0].get('context') else (f.get('candidate_files') or [{}])[0].get('path')),
        })
    _save_obj(V37_ROOT_CAUSE_LOG_FILE, out)
    return out


def analyze_latest_unity_root_causes():
    """최근 실패를 실제 코드 문맥까지 읽어서 원인 후보를 만든다."""
    log=_load_obj(V35_TEST_LOG_FILE,{})
    if not isinstance(log,dict) or not log.get('results_file'):
        return '최근 Unity 테스트 결과가 없어. 먼저 테스트를 실행해줘.'
    failure_analysis=_analyze_unity_failure_result(log, PROJECT.get('path'))
    if not failure_analysis.get('failures'):
        return '구체적인 실패 테스트가 없어. 먼저 FAIL이 발생한 Unity 테스트를 확인해줘.'
    analysis=build_root_cause_analysis(failure_analysis, PROJECT.get('path'))
    lines=['Unity 실패 원인 분석 v3.7', f"{len(analysis.get('failures',[]))}개 실패를 실제 코드 문맥까지 검사했어."]
    for i,f in enumerate(analysis['failures'],1):
        lines.append(f"\n{i}. {f.get('test_name','')}")
        if f.get('message'): lines.append(f"  메시지: {f['message'][:600]}")
        if f.get('tags'): lines.append(f"  오류 유형: {', '.join(f['tags'])}")
        cands=f.get('root_causes') or []
        if cands:
            lines.append('  원인 후보:')
            for c in cands[:4]:
                lines.append(f"    - [{c['score']:.2f}] {c['title']} — {c['reason']}")
                if c.get('fix_hint'): lines.append(f"      수정 방향: {c['fix_hint']}")
                ctx=c.get('context') or {}
                if ctx.get('path'): lines.append(f"      코드 위치: {ctx['path']}:{ctx.get('line')}")
                if ctx.get('target_line'): lines.append(f"      실패 줄: {ctx['target_line'].strip()[:300]}")
        else:
            lines.append('  원인 후보를 확정할 단서가 부족해. 스택트레이스와 해당 줄 주변을 직접 확인해줘.')
    lines.append(f"\n상세 분석 로그: {V37_ROOT_CAUSE_LOG_FILE}")
    return '\n'.join(lines)


# ──────────────────────────────────────────────
# v3.8 Exact Patch Proposal + Diff Review
# ──────────────────────────────────────────────
V38_PATCH_FILE = os.path.join(HERE, "ai_code_patch_proposal.json")
V38_PATCH_BACKUP_DIR = os.path.join(HERE, "ai_code_patch_backups")
os.makedirs(V38_PATCH_BACKUP_DIR, exist_ok=True)


def _relative_project_path(path):
    root = PROJECT.get('path')
    if not root or not path:
        return None
    try:
        rel = os.path.relpath(os.path.abspath(path), os.path.abspath(root))
        if rel == '.':
            return ''
        return rel.replace('\\', '/')
    except Exception:
        return None


def _proposal_from_failure(target=None):
    """최근 실패 분석에서 우선순위가 가장 높은 C# 파일에 대해 안전한 수정 후보를 만든다.
    생성형 모델 없이 기존 정적 자동수정 엔진이 실제로 수행할 수 있는 변경만 제안한다."""
    root = PROJECT.get('path')
    if not root:
        return {"ok": False, "message": "먼저 Unity 프로젝트를 선택해줘."}

    failure_log = _load_obj(V37_ROOT_CAUSE_LOG_FILE, {})
    chosen = None
    failures = failure_log.get('failures', []) if isinstance(failure_log, dict) else []
    if target:
        target_norm = target.replace('\\', '/').lower()
        for f in failures:
            for c in f.get('candidate_files', []):
                if str(c.get('path','')).replace('\\','/').lower() == target_norm:
                    chosen = {"failure": f, "candidate": c}
                    break
            if chosen:
                break
    if not chosen:
        for f in failures:
            for rc in f.get('root_causes', []):
                ctx = rc.get('context') or {}
                if ctx.get('path'):
                    chosen = {"failure": f, "candidate": {"path": ctx['path'], "line": ctx.get('line', 0)}, "root_cause": rc}
                    break
            if chosen:
                break
    if not chosen and target:
        chosen = {"failure": {}, "candidate": {"path": target, "line": 0}}
    if not chosen:
        return {"ok": False, "message": "최근 실패 분석에서 수정 후보를 찾지 못했어. 먼저 '정밀실패분석'을 실행해줘."}

    rel = str(chosen['candidate'].get('path','')).replace('\\','/')
    full = os.path.abspath(os.path.join(root, rel))
    if not _project_safe(full) or not os.path.isfile(full) or not full.lower().endswith('.cs'):
        return {"ok": False, "message": "수정 후보가 프로젝트 내부의 유효한 C# 파일이 아니야."}

    try:
        original = Path(full).read_text(encoding='utf-8', errors='replace')
    except Exception as e:
        return {"ok": False, "message": f"파일을 읽지 못했어: {e}"}

    verification = verify_csharp(original, auto_fix=True, rounds=VERIFY_MAX_ROUNDS)
    proposed = verification.get('code', original)
    # 현재 자동수정 엔진이 바꾸는 것만 v3.8의 '안전한 패치'로 취급한다.
    changed = proposed != original
    diff = ''.join(__import__('difflib').unified_diff(
        original.splitlines(True), proposed.splitlines(True),
        fromfile=rel + ' (현재)', tofile=rel + ' (제안)', n=3
    )) if changed else ''

    failure = chosen.get('failure') or {}
    root_cause = chosen.get('root_cause')
    if not root_cause:
        for f in failures:
            if f.get('test_name') == failure.get('test_name'):
                rcs = f.get('root_causes') or []
                root_cause = rcs[0] if rcs else None
                break

    proposal = {
        "version": "3.8",
        "created_at": datetime.now().isoformat(timespec='seconds'),
        "target": rel,
        "absolute_path": full,
        "original_sha256": hashlib.sha256(original.encode('utf-8')).hexdigest(),
        "proposed_sha256": hashlib.sha256(proposed.encode('utf-8')).hexdigest(),
        "changed": changed,
        "diff": diff[:50000],
        "verification": verification,
        "failure": {
            "test_name": failure.get('test_name',''),
            "message": failure.get('message',''),
            "tags": failure.get('tags',[]),
        },
        "root_cause": root_cause,
        "status": "pending" if changed else "no_safe_change",
    }
    _save_obj(V38_PATCH_FILE, proposal)
    return {"ok": True, "proposal": proposal}


def propose_code_patch(target=None):
    result = _proposal_from_failure(target)
    if not result.get('ok'):
        return result.get('message', '수정 제안을 만들지 못했어.')
    p = result['proposal']
    lines = [
        'C# 수정 제안 v3.8',
        f"대상: {p['target']}",
        f"상태: {'수정안 있음' if p['changed'] else '안전한 자동 수정 없음'}",
    ]
    rc = p.get('root_cause') or {}
    if rc:
        lines.append(f"원인 후보: [{float(rc.get('score',0)):.2f}] {rc.get('title','')}")
        if rc.get('reason'): lines.append(f"근거: {rc['reason']}")
        if rc.get('fix_hint'): lines.append(f"수정 방향: {rc['fix_hint']}")
    if p['changed']:
        lines.append('\n[적용 전 diff]')
        lines.append(p['diff'][:30000])
        lines.append("\n적용하려면 정확히 '수정적용 승인'이라고 입력해줘.")
    else:
        lines.append('\n현재 엔진으로는 추측성 코드를 자동 변경하지 않았어.')
        lines.append("원인과 코드 문맥만 확인하고 직접 수정하는 게 안전해.")
    lines.append(f"제안 저장: {V38_PATCH_FILE}")
    return '\n'.join(lines)


def apply_code_patch_approved():
    p = _load_obj(V38_PATCH_FILE, {})
    if not isinstance(p, dict) or p.get('status') != 'pending' or not p.get('changed'):
        return '적용 대기 중인 수정 제안이 없어. 먼저 수정제안을 만들어줘.'
    root = PROJECT.get('path')
    full = p.get('absolute_path')
    rel = p.get('target','')
    if not root or not full or not _project_safe(full) or not os.path.isfile(full):
        return '프로젝트가 바뀌었거나 대상 파일을 찾지 못했어. 수정안을 다시 만들어줘.'
    try:
        current = Path(full).read_text(encoding='utf-8', errors='replace')
        current_hash = hashlib.sha256(current.encode('utf-8')).hexdigest()
        if current_hash != p.get('original_sha256'):
            return '대상 파일이 수정안 생성 후 변경됐어. 안전을 위해 적용하지 않았어. 수정안을 다시 만들어줘.'
        backup = _backup_before_repair(full)
        if not backup:
            return '백업 생성에 실패해서 수정하지 않았어.'
        proposed_hash = p.get('proposed_sha256')
        # diff에서 재구성하지 않고 제안 당시 verification 결과의 코드를 사용한다.
        proposed = ((p.get('verification') or {}).get('code') or '')
        if not proposed:
            return '수정안의 제안 코드가 없어 적용하지 않았어.'
        Path(full).write_text(proposed, encoding='utf-8')
        after = verify_csharp(proposed, auto_fix=False, rounds=1)
        if not after.get('ok'):
            try:
                Path(full).write_text(current, encoding='utf-8')
            except Exception:
                pass
            return f"수정 후 검증 실패라 원본으로 되돌렸어. 백업: {backup}\n{after.get('analysis') or after.get('compiler',{}).get('output','')}"
        p['status'] = 'applied'
        p['applied_at'] = datetime.now().isoformat(timespec='seconds')
        p['backup'] = backup
        p['after_verification'] = after
        _save_obj(V38_PATCH_FILE, p)
        return f"✅ 수정안을 적용했어: {rel}\n백업: {backup}\n수정 후 정적 검증도 통과했어."
    except Exception as e:
        return f'수정안 적용 오류: {e}'


def handle_patch_review_command(text):
    t = str(text or '').strip()
    n = normalize(t)
    if n in ('수정제안','코드수정제안','수정안','패치제안','diff제안'):
        return propose_code_patch()
    m = re.match(r'(?:수정제안|코드수정제안|패치제안)\s*[:：]\s*(.+)$', t, re.I)
    if m:
        return propose_code_patch(m.group(1).strip())
    if n in ('수정적용승인','패치적용승인','코드수정적용승인'):
        return apply_code_patch_approved()
    return None

def analyze_latest_unity_failures():
    """가장 최근 Unity Test Runner 결과를 분석한다."""
    log=_load_obj(V35_TEST_LOG_FILE,{})
    if not isinstance(log, dict) or not log.get('results_file'):
        return '최근 Unity 테스트 결과가 없어. 먼저 테스트계획 실행을 해줘.'
    analysis=_analyze_unity_failure_result(log)
    if not analysis.get('failures'):
        return '최근 Unity 테스트에서 구체적인 실패 원인을 찾지 못했어. 로그/결과 XML을 확인해줘.'
    lines=[f"Unity 실패 원인 분석 v3.6", analysis.get('summary','')]
    for i,f in enumerate(analysis['failures'],1):
        lines.append(f"\n{i}. {f.get('test_name','')}")
        if f.get('classname'): lines.append(f"  클래스: {f['classname']}")
        if f.get('tags'): lines.append(f"  오류 유형: {', '.join(f['tags'])}")
        if f.get('message'): lines.append(f"  메시지: {f['message'][:700]}")
        cands=f.get('candidate_files') or []
        if cands:
            lines.append('  의심 파일:')
            for c in cands[:8]: lines.append(f"    - {c['path']}:{c['line']}")
    lines.append(f"\n분석 로그: {V36_FAILURE_LOG_FILE}")
    return '\n'.join(lines)

def run_unity_test_runner(platform='editmode', timeout=600):
    root = PROJECT.get('path')
    if not root or not unity_project_ok():
        return {"ok": False, "status": "warn", "message": "먼저 유효한 Unity 프로젝트를 선택해줘.", "platform": platform}
    if not _unity_project_has_tests(root):
        return {"ok": False, "status": "warn", "message": "Unity Test Runner 테스트를 찾지 못했어.", "platform": platform}
    exe = _find_unity_executable()
    if not exe:
        return {"ok": False, "status": "warn", "message": "Unity Editor를 찾지 못했어. UNITY_EDITOR_PATH를 설정해줘.", "platform": platform}
    platform = str(platform).lower().strip()
    if platform not in ('editmode', 'playmode'):
        platform = 'editmode'
    os.makedirs(V35_TEST_RESULTS_DIR, exist_ok=True)
    stamp = datetime.now().strftime('%Y%m%d_%H%M%S_%f')
    result_xml = os.path.join(V35_TEST_RESULTS_DIR, f'{platform}_{stamp}.xml')
    log_txt = os.path.join(V35_TEST_RESULTS_DIR, f'{platform}_{stamp}.log')
    cmd = [exe, '-batchmode', '-quit', '-projectPath', root, '-runTests', '-testPlatform', platform, '-testResults', result_xml, '-logFile', log_txt]
    started = time.time()
    try:
        proc = subprocess.run(cmd, capture_output=True, text=True, timeout=max(30, int(timeout)))
        parsed = _parse_unity_test_results(result_xml)
        parsed.update({'platform': platform, 'returncode': proc.returncode, 'elapsed': time.time()-started, 'log_file': log_txt, 'stdout_tail': (proc.stdout or '')[-3000:], 'stderr_tail': (proc.stderr or '')[-3000:]})
        if parsed.get('total', 0) == 0 and proc.returncode != 0:
            parsed['status'] = 'fail'
            parsed['message'] = f"Unity Test Runner 종료 코드 {proc.returncode}"
        elif parsed.get('total', 0) == 0:
            parsed['status'] = 'warn'
        _save_obj(V35_TEST_LOG_FILE, parsed)
        if parsed.get('status') == 'fail':
            parsed['failure_analysis'] = _analyze_unity_failure_result(parsed, root)
            _save_obj(V35_TEST_LOG_FILE, parsed)
        return parsed
    except subprocess.TimeoutExpired:
        return {"ok": False, "status": "fail", "message": f"Unity Test Runner 시간 초과({timeout}초)", "platform": platform}
    except Exception as e:
        return {"ok": False, "status": "fail", "message": f"Unity Test Runner 실행 오류: {e}", "platform": platform}

def run_unity_test_suite(platform='editmode'):
    r = run_unity_test_runner(platform)
    if r.get('status') == 'pass':
        return f"PASS — Unity {platform} 테스트 {r.get('passed',0)}/{r.get('total',0)} 통과 (실패 {r.get('failed',0)}, 건너뜀 {r.get('skipped',0)})"
    if r.get('status') == 'fail':
        msg=f"FAIL — Unity {platform} 테스트: 통과 {r.get('passed',0)}, 실패 {r.get('failed',0)}, 건너뜀 {r.get('skipped',0)} / 전체 {r.get('total',0)}. {r.get('message','')}"
        fa=(r.get('failure_analysis') or {}).get('failures',[])
        for f in fa[:3]:
            cand=f.get('candidate_files') or []
            if cand:
                msg += "\n  의심 파일: " + ", ".join(f"{c['path']}:{c['line']}" for c in cand[:4])
        return msg
    return f"WARN — Unity {platform} 테스트 미실행/테스트 없음. {r.get('message','')}"

# ──────────────────────────────────────────────
# v3.4 Automatic Repair Loop
# ──────────────────────────────────────────────
V34_REPAIR_MAX_ROUNDS = 5
V34_REPAIR_LOG_FILE = os.path.join(HERE, "ai_auto_repair_log.json")


def _backup_before_repair(full_path):
    try:
        backup_root = os.path.join(HERE, "ai_project_repair_backups")
        root = PROJECT.get("path") or HERE
        stamp = datetime.now().strftime("%Y%m%d_%H%M%S_%f")
        rel = os.path.relpath(full_path, root)
        safe_rel = rel.replace("\\", "__").replace("/", "__")
        out = os.path.join(backup_root, stamp + "__" + safe_rel)
        os.makedirs(os.path.dirname(out), exist_ok=True)
        shutil.copy2(full_path, out)
        return out
    except Exception:
        return None


def _safe_repair_csharp_file(relpath):
    """현재 정적 검사 엔진이 자동 수정할 수 있는 범위만 실제 파일에 적용."""
    root = PROJECT.get("path")
    if not root:
        return {"ok": False, "changed": False, "message": "프로젝트가 선택되지 않았어."}
    full = os.path.abspath(os.path.join(root, relpath))
    if not _project_safe(full) or not os.path.isfile(full):
        return {"ok": False, "changed": False, "message": "프로젝트 내부의 C# 파일이 아니야."}
    if not full.lower().endswith(".cs"):
        return {"ok": False, "changed": False, "message": "C# 파일이 아니야."}
    try:
        original = Path(full).read_text(encoding="utf-8", errors="replace")
        vr = verify_csharp(original, auto_fix=True, rounds=V34_REPAIR_MAX_ROUNDS)
        fixed = vr.get("code", original)
        if fixed == original:
            return {"ok": bool(vr.get("ok")), "changed": False, "message": "자동 수정할 항목이 없거나 정적 검사가 통과했어.", "verify": vr}
        backup = _backup_before_repair(full)
        if not backup:
            return {"ok": False, "changed": False, "message": "백업 생성에 실패해서 수정하지 않았어.", "verify": vr}
        Path(full).write_text(fixed, encoding="utf-8")
        after = verify_csharp(fixed, auto_fix=False, rounds=1)
        return {
            "ok": bool(after.get("ok")),
            "changed": True,
            "message": "자동 수정 및 재검증 완료" if after.get("ok") else "자동 수정했지만 재검증에서 문제가 남았어.",
            "backup": backup,
            "verify_before": vr,
            "verify_after": after,
        }
    except Exception as e:
        return {"ok": False, "changed": False, "message": f"자동 수정 오류: {e}"}


def _repair_test_failures_once():
    """실패 원인을 바탕으로 수정안을 만들기만 한다. 실제 파일 수정은 승인 후에만 가능하다."""
    _load_change_test_plan()
    repairs = []
    if not CHANGE_TEST_PLAN.get("tests"):
        return {"ok": False, "message": "저장된 테스트 계획이 없어.", "repairs": repairs}

    prioritized = []
    latest = _load_obj(V36_FAILURE_LOG_FILE, {})
    for f in (latest.get('failures', []) if isinstance(latest, dict) else []):
        for c in f.get('candidate_files', [])[:10]:
            if c.get('path') and c['path'] not in prioritized:
                prioritized.append(c['path'])

    candidates = list(prioritized)
    for t in CHANGE_TEST_PLAN.get("tests", []):
        status = t.get("status")
        action = t.get("action")
        target = t.get("target", "")
        if action == "analyze_csharp" and status in ("fail", "warn") and target and target not in candidates:
            candidates.append(target)

    for target in candidates:
        try:
            result = _proposal_from_failure(target)
            if not result.get("ok"):
                repairs.append({"target": target, "source": "proposal", "changed": False, "approved": False, "message": result.get("message", "수정안을 만들지 못했어.")})
                continue
            proposal = result.get("proposal", {})
            repairs.append({
                "target": target,
                "source": "proposal",
                "changed": bool(proposal.get("changed")),
                "approved": False,
                "status": proposal.get("status"),
                "proposal_file": V38_PATCH_FILE,
                "message": "수정안 생성 완료. 사용자 승인 전에는 파일을 변경하지 않아.",
            })
        except Exception as e:
            repairs.append({"target": target, "source": "proposal", "changed": False, "approved": False, "message": f"수정안 생성 오류: {e}"})

    return {
        "ok": True,
        "message": f"수정안 {sum(1 for r in repairs if r.get('changed'))}개 생성. 실제 파일 수정은 승인 필요",
        "prioritized_by_failure": prioritized,
        "repairs": repairs,
    }


def automatic_repair_cycle(max_rounds=V34_REPAIR_MAX_ROUNDS):
    """테스트 -> 자동 수정 -> 재테스트를 반복. 수정 가능한 C# 문제만 자동 처리."""
    _load_change_test_plan()
    if not CHANGE_TEST_PLAN.get("tests"):
        return "먼저 '변경테스트계획: 대상'으로 테스트 계획을 만들어줘."
    if not PROJECT.get("path"):
        return "먼저 Unity 프로젝트를 선택해줘."

    max_rounds = max(1, min(V34_REPAIR_MAX_ROUNDS, int(max_rounds)))
    cycle_log = []
    overall_ok = False

    for round_no in range(1, max_rounds + 1):
        execute_change_test_plan()
        _load_change_test_plan()
        fail_count = sum(t.get("status") == "fail" for t in CHANGE_TEST_PLAN.get("tests", []))
        warn_count = sum(t.get("status") == "warn" for t in CHANGE_TEST_PLAN.get("tests", []))
        cycle_log.append({"round": round_no, "fail": fail_count, "warn": warn_count, "phase": "test"})

        if fail_count == 0:
            overall_ok = True
            break

        rep = _repair_test_failures_once()
        cycle_log.append({"round": round_no, "phase": "proposal", "result": rep})
        changed = [x for x in rep.get("repairs", []) if x.get("changed")]
        # v3.8 안전 정책: 자동복구 루프는 실제 파일을 수정하지 않고
        # 수정안만 생성한다. 실제 적용은 반드시 '수정적용 승인'으로
        # 명시적으로 승인해야 한다.
        break

    _load_change_test_plan()
    final_fail = sum(t.get("status") == "fail" for t in CHANGE_TEST_PLAN.get("tests", []))
    final_warn = sum(t.get("status") == "warn" for t in CHANGE_TEST_PLAN.get("tests", []))
    overall_ok = final_fail == 0

    log = {
        "version": "3.6",
        "target": CHANGE_TEST_PLAN.get("target"),
        "finished_at": datetime.now().isoformat(timespec="seconds"),
        "ok": overall_ok,
        "final_fail": final_fail,
        "final_warn": final_warn,
        "cycles": cycle_log,
    }
    _save_obj(V34_REPAIR_LOG_FILE, log)

    lines = [
        f"자동 복구 루프 v3.8: {CHANGE_TEST_PLAN.get('target')}",
        f"최종 결과: {'✅ FAIL 없음' if overall_ok else '❌ FAIL 남음'}",
        f"라운드 최대 {max_rounds} · 최종 FAIL {final_fail} · WARN {final_warn}",
        f"로그: {V34_REPAIR_LOG_FILE}",
    ]
    if final_fail:
        lines.append("\nFAIL이 남아 있어. 수정안만 생성했으며 실제 파일 수정은 승인 후에만 수행돼.")
    else:
        lines.append("\n✅ 현재 테스트 FAIL은 없지만, 이 루프는 승인 없이는 파일을 수정하지 않아.")
    # 최근 수정 요약
    repairs = []
    for item in cycle_log:
        if item.get("phase") == "proposal":
            for r in item.get("result", {}).get("repairs", []):
                if r.get("changed"):
                    repairs.append(f"- {r.get('target')}: 수정안 생성됨 (승인 대기)" + (f" [{r.get('proposal_file')}]" if r.get('proposal_file') else ""))
    if repairs:
        lines.append("\n[자동 수정]")
        lines.extend(repairs[-15:])
    return "\n".join(lines)


def handle_failure_analysis_command(text):
    t = str(text or '').strip()
    n = normalize(t)
    if n in ('실패원인분석','유니티실패분석','테스트실패분석','실패분석'):
        return analyze_latest_unity_failures()
    if n in ('정밀실패분석','원인분석','코드원인분석','실패코드분석'):
        return analyze_latest_unity_root_causes()
    return None

def handle_auto_repair_command(text):
    t = str(text or "").strip()
    n = normalize(t)
    if n in ("자동복구", "자동복구실행", "테스트자동복구", "영향테스트자동복구"):
        return automatic_repair_cycle()
    m = re.match(r"(?:자동복구|자동복구실행)\s*(?:최대|max)\s*(\d+)\s*(?:회|번)?$", t, re.I)
    if m:
        return automatic_repair_cycle(int(m.group(1)))
    return None




# ──────────────────────────────────────────────
# v4.2 Development Orchestrator
# 요구사항 → 프로젝트 분석 → 영향도 → 테스트 계획 → 수정 제안 → 승인 → 테스트 → 벤치마크
# 실제 파일 수정은 기존의 "수정적용 승인" 경로에서만 수행한다.
# ──────────────────────────────────────────────
DEV_WORKFLOW_FILE = Path(HERE) / "ai_development_workflow.json"
DEV_WORKFLOW_VERSION = "4.2"


def _dev_save(state):
    try:
        _save_obj(str(DEV_WORKFLOW_FILE), state)
    except Exception:
        pass


def _dev_load():
    try:
        obj = _load_obj(str(DEV_WORKFLOW_FILE), {})
        return obj if isinstance(obj, dict) else {}
    except Exception:
        return {}


def _dev_keywords(text):
    n = normalize(text)
    keys=[]
    groups={
        "입력":("입력", "키보드", "마우스", "컨트롤러", "input"),
        "이동":("이동", "move", "걷기", "달리기", "점프", "jump"),
        "전투":("공격", "전투", "데미지", "체력", "hp", "공격력"),
        "애니메이션":("애니메이션", "animation", "animator"),
        "UI":("ui", "버튼", "canvas", "슬라이더", "메뉴"),
        "물리":("rigidbody", "collider", "물리", "충돌", "physics"),
        "저장":("저장", "세이브", "load", "save", "serialization"),
        "네트워크":("네트워크", "멀티", "network", "multiplayer"),
        "인벤토리":("인벤토리", "inventory", "아이템", "item"),
        "퀘스트":("퀘스트", "quest"),
    }
    for g, vals in groups.items():
        if any(v in n for v in vals): keys.append(g)
    return keys


def _dev_requirements(request):
    req = {
        "request": request.strip(),
        "keywords": _dev_keywords(request),
        "needs_project": bool(PROJECT.get("path")),
        "clarifications": [],
    }
    # 안전하게 물어볼 조건만 표시. 이미 프로젝트에 정보가 있으면 질문을 줄인다.
    if "UI" in req["keywords"] and not any(k in normalize(request) for k in ("uGUI", "uitoolkit", "ui toolkit", "canvas")):
        req["clarifications"].append("UI 방식(uGUI/Canvas 또는 UI Toolkit)을 정해야 해.")
    if "네트워크" in req["keywords"] and not any(k in normalize(request) for k in ("netcode", "mirror", "photon", "multiplayer")):
        req["clarifications"].append("멀티플레이 프레임워크(Netcode/Mirror/Photon 등)를 정해야 해.")
    if "저장" in req["keywords"] and not any(k in normalize(request) for k in ("json", "binary", "playerprefs", "scriptableobject")):
        req["clarifications"].append("저장 형식/방식(JSON, PlayerPrefs 등)을 정해야 해.")
    if not req["needs_project"]:
        req["clarifications"].append("실제 프로젝트 변경을 하려면 먼저 '프로젝트 선택'이 필요해.")
    return req


def _dev_plan_text(state):
    steps = state.get("steps", [])
    lines=[f"개발 작업 v{DEV_WORKFLOW_VERSION}: {state.get('request','')}",
           f"상태: {state.get('status','unknown')}",
           f"현재 단계: {state.get('current_step',0)}/{len(steps)}"]
    if state.get("clarifications"):
        lines.append("\n[먼저 확인할 조건]")
        lines.extend(f"- {x}" for x in state["clarifications"])
    if steps:
        lines.append("\n[작업 단계]")
        for i,s in enumerate(steps,1):
            mark="✅" if s.get("done") else ("▶" if i==state.get("current_step",0)+1 else "•")
            lines.append(f"{mark} {i}. {s.get('name','')}")
    if state.get("last_result"):
        lines.append("\n[최근 결과]\n" + str(state["last_result"])[:8000])
    return "\n".join(lines)


def start_development_workflow(request):
    req=_dev_requirements(request)
    steps=[
        {"name":"요구사항 확정", "done": False},
        {"name":"Unity 프로젝트 구조/코드 분석", "done": False},
        {"name":"영향도 분석 및 변경 테스트 계획", "done": False},
        {"name":"C# 수정안/Diff 생성", "done": False},
        {"name":"사용자 승인 후 변경 적용", "done": False},
        {"name":"Unity/정적 테스트 실행", "done": False},
        {"name":"실패 원인 분석 및 재검증", "done": False},
        {"name":"벤치마크 기록", "done": False},
    ]
    state={
        "version":DEV_WORKFLOW_VERSION,
        "created_at":datetime.now().isoformat(timespec="seconds"),
        "updated_at":datetime.now().isoformat(timespec="seconds"),
        "request":request.strip(),
        "status":"clarify" if req["clarifications"] else "ready",
        "current_step":0,
        "requirements":req,
        "clarifications":req["clarifications"],
        "steps":steps,
        "last_result":"",
    }
    _dev_save(state)
    if req["clarifications"]:
        return _dev_plan_text(state) + "\n\n필요한 조건을 알려주면 '개발다음'으로 계속 진행할 수 있어."
    return _dev_plan_text(state) + "\n\n준비됐어. '개발다음'으로 안전한 단계부터 진행할 수 있어."


def development_workflow_next():
    state=_dev_load()
    if not state.get("request"):
        return "진행 중인 개발 작업이 없어. '개발작업: ...'으로 시작해줘."
    if state.get("clarifications"):
        return _dev_plan_text(state)
    steps=state.get("steps",[])
    cur=int(state.get("current_step",0))
    if cur>=len(steps):
        return "개발 작업이 이미 끝났어.\n"+_dev_plan_text(state)

    request=state.get("request","")
    result=""
    # 단계 1: 요구사항 확정
    if cur==0:
        state["requirements"]["confirmed_at"]=datetime.now().isoformat(timespec="seconds")
        result="요구사항 구조화를 완료했어."
    # 단계 2: 프로젝트 분석
    elif cur==1:
        if not PROJECT.get("path"):
            state["clarifications"]=["먼저 '프로젝트 선택'으로 Unity 프로젝트를 연결해줘."]
            state["status"]="clarify"
            _dev_save(state)
            return _dev_plan_text(state)
        result=project_scan()
        try:
            graph=project_graph_analyze()
            result += "\n\n" + graph
        except Exception:
            pass
    # 단계 3: 영향도 + 테스트 계획
    elif cur==2:
        target=(state.get("target") or "").strip()
        if not target:
            # 프로젝트에서 요청 키워드와 관련된 C# 파일을 우선 후보로 찾는다.
            candidates=[]
            for f in project_files(limit=3000):
                if f.lower().endswith('.cs'):
                    rel=os.path.relpath(f, PROJECT["path"])
                    if any(k.lower() in rel.lower() for k in _dev_keywords(request)):
                        candidates.append(rel)
            target=candidates[0] if candidates else ""
            state["target"]=target
        if target:
            result=project_impact_analyze(target) if 'project_impact_analyze' in globals() else project_graph_related(target)
            try:
                result += "\n\n" + create_change_test_plan(target)
            except Exception:
                pass
        else:
            result="요청에 가장 직접적으로 대응하는 기존 C# 파일을 특정하지 못했어. 수정 전에 대상 파일을 지정해야 해."
            state["status"]="needs_target"
            _dev_save(state)
            return _dev_plan_text(state)
    # 단계 4: 수정안
    elif cur==3:
        target=state.get("target") or None
        result=propose_code_patch(target)
        if "수정안 있음" in result:
            state["status"]="awaiting_approval"
        else:
            state["status"]="manual_review"
    # 단계 5: 적용은 사용자의 명시 승인이 있어야만 진행
    elif cur==4:
        return _dev_plan_text(state)+"\n\n⛔ 실제 코드 변경은 자동으로 하지 않아. Diff를 확인한 뒤 정확히 '수정적용 승인'을 입력해줘."
    # 단계 6: 테스트
    elif cur==5:
        result=execute_change_test_plan()
    # 단계 7: 실패 분석
    elif cur==6:
        result=precision_failure_analysis()
    # 단계 8: 벤치마크
    elif cur==7:
        result=run_ai_benchmark(full=True, announce=True)

    steps[cur]["done"]=True
    state["current_step"]=cur+1
    state["last_result"]=str(result)
    state["updated_at"]=datetime.now().isoformat(timespec="seconds")
    if state["current_step"]>=len(steps): state["status"]="complete"
    _dev_save(state)
    return _dev_plan_text(state)


def handle_development_orchestrator(text):
    raw=str(text or "").strip()
    n=normalize(raw)
    for prefix in ("개발작업:", "개발 작업:", "개발시작:", "개발 시작:"):
        if raw.startswith(prefix):
            return start_development_workflow(raw.split(":",1)[1].strip())
    if n in ("개발상태","개발계획","개발작업상태","개발 진행상황"):
        state=_dev_load()
        return _dev_plan_text(state) if state.get("request") else "진행 중인 개발 작업이 없어. '개발작업: ...'으로 시작해줘."
    if n in ("개발다음","개발 다음","다음개발단계","다음 개발 단계"):
        return development_workflow_next()
    if n in ("개발취소","개발 작업 취소","개발초기화"):
        _dev_save({"version":DEV_WORKFLOW_VERSION,"status":"cancelled","updated_at":datetime.now().isoformat(timespec="seconds")})
        return "진행 중인 개발 작업을 취소했어. 이미 적용된 파일은 건드리지 않았어."
    return None


# ──────────────────────────────────────────────


# ──────────────────────────────────────────────
# v5.0 Final Review Gate — 실패 시 안전하게 멈추고 다시 시도
# 생성/수정과 검토를 분리한다. 검토 실패 시 자동 파일 수정은 하지 않는다.
# ──────────────────────────────────────────────
V50_REVIEW_DIR = Path(HERE) / "ai_final_review"
V50_REVIEW_DIR.mkdir(exist_ok=True)
V50_REVIEW_LATEST = V50_REVIEW_DIR / "latest.json"
V50_REVIEW_HISTORY = V50_REVIEW_DIR / "history.jsonl"

V50_REVIEW_CASES = [
    ("요구사항", ["request", "requirements"]),
    ("테스트", ["test", "plan"]),
    ("보안", ["security", "safe"]),
    ("변경최소성", ["diff", "patch"]),
    ("협업", ["approval", "review"]),
]

def _v50_write_review(report):
    try:
        V50_REVIEW_LATEST.write_text(json.dumps(report, ensure_ascii=False, indent=2), encoding="utf-8")
        with V50_REVIEW_HISTORY.open("a", encoding="utf-8") as f:
            f.write(json.dumps(report, ensure_ascii=False) + "\n")
    except Exception:
        pass

def _v50_final_review():
    state=_v49_load_job() if '_v49_load_job' in globals() else None
    job=dict(V49_JOB) if isinstance(V49_JOB,dict) else {}
    dev=_dev_load() if '_dev_load' in globals() else {}
    request=job.get("request") or dev.get("request") or ""
    findings=[]; checks=[]

    if not request:
        findings.append("작업 요구사항이 없어 최종 검토를 할 수 없음")
    else:
        checks.append({"name":"요구사항 기록", "passed": bool(dev.get("requirements") or request)})
        checks.append({"name":"변경 계획", "passed": bool(dev.get("steps"))})
        checks.append({"name":"테스트 계획", "passed": bool(dev.get("steps") and len(dev.get("steps")) >= 6)})
        checks.append({"name":"승인 게이트", "passed": True})
        # 최근 결과에 명시적 실패가 있으면 검토 실패로 판정
        blob=" ".join(str(x.get("last_result", "")) for x in [job, dev])
        if any(tok in blob.upper() for tok in ("FAIL", "ERROR", "실패", "⛔")):
            findings.append("최근 작업 결과에 실패/오류 신호가 있음")
        # 코드 리뷰 결과가 있으면 반영
        try:
            cr=Path(HERE)/"ai_code_review"/"latest.json"
            if cr.exists():
                data=json.loads(cr.read_text(encoding="utf-8"))
                score=float(data.get("overall_score", 100))
                checks.append({"name":"코드 리뷰", "passed": score >= 80, "score": score})
                if score < 80:
                    findings.append(f"코드 리뷰 점수 {score:.1f} < 80")
        except Exception as e:
            findings.append(f"코드 리뷰 결과를 읽지 못함: {e}")
        # 벤치마크 결과 반영
        try:
            b=Path(HERE)/"ai_benchmark"/"latest.json"
            if b.exists():
                data=json.loads(b.read_text(encoding="utf-8"))
                score=float(data.get("score", 0))
                checks.append({"name":"코딩 벤치마크", "passed": score >= 80, "score": score})
                if score < 80:
                    findings.append(f"벤치마크 점수 {score:.1f} < 80")
        except Exception:
            pass

    passed=sum(1 for c in checks if c.get("passed"))
    total=len(checks)
    verdict="PASS" if not findings and passed==total and total>0 else "REVIEW_REQUIRED"
    report={
        "version":"5.0",
        "timestamp":time.time(),
        "job_id":job.get("job_id", ""),
        "request":request,
        "verdict":verdict,
        "passed":passed,
        "total":total,
        "findings":findings,
        "checks":checks,
    }
    _v50_write_review(report)
    if job.get("job_id"):
        V49_JOB["last_review"]=report
        if verdict != "PASS":
            V49_JOB["status"]="paused_review"
            V49_JOB["last_action"]="final_review_failed"
            V49_JOB["last_result"]=f"최종 검토 결과 {verdict}: " + ("; ".join(findings) if findings else "추가 검토 필요")
        else:
            V49_JOB["status"]="review_passed"
            V49_JOB["last_action"]="final_review_passed"
            V49_JOB["last_result"]=f"최종 검토 PASS ({passed}/{total})"
        _v49_save_job()
    if verdict != "PASS":
        return "🛑 최종 검토에서 멈췄어.\n" + json.dumps(report, ensure_ascii=False, indent=2) + "\n\n수정안을 새로 만들어 다시 검토하려면 '검토재시도'를 사용해줘."
    return "✅ 최종 검토 PASS.\n" + json.dumps(report, ensure_ascii=False, indent=2)


def _v50_retry_review():
    _v49_load_job()
    if not V49_JOB.get("job_id"):
        return "진행 중인 작업이 없어."
    if V49_JOB.get("status") != "paused_review":
        return "지금은 최종 검토 실패로 멈춘 작업이 아니야. 먼저 '최종검토'를 실행해줘."
    # 실제 파일은 건드리지 않고 개발 워크플로를 안전한 재계획 지점으로 되돌린다.
    dev=_dev_load()
    if dev.get("request"):
        steps=dev.get("steps") or []
        for st in steps:
            st["done"]=False
        dev["current_step"]=2
        dev["status"]="ready"
        dev["last_result"]="최종 검토 실패로 인해 영향도/테스트 계획 단계부터 재검토하도록 되돌림"
        dev["updated_at"]=datetime.now().isoformat(timespec="seconds")
        _dev_save(dev)
    V49_JOB["status"]="running"
    V49_JOB["stage"]="impact"
    V49_JOB["stage_index"]=2
    V49_JOB["retry_count"]=int(V49_JOB.get("retry_count",0))+1
    V49_JOB["last_action"]="review_retry_requested"
    V49_JOB["last_result"]=f"최종 검토 실패 후 재시도 #{V49_JOB['retry_count']}. 기존 파일은 자동 수정하지 않았어."
    _v49_save_job()
    return "🔁 최종 검토가 실패해서 작업을 멈춘 뒤, 영향도/테스트 계획부터 다시 잡도록 되돌렸어. 기존 코드에는 자동 변경을 하지 않았어. 이제 '작업계속'으로 다시 진행해줘."


def _v50_review_commands(text):
    n=normalize(str(text or "").strip())
    if n in ("최종검토", "검토", "최종리뷰", "검토실행"):
        return _v50_final_review()
    if n in ("검토재시도", "검토다시", "최종검토재시도", "리뷰재시도"):
        return _v50_retry_review()
    if n in ("검토상태", "최종검토상태"):
        try:
            if V50_REVIEW_LATEST.exists():
                return V50_REVIEW_LATEST.read_text(encoding="utf-8")
        except Exception:
            pass
        return "최종 검토 기록이 없어."
    return None

# ──────────────────────────────────────────────
# v4.5 Git 통합 엔진
# ──────────────────────────────────────────────
GIT_AUDIT_DIR = os.path.join(HERE, "ai_git_audit")
os.makedirs(GIT_AUDIT_DIR, exist_ok=True)
GIT_LAST_PLAN = os.path.join(GIT_AUDIT_DIR, "last_commit_plan.json")
GIT_LAST_STATUS = os.path.join(GIT_AUDIT_DIR, "last_status.json")
GIT_PUSH_BLOCKED = True


def _git_root():
    root = PROJECT.get("path") or HERE
    root = os.path.abspath(root)
    return root if os.path.isdir(root) else None


def _git_exec(args, timeout=30, cwd=None):
    cwd = cwd or _git_root()
    if not cwd:
        return {"ok": False, "returncode": -1, "stdout": "", "stderr": "Git 저장소 경로가 없어."}
    try:
        p = subprocess.run(["git", *args], cwd=cwd, capture_output=True, text=True,
                           encoding="utf-8", errors="replace", timeout=timeout)
        return {"ok": p.returncode == 0, "returncode": p.returncode,
                "stdout": p.stdout.strip(), "stderr": p.stderr.strip(), "cwd": cwd}
    except FileNotFoundError:
        return {"ok": False, "returncode": -1, "stdout": "", "stderr": "git 실행 파일을 찾지 못했어."}
    except Exception as e:
        return {"ok": False, "returncode": -1, "stdout": "", "stderr": str(e)}


def git_available():
    r = _git_exec(["--version"], cwd=HERE)
    return bool(r.get("ok")) and r.get("stdout", "").startswith("git version")


def git_is_repo():
    return bool(_git_exec(["rev-parse", "--show-toplevel"]).get("ok"))


def git_repo_root():
    r = _git_exec(["rev-parse", "--show-toplevel"])
    return r.get("stdout") if r.get("ok") else None


def git_status():
    if not git_available():
        return "Git을 찾지 못했어. Git을 설치하고 PATH에 등록해줘."
    if not git_is_repo():
        return "현재 프로젝트가 Git 저장소가 아니야. 'git 저장소 초기화'를 먼저 실행해줘."
    branch = _git_exec(["branch", "--show-current"]).get("stdout") or "(detached)"
    porcelain = _git_exec(["status", "--porcelain=v1"]).get("stdout", "")
    entries = porcelain.splitlines() if porcelain else []
    lines = [f"Git 저장소: {git_repo_root()}", f"브랜치: {branch}", f"변경 파일: {len(entries)}개"]
    if entries:
        lines.append("변경 목록:")
        lines.extend(f"  {e}" for e in entries[:50])
        if len(entries) > 50:
            lines.append(f"  ...외 {len(entries)-50}개")
    else:
        lines.append("작업 트리가 깨끗해.")
    _save_obj(GIT_LAST_STATUS, {"branch": branch, "changed_files": len(entries), "entries": entries[:200],
                                "timestamp": datetime.now().isoformat()})
    return "\n".join(lines)


def git_diff(max_chars=12000):
    if not git_available():
        return "Git을 찾지 못했어."
    if not git_is_repo():
        return "현재 프로젝트가 Git 저장소가 아니야."
    r = _git_exec(["diff"], timeout=60)
    if not r.get("ok"):
        return f"git diff 실패: {r.get('stderr') or r.get('stdout')}"
    out = r.get("stdout", "")
    if not out:
        return "현재 비교할 변경 내용이 없어."
    return out if len(out) <= max_chars else out[:max_chars] + "\n... [diff 일부만 표시]"


def _safe_branch_name(name):
    name = re.sub(r"[^A-Za-z0-9._/-]+", "-", str(name or "").strip())
    name = re.sub(r"/{2,}", "/", name).strip("/.") or "task"
    return name if name.startswith("ai/") else "ai/" + name


def git_create_branch(name):
    if not git_available(): return "Git이 설치되어 있지 않아."
    if not git_is_repo(): return "현재 프로젝트가 Git 저장소가 아니야."
    branch = _safe_branch_name(name)
    r = _git_exec(["switch", "-c", branch], timeout=30)
    if not r.get("ok"):
        r = _git_exec(["checkout", "-b", branch], timeout=30)
    return f"새 AI 작업 브랜치를 만들고 이동했어: {branch}" if r.get("ok") else f"브랜치를 만들지 못했어: {r.get('stderr') or r.get('stdout')}"


def git_init_repo():
    if not git_available(): return "Git이 설치되어 있지 않아."
    if git_is_repo(): return f"이미 Git 저장소야: {git_repo_root()}"
    root = _git_root()
    r = _git_exec(["init"], cwd=root)
    return f"Git 저장소를 만들었어: {root}" if r.get("ok") else f"git init 실패: {r.get('stderr') or r.get('stdout')}"


def git_commit_plan():
    if not git_available(): return "Git이 설치되어 있지 않아."
    if not git_is_repo(): return "현재 프로젝트가 Git 저장소가 아니야."
    status = _git_exec(["status", "--porcelain=v1"]).get("stdout", "")
    if not status: return "커밋할 변경 사항이 없어."
    files = [line[3:].strip() if len(line) >= 3 else line for line in status.splitlines()]
    diff = git_diff(9000)
    lowered = (diff + "\n" + " ".join(files)).lower()
    prefix = "fix" if any(k in lowered for k in ("bug", "exception", "error", "nullreference")) else ("test" if "test" in lowered else "feat")
    subject = "update unity project" if any(k in lowered for k in (".unity", ".prefab", "monobehaviour", "unity")) else "update ai project"
    msg = f"{prefix}: {subject}"
    branch = _git_exec(["branch", "--show-current"]).get("stdout", "") or "(detached)"
    _save_obj(GIT_LAST_PLAN, {"message": msg, "files": files, "branch": branch, "timestamp": datetime.now().isoformat()})
    return ("커밋 제안을 만들었어. 아직 커밋하지 않았어.\n"
            f"브랜치: {branch}\n메시지 제안: {msg}\n변경 파일: {len(files)}개\n"
            f"확인 후 'git 커밋 승인: {msg}'라고 입력하면 커밋해.")


def git_commit_approved(message):
    if not git_available(): return "Git이 설치되어 있지 않아."
    if not git_is_repo(): return "현재 프로젝트가 Git 저장소가 아니야."
    if not _git_exec(["status", "--porcelain=v1"]).get("stdout", ""): return "커밋할 변경 사항이 없어."
    if not str(message).strip(): return "커밋 메시지가 비어 있어."
    add = _git_exec(["add", "-A"], timeout=60)
    if not add.get("ok"): return f"git add 실패: {add.get('stderr') or add.get('stdout')}"
    commit = _git_exec(["commit", "-m", str(message).strip()], timeout=120)
    if not commit.get("ok"): return f"커밋 실패: {commit.get('stderr') or commit.get('stdout')}"
    return f"커밋 완료: {message}\n{commit.get('stdout','')}"


def git_push_blocked():
    return "AI의 git push는 안전을 위해 막아뒀어. push는 직접 실행해줘."


def handle_git_command(text):
    raw = str(text or "").strip()
    n = normalize(raw)
    if n in ("git", "git도움말", "git사용법"):
        return "Git 명령: git 상태 / git diff / git 저장소 초기화 / git 작업브랜치: 이름 / git 커밋 준비 / git 커밋 승인: 메시지 / git push"
    if n in ("git상태", "gitstatus"): return git_status()
    if n in ("gitdiff", "git차이", "git변경사항"): return git_diff()
    if n in ("git저장소초기화", "gitinit"): return git_init_repo()
    if n.startswith("git작업브랜치:") or n.startswith("git브랜치:"):
        return git_create_branch(raw.split(":", 1)[1].strip())
    if n in ("git커밋준비", "git커밋계획", "git커밋제안"): return git_commit_plan()
    if n in ("gitpush", "git푸시"): return git_push_blocked()
    m = re.match(r"git\s*커밋\s*승인\s*:\s*(.+)$", raw, flags=re.IGNORECASE)
    if m: return git_commit_approved(m.group(1).strip())
    return None


# ──────────────────────────────────────────────
# v5.4 Measurement-First GroundTruth Harness
# ──────────────────────────────────────────────
# 원칙:
# 1) 평가 정답지는 RAG 코퍼스와 분리한다.
# 2) 실제 동작/검색 결과를 평가하고, 소스 문자열 존재 여부만으로 점수를 주지 않는다.
# 3) 측정되지 않은 verifier는 사용자 화면에서 ✅를 받지 못한다.
# 4) verifier 활성화 기준은 측정 전에 먼저 고정한다.
MEASUREMENT_VERSION = "5.4"
AI_GT_DIR = Path(__file__).resolve().parent / "ai_groundtruth"
AI_GT_CASES = Path(__file__).resolve().parent / "ai_coding_benchmark_cases.jsonl"
AI_GT_HISTORY = AI_GT_DIR / "history.jsonl"
AI_GT_LATEST = AI_GT_DIR / "latest.json"
AI_GT_POLICY = {
    "min_test_cases": 20,
    "min_cases_per_category": 2,
    "required_difficulties": ["easy", "medium", "hard"],
    "evidence_activation_delta_pp": 15.0,
    "unmeasured_weight": 0.0,
}
UNMEASURED_VERIFIERS = {"EvidenceVerifier", "TestVerifier", "SecurityVerifier"}
MEASURED_VERIFIERS = {"GroundTruthHarness", "CodeVerifier", "UnityVerifier"}


def _is_eval_artifact_name(name):
    """평가 정답/산출물/벤치마크 결과가 학습 코퍼스에 섞이지 않도록 경로를 차단한다."""
    raw = str(name or "").replace("\\", "/").lower()
    base = raw.rsplit("/", 1)[-1]
    blocked_parts = {"ai_benchmark", "ai_groundtruth", "groundtruth", "eval", "evaluation", "benchmark"}
    if any(part in blocked_parts for part in raw.split("/")):
        return True
    if base in {"latest.json", "history.jsonl", "ai_coding_benchmark_cases.jsonl"}:
        return True
    if base.endswith((".benchmark.json", ".benchmark.jsonl", ".groundtruth.json", ".groundtruth.jsonl")):
        return True
    return False


def _gt_load_cases():
    cases = []
    if not AI_GT_CASES.exists():
        return cases
    with AI_GT_CASES.open("r", encoding="utf-8") as f:
        for line_no, line in enumerate(f, 1):
            if not line.strip():
                continue
            obj = json.loads(line)
            obj["_line"] = line_no
            cases.append(obj)
    return cases


def _gt_validate_case(case):
    required = ["id", "category", "difficulty", "question", "required_facts", "forbidden_claims", "test_type"]
    missing = [k for k in required if k not in case]
    errors = []
    if missing:
        errors.append("missing=" + ",".join(missing))
    if case.get("difficulty") not in {"easy", "medium", "hard"}:
        errors.append("invalid difficulty")
    if not isinstance(case.get("required_facts", []), list):
        errors.append("required_facts must be list")
    if not isinstance(case.get("forbidden_claims", []), list):
        errors.append("forbidden_claims must be list")
    if not str(case.get("question", "")).strip():
        errors.append("empty question")
    return errors


def _gt_score_answer(answer, case):
    text = normalize(str(answer or ""))
    facts = [str(x) for x in (case.get("required_facts") or []) if str(x).strip()]
    forbidden = [str(x) for x in (case.get("forbidden_claims") or []) if str(x).strip()]
    fact_hits = sum(1 for fact in facts if normalize(fact) in text)
    forbidden_hits = sum(1 for bad in forbidden if normalize(bad) in text)
    fact_recall = fact_hits / max(1, len(facts))
    forbidden_rate = forbidden_hits / max(1, len(forbidden)) if forbidden else 0.0
    factuality = 1.0 if forbidden_hits == 0 else max(0.0, 1.0 - forbidden_rate)
    # 현재 측정 단계에서는 reference_answer 문자열 완전 일치로 점수를 왜곡하지 않는다.
    answer_score = 0.70 * fact_recall + 0.30 * factuality
    passed = bool(facts) and fact_recall >= 0.70 and forbidden_hits == 0
    return {
        "passed": passed,
        "fact_hits": fact_hits,
        "fact_total": len(facts),
        "fact_recall": round(fact_recall, 4),
        "forbidden_hits": forbidden_hits,
        "forbidden_total": len(forbidden),
        "factuality": round(factuality, 4),
        "answer_score": round(answer_score, 4),
    }


def _gt_run_case(case):
    errs = _gt_validate_case(case)
    if errs:
        return {"id": case.get("id"), "passed": False, "score": 0.0, "status": "invalid", "errors": errs}
    question = str(case.get("question", ""))
    try:
        answer, retrieval_score = search_docs(question)
    except Exception as e:
        return {"id": case.get("id"), "passed": False, "score": 0.0, "status": "error", "error": str(e)}
    scored = _gt_score_answer(answer, case)
    return {
        "id": case.get("id"),
        "category": case.get("category"),
        "difficulty": case.get("difficulty"),
        "test_type": case.get("test_type"),
        "passed": scored["passed"],
        "score": scored["answer_score"],
        "retrieval_score": round(float(retrieval_score or 0.0), 4),
        "answer": str(answer or "")[:1200],
        "metrics": scored,
        "source_refs_checked": False,
        "source_refs_note": "source_refs는 메타데이터 연결 검증기 활성화 전까지 점수에 반영하지 않음",
    }


def _gt_activation_state(cases, results):
    categories = Counter(str(c.get("category", "unknown")) for c in cases)
    difficulties = {str(c.get("difficulty")) for c in cases}
    structurally_ready = (
        len(cases) >= AI_GT_POLICY["min_test_cases"]
        and all(v >= AI_GT_POLICY["min_cases_per_category"] for v in categories.values())
        and set(AI_GT_POLICY["required_difficulties"]).issubset(difficulties)
    )
    measured_accuracy = (sum(1 for r in results if r.get("passed")) / max(1, len(results))) * 100.0
    return {
        "structurally_ready": structurally_ready,
        "case_count": len(cases),
        "category_counts": dict(categories),
        "difficulties": sorted(difficulties),
        "measured_accuracy": round(measured_accuracy, 2),
        "evidence_weight": AI_GT_POLICY["unmeasured_weight"],
        "evidence_status": "미측정",
    }


def run_groundtruth_harness(split="test", announce=True):
    start = time.perf_counter()
    cases = [c for c in _gt_load_cases() if str(c.get("split", "test")) == str(split)]
    results = [_gt_run_case(c) for c in cases]
    activation = _gt_activation_state(cases, results)
    passed = sum(1 for r in results if r.get("passed"))
    valid = sum(1 for r in results if r.get("status") != "invalid")
    score = (sum(float(r.get("score", 0.0)) for r in results) / max(1, len(results))) * 100.0
    elapsed_ms = round((time.perf_counter() - start) * 1000.0, 2)
    result = {
        "measurement_version": MEASUREMENT_VERSION,
        "timestamp": datetime.now().isoformat(timespec="seconds"),
        "split": split,
        "score": round(score, 2),
        "passed": passed,
        "total": len(results),
        "valid": valid,
        "elapsed_ms": elapsed_ms,
        "activation_policy": AI_GT_POLICY,
        "activation": activation,
        "verifiers": {
            "GroundTruthHarness": {"status": "measured", "weight": 1.0},
            "CodeVerifier": {"status": "unmeasured", "weight": 0.0},
            "UnityVerifier": {"status": "unmeasured", "weight": 0.0},
            "EvidenceVerifier": {"status": "unmeasured", "weight": 0.0},
            "TestVerifier": {"status": "unmeasured", "weight": 0.0},
            "SecurityVerifier": {"status": "unmeasured", "weight": 0.0},
        },
        "results": results,
        "limitations": [
            "현재 GroundTruth는 검색/답변의 required_facts와 forbidden_claims를 평가한다.",
            "source_refs의 실제 근거 연결 점수는 아직 활성화하지 않았다.",
            "검증되지 않은 verifier는 화면과 점수에서 미측정으로 취급한다.",
            "정답지 파일은 RAG 코퍼스에 자동으로 제외된다.",
        ],
    }
    AI_GT_DIR.mkdir(parents=True, exist_ok=True)
    AI_GT_LATEST.write_text(json.dumps(result, ensure_ascii=False, indent=2), encoding="utf-8")
    with AI_GT_HISTORY.open("a", encoding="utf-8") as f:
        f.write(json.dumps(result, ensure_ascii=False) + "\n")
    if announce:
        unmeasured = [k for k,v in result["verifiers"].items() if v["status"] == "unmeasured"]
        return (f"🧪 GroundTruth v{MEASUREMENT_VERSION}: {score:.2f}/100 ({passed}/{len(results)} 통과)\n"
                f"케이스 {len(results)}개 · 실행 {elapsed_ms:.0f}ms · 검증 대기: {', '.join(unmeasured)}\n"
                f"EvidenceVerifier: 미측정 (weight=0) · 활성화 규칙을 통과하기 전에는 ✅ 표시하지 않음\n"
                f"결과: {AI_GT_LATEST}")
    return result


def groundtruth_summary():
    if not AI_GT_LATEST.exists():
        return "아직 GroundTruth 측정 결과가 없어. 'GroundTruth 실행'을 먼저 해줘."
    try:
        r = json.loads(AI_GT_LATEST.read_text(encoding="utf-8"))
        v = r.get("verifiers", {})
        status_text = ", ".join(f"{k}:{('측정' if x.get('status')=='measured' else '미측정')}" for k,x in v.items())
        return (f"최근 GroundTruth: {r.get('score',0):.2f}/100 · {r.get('passed',0)}/{r.get('total',0)} 통과\n"
                f"케이스: {r.get('total',0)}개 · split={r.get('split')}\n"
                f"Verifier 상태: {status_text}\n"
                f"상세: {AI_GT_LATEST}")
    except Exception as e:
        return f"GroundTruth 결과를 읽지 못했어: {e}"


def handle_groundtruth_command(text):
    n = normalize(str(text or "").strip())
    if n in {"groundtruth실행", "groundtruth", "정답셋평가", "측정하네스실행", "측정실행", "v54평가"}:
        return run_groundtruth_harness("test", announce=True)
    if n in {"groundtruth결과", "groundtruth상태", "측정결과", "측정상태"}:
        return groundtruth_summary()
    return None


# v4.4 Coding AI Benchmark Engine
# 코딩 AI 전용 12개 영역을 매 버전마다 자동 측정한다.
# 주의: 외부 LLM 없이 실행 가능한 결정적 회귀/정적 벤치마크다.
# 실제 개발 능력의 최종 증명은 실제 Unity 저장소 fixture/테스트셋을 추가해 측정해야 한다.
# ──────────────────────────────────────────────
AI_BENCHMARK_VERSION = "5.4"
AI_BENCHMARK_DIR = Path(__file__).resolve().parent / "ai_benchmark"
AI_BENCHMARK_HISTORY = AI_BENCHMARK_DIR / "history.jsonl"
AI_BENCHMARK_LATEST = AI_BENCHMARK_DIR / "latest.json"
AI_BENCHMARK_CASES = Path(__file__).resolve().parent / "ai_coding_benchmark_cases.jsonl"
AI_BENCHMARK_WEIGHTS = {
    "requirements": 12.0,
    "code_understanding": 10.0,
    "debugging": 11.0,
    "testing": 10.0,
    "code_quality": 8.0,
    "maintainability": 7.0,
    "performance": 7.0,
    "security": 9.0,
    "framework_fit": 8.0,
    "repository_work": 8.0,
    "minimal_change": 5.0,
    "collaboration": 5.0,
}


def _bench_write_json(path, obj):
    AI_BENCHMARK_DIR.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(obj, ensure_ascii=False, indent=2, default=str), encoding="utf-8")


def _bench_append_history(obj):
    AI_BENCHMARK_DIR.mkdir(parents=True, exist_ok=True)
    with AI_BENCHMARK_HISTORY.open("a", encoding="utf-8") as f:
        f.write(json.dumps(obj, ensure_ascii=False, default=str) + "\n")


def _bench_case_result(category, name, ok, detail="", weight=1.0):
    return {
        "category": category,
        "name": name,
        "ok": bool(ok),
        "detail": str(detail),
        "weight": float(weight),
    }


def _bench_source_checks():
    try:
        source = Path(__file__).read_text(encoding="utf-8", errors="replace")
    except Exception as e:
        return {"source_read": False, "error": str(e)}
    checks = {
        "approval_function": "def apply_code_patch_approved" in source,
        "hash_check": "hashlib.sha256" in source,
        "backup": "backup" in source.lower(),
        "rollback": "rollback" in source.lower(),
        "unity_runner": "run_unity_tests" in source or "_run_unity_batch" in source,
        "collector": "start_collector" in source and "collector_status" in source,
        "benchmark": "def run_ai_benchmark" in source,
    }
    try:
        fn_src = inspect.getsource(automatic_repair_cycle)
        checks["no_direct_auto_repair_write"] = "_safe_repair_csharp_file(" not in fn_src
    except Exception:
        checks["no_direct_auto_repair_write"] = True
    return checks


def _bench_safe_static_code_metrics(code):
    text = str(code or "")
    lines = text.splitlines() or [""]
    metrics = {
        "lines": len(lines),
        "long_lines": sum(1 for x in lines if len(x) > 140),
        "debug_logs": text.count("Debug.Log"),
        "get_component": text.count("GetComponent<"),
        "find_calls": text.count("GameObject.Find("),
        "update_count": len(re.findall(r"\b(?:void\s+)?Update\s*\(", text)),
        "while_true": len(re.findall(r"while\s*\(\s*true\s*\)", text)),
        "process_start": text.count("Process.Start("),
        "sql_concat": len(re.findall(r"SELECT\s+.*\+\s*", text, re.I)),
        "hardcoded_secret": len(re.findall(r"(?:api[_-]?key|password|secret|token)\s*=\s*[\"']", text, re.I)),
        "empty_catch": len(re.findall(r"catch\s*\([^)]*\)\s*\{\s*\}", text, re.S)),
    }
    return metrics


def _bench_run_builtin():
    tests = []
    def add(category, name, ok, detail="", weight=1.0):
        tests.append(_bench_case_result(category, name, ok, detail, weight))

    # 1. 요구사항 해석력
    try:
        plan = create_plan("Unity 2D 플레이어 대시 기능 추가. 기존 이동은 깨지면 안 되고 스태미나를 사용해야 함")
        steps = plan.get("steps", []) if isinstance(plan, dict) else []
        add("requirements", "plan_generation", len(steps) >= 3, f"steps={len(steps)}")
        joined = " ".join(map(str, steps)).lower()
        add("requirements", "requirement_constraints_visible", any(k in joined for k in ["test", "기존", "대시", "검증", "영향"]), joined[:300])
        add("requirements", "clarification_api_exists", callable(create_plan) and callable(_dev_requirements), "clarification/planning APIs")
    except Exception as e:
        for n in ("plan_generation", "requirement_constraints_visible", "clarification_api_exists"):
            add("requirements", n, False, str(e))

    # 2. 기존 코드 이해력
    fixture = """using UnityEngine;\npublic class PlayerController : MonoBehaviour {\n    public float speed = 5f;\n    public Rigidbody rb;\n    void Update(){ rb.velocity = new Vector3(Input.GetAxisRaw(\"Horizontal\"), rb.velocity.y, 0); }\n}"""
    try:
        analysis = analyze_csharp_code(fixture)
        text = str(analysis or "")
        add("code_understanding", "csharp_analysis", bool(text.strip()), text[:300])
        add("code_understanding", "project_graph_api", callable(project_graph) if "project_graph" in globals() else callable(_project_guid_map), "graph/project map API")
        add("code_understanding", "impact_api", callable(analyze_project_impact) if "analyze_project_impact" in globals() else callable(_graph_neighbors), "impact/graph API")
    except Exception as e:
        for n in ("csharp_analysis", "project_graph_api", "impact_api"):
            add("code_understanding", n, False, str(e))

    # 3. 디버깅 능력
    bad = """using UnityEngine;\npublic class Bad : MonoBehaviour {\n  public Rigidbody rb;\n  void Update(){ while(true){} rb.velocity = target.velocity; }\n}"""
    try:
        out = str(analyze_csharp_code(bad) or "")
        add("debugging", "infinite_loop_detection", "while(true)" in out or "무한 루프" in out, out[:250])
        add("debugging", "null_risk_detection", any(k in out.lower() for k in ["null", "직렬화", "reference"]), out[:250])
        add("debugging", "failure_analysis_api", callable(precise_failure_analysis) if "precise_failure_analysis" in globals() else callable(_root_cause_candidates_for_failure), "failure analysis API")
    except Exception as e:
        for n in ("infinite_loop_detection", "null_risk_detection", "failure_analysis_api"):
            add("debugging", n, False, str(e))

    # 4. 테스트 능력
    try:
        add("testing", "test_plan_api", callable(create_change_test_plan), "change test plan")
        add("testing", "test_runner_api", callable(run_unity_tests) if "run_unity_tests" in globals() else callable(_run_unity_batch), "Unity Test Runner API")
        add("testing", "regression_plan_support", callable(_make_test_case) and callable(_save_change_test_plan), "regression plan helpers")
    except Exception as e:
        for n in ("test_plan_api", "test_runner_api", "regression_plan_support"):
            add("testing", n, False, str(e))

    # 5. 코드 품질
    try:
        generated = str(generate_unity_csharp("플레이어 이동 스크립트 만들어줘") or "")
        m = _bench_safe_static_code_metrics(generated)
        add("code_quality", "unity_markers", "UnityEngine" in generated and "MonoBehaviour" in generated, generated[:200])
        add("code_quality", "reasonable_length", m["lines"] <= 180, f"lines={m['lines']}")
        add("code_quality", "no_infinite_loop", m["while_true"] == 0, f"while_true={m['while_true']}")
    except Exception as e:
        for n in ("unity_markers", "reasonable_length", "no_infinite_loop"):
            add("code_quality", n, False, str(e))

    # 6. 유지보수성
    try:
        src = Path(__file__).read_text(encoding="utf-8", errors="replace")
        functions = re.findall(r"^def\s+([A-Za-z_]\w*)\s*\(", src, re.M)
        duplicate_like = len(functions) != len(set(functions))
        add("maintainability", "unique_function_names", not duplicate_like, f"functions={len(functions)}")
        add("maintainability", "version_defined", bool(re.search(r"LOCAL_ANSWER_VERSION\s*=", src)), "version marker")
        add("maintainability", "benchmark_history", AI_BENCHMARK_HISTORY.parent.name == "ai_benchmark", "history path")
    except Exception as e:
        for n in ("unique_function_names", "version_defined", "benchmark_history"):
            add("maintainability", n, False, str(e))

    # 7. 성능
    try:
        metrics = _bench_safe_static_code_metrics(bad)
        add("performance", "no_heavy_find_in_update", metrics["find_calls"] == 0, f"find={metrics['find_calls']}")
        add("performance", "no_obvious_update_getcomponent", not (metrics["update_count"] and metrics["get_component"] > 0), f"update={metrics['update_count']}, getcomponent={metrics['get_component']}")
        add("performance", "collector_status_available", isinstance(collector_status(), dict), "collector status")
    except Exception as e:
        for n in ("no_heavy_find_in_update", "no_obvious_update_getcomponent", "collector_status_available"):
            add("performance", n, False, str(e))

    # 8. 보안
    try:
        checks = _bench_source_checks()
        add("security", "approval_hash_backup", checks.get("approval_function") and checks.get("hash_check") and checks.get("backup"), str(checks))
        add("security", "rollback", checks.get("rollback"), str(checks))
        add("security", "remote_mode_scoped", checks.get("tailscale_mode", "TAILSCALE_MODE" in Path(__file__).read_text(encoding="utf-8", errors="replace")), "tailscale/LAN remote controls")
    except Exception as e:
        for n in ("approval_hash_backup", "rollback", "remote_mode_scoped"):
            add("security", n, False, str(e))

    # 9. 언어/프레임워크 적합성
    try:
        generated = str(generate_unity_csharp("Unity Rigidbody를 이용한 2D 점프 코드") or "")
        add("framework_fit", "unity_api_present", "UnityEngine" in generated, generated[:200])
        add("framework_fit", "mono_behaviour_present", "MonoBehaviour" in generated, generated[:200])
        add("framework_fit", "csharp_file_shape", "class " in generated and "{" in generated and "}" in generated, generated[:200])
    except Exception as e:
        for n in ("unity_api_present", "mono_behaviour_present", "csharp_file_shape"):
            add("framework_fit", n, False, str(e))

    # 10. 저장소 작업
    try:
        has_project_api = callable(project_graph) if "project_graph" in globals() else callable(_project_guid_map)
        has_file_api = callable(read_project_file) if "read_project_file" in globals() else callable(_read_small)
        has_impact_api = callable(analyze_project_impact) if "analyze_project_impact" in globals() else callable(_graph_neighbors)
        add("repository_work", "project_graph", has_project_api, "project graph")
        add("repository_work", "project_file_read", has_file_api, "project file reader")
        add("repository_work", "impact_analysis", has_impact_api, "impact analysis")
    except Exception as e:
        for n in ("project_graph", "project_file_read", "impact_analysis"):
            add("repository_work", n, False, str(e))

    # 11. 변경 최소성
    try:
        checks = _bench_source_checks()
        add("minimal_change", "patch_approval_gate", checks.get("approval_function"), str(checks))
        add("minimal_change", "rollback_path", checks.get("rollback"), str(checks))
        add("minimal_change", "automatic_repair_no_direct_write", checks.get("no_direct_auto_repair_write"), str(checks))
    except Exception as e:
        for n in ("patch_approval_gate", "rollback_path", "automatic_repair_no_direct_write"):
            add("minimal_change", n, False, str(e))

    # 12. 협업
    try:
        add("collaboration", "development_next", callable(development_workflow_next), "workflow next")
        add("collaboration", "development_state_store", callable(_dev_save) and callable(_dev_load), "workflow state persistence")
        add("collaboration", "benchmark_summary", callable(benchmark_summary), "benchmark summary")
    except Exception as e:
        for n in ("development_status", "development_cancel", "benchmark_summary"):
            add("collaboration", n, False, str(e))

    # 외부 실제 코딩 사례: question + expected_keywords 또는 static_checks를 지원한다.
    if AI_BENCHMARK_CASES.exists() and not _is_eval_artifact_name(AI_BENCHMARK_CASES.name):
        try:
            with AI_BENCHMARK_CASES.open("r", encoding="utf-8") as f:
                for i, line in enumerate(f):
                    if not line.strip() or i >= 200:
                        continue
                    case = json.loads(line)
                    category = str(case.get("category", "repository_work"))
                    q = str(case.get("question", ""))
                    kws = [str(x) for x in (case.get("expected_keywords", []) or [])]
                    if q and kws:
                        ok, score, detail = _bench_expected_retrieval(q, kws)
                        add(category, f"external_case_{i+1}", ok, f"score={score:.3f}; {detail}", 0.25)
        except Exception as e:
            add("collaboration", "external_case_loader", False, str(e), 0.25)
    return tests


def _bench_expected_retrieval(question, expected_keywords):
    try:
        answer, score = search_docs(question)
    except Exception as e:
        return False, 0.0, f"검색 예외: {e}"
    if not answer:
        return False, float(score or 0.0), "검색 결과 없음"
    norm = normalize(str(answer))
    hits = sum(1 for k in expected_keywords if normalize(k) in norm)
    ratio = hits / max(1, len(expected_keywords))
    return ratio >= 0.5, float(score or 0.0), f"keyword_hit={hits}/{len(expected_keywords)}"


def _bench_category_scores(tests):
    raw = {k: {"passed": 0, "total": 0, "score": 0.0} for k in AI_BENCHMARK_WEIGHTS}
    for t in tests:
        c = t["category"]
        if c not in raw:
            continue
        raw[c]["total"] += 1
        if t["ok"]:
            raw[c]["passed"] += 1
    for c, data in raw.items():
        data["score"] = round(100.0 * data["passed"] / data["total"], 2) if data["total"] else 0.0
    return raw


def run_ai_benchmark(full=True, announce=True):
    start = time.perf_counter()
    tests = _bench_run_builtin()
    elapsed = time.perf_counter() - start
    category_scores = _bench_category_scores(tests)
    total_w = sum(t["weight"] for t in tests) or 1.0
    score = 100.0 * sum(t["weight"] for t in tests if t["ok"]) / total_w
    passed = sum(1 for t in tests if t["ok"])
    result = {
        "benchmark_version": AI_BENCHMARK_VERSION,
        "app_version": LOCAL_ANSWER_VERSION,
        "benchmark_type": "coding_ai_engineering_regression",
        "timestamp": datetime.now().isoformat(timespec="seconds"),
        "score": round(score, 2),
        "passed": passed,
        "total": len(tests),
        "elapsed_ms": round(elapsed * 1000, 2),
        "category_scores": category_scores,
        "tests": tests,
        "limitations": [
            "외부 LLM 없이 측정하는 결정적 회귀 테스트임",
            "실제 Unity 저장소 fixture/테스트셋이 충분히 있어야 저장소 수준 능력을 평가할 수 있음",
            "점수는 코드 품질의 일부만 측정하며 실제 사용자 성능을 보장하지 않음",
        ],
    }
    previous = None
    if AI_BENCHMARK_HISTORY.exists():
        try:
            lines = AI_BENCHMARK_HISTORY.read_text(encoding="utf-8").splitlines()
            if lines:
                previous = json.loads(lines[-1])
        except Exception:
            previous = None
    if isinstance(previous, dict) and isinstance(previous.get("score"), (int, float)):
        result["delta_vs_previous"] = round(score - float(previous["score"]), 2)
    else:
        result["delta_vs_previous"] = None
    _bench_write_json(AI_BENCHMARK_LATEST, result)
    _bench_append_history(result)
    if announce:
        delta = result["delta_vs_previous"]
        delta_txt = "" if delta is None else f" / 이전 대비 {delta:+.2f}점"
        cat = ", ".join(f"{k}:{v['score']:.0f}" for k, v in category_scores.items())
        return f"🧪 코딩 AI 벤치마크 v{AI_BENCHMARK_VERSION}: {score:.2f}/100 ({passed}/{len(tests)} 통과){delta_txt}\n분야: {cat}\n실행 {elapsed*1000:.0f}ms\n결과: {AI_BENCHMARK_LATEST}"
    return result


def benchmark_summary():
    try:
        r = load_json(AI_BENCHMARK_LATEST)
        if not isinstance(r, dict):
            return "아직 벤치마크 기록이 없어."
        delta = r.get("delta_vs_previous")
        dt = "기준선 없음" if delta is None else f"이전 대비 {float(delta):+.2f}점"
        cats = r.get("category_scores", {}) or {}
        cat_txt = ", ".join(f"{k} {float(v.get('score',0)):.0f}" for k,v in cats.items())
        return (f"최근 코딩 AI 벤치마크: {float(r.get('score', 0)):.2f}/100 · "
                f"{r.get('passed',0)}/{r.get('total',0)} 통과 · {dt}\n"
                f"분야별: {cat_txt}\n"
                f"실행 {r.get('elapsed_ms',0)}ms · {r.get('timestamp','')}\n"
                f"상세: {AI_BENCHMARK_LATEST}")
    except Exception as e:
        return f"벤치마크 결과를 읽지 못했어: {e}"


def handle_benchmark_command(text):
    n = normalize(str(text or "").strip())
    if n in ("벤치마크", "평가", "ai평가", "성능평가", "벤치마크실행", "평가실행", "코딩벤치마크", "코딩벤치마크실행"):
        return run_ai_benchmark(full=True, announce=True)
    if n in ("벤치마크결과", "최근평가", "평가결과", "코딩벤치마크결과"):
        return benchmark_summary()
    return None




# ──────────────────────────────────────────────
# v4.6 CI / 회귀 테스트 게이트
# ──────────────────────────────────────────────
CI_AUDIT_DIR = os.path.join(HERE, 'ai_ci_audit')
os.makedirs(CI_AUDIT_DIR, exist_ok=True)
CI_LATEST = os.path.join(CI_AUDIT_DIR, 'latest.json')
CI_HISTORY = os.path.join(CI_AUDIT_DIR, 'history.jsonl')
CI_FAIL_ON_BENCHMARK_DROP = float(os.environ.get('MYAI_CI_MIN_SCORE', '0'))


def _ci_save(obj):
    _save_obj(CI_LATEST, obj)
    try:
        with open(CI_HISTORY, 'a', encoding='utf-8') as f:
            f.write(json.dumps(obj, ensure_ascii=False) + '\n')
    except Exception:
        pass


def _ci_python_compile():
    """현재 AI 파일 자체의 Python AST 컴파일 검사."""
    try:
        import py_compile
        path = os.path.abspath(__file__)
        py_compile.compile(path, doraise=True)
        return {'ok': True, 'status': 'pass', 'message': 'Python AST/bytecode 검사 통과', 'path': path}
    except Exception as e:
        return {'ok': False, 'status': 'fail', 'message': f'Python 컴파일 검사 실패: {e}'}


def _ci_git_snapshot():
    if not git_available() or not git_is_repo():
        return {'ok': True, 'status': 'warn', 'message': 'Git 저장소가 없어 Git 회귀 비교를 건너뜀'}
    status_raw = _git_exec(['status', '--porcelain=v1']).get('stdout', '')
    branch = _git_exec(['branch', '--show-current']).get('stdout', '') or '(detached)'
    diff = git_diff(16000)
    return {
        'ok': True,
        'status': 'pass',
        'branch': branch,
        'changed_files': len(status_raw.splitlines()) if status_raw else 0,
        'status_lines': status_raw.splitlines()[:200],
        'diff_preview': diff,
        'message': 'Git 상태/변경점 수집 완료',
    }


def _ci_unity_regression(include_playmode=False):
    """Unity 프로젝트가 연결되어 있고 테스트가 있으면 실제 EditMode/PlayMode 회귀 테스트 수행."""
    results = []
    if not PROJECT.get('path') or not unity_project_ok():
        return {'status': 'warn', 'results': [], 'message': 'Unity 프로젝트가 연결되지 않아 Unity 회귀 테스트를 건너뜀'}
    results.append(run_unity_test_runner('editmode'))
    if include_playmode:
        results.append(run_unity_test_runner('playmode'))
    bad = [r for r in results if r.get('status') == 'fail']
    good = [r for r in results if r.get('status') == 'pass']
    if bad:
        status = 'fail'
    elif good and all(r.get('status') == 'pass' for r in results):
        status = 'pass'
    else:
        status = 'warn'
    return {'status': status, 'results': results, 'message': f'Unity 회귀 테스트 {len(results)}개 실행'}


def run_ci_regression_gate(include_playmode=False):
    """v4.6 통합 CI 게이트: Python + 코딩 벤치마크 + Git + 선택적 Unity 회귀 테스트."""
    started = time.perf_counter()
    checks = []

    py = _ci_python_compile(); checks.append({'name': 'python_compile', **py})

    try:
        bench = run_ai_benchmark(full=True, announce=False)
        checks.append({'name': 'coding_benchmark', 'ok': bench.get('score', 0) >= CI_FAIL_ON_BENCHMARK_DROP,
                       'status': 'pass' if bench.get('score', 0) >= CI_FAIL_ON_BENCHMARK_DROP else 'fail',
                       'score': bench.get('score'), 'delta_vs_previous': bench.get('delta_vs_previous'),
                       'passed': bench.get('passed'), 'total': bench.get('total')})
    except Exception as e:
        checks.append({'name': 'coding_benchmark', 'ok': False, 'status': 'fail', 'message': str(e)})

    checks.append({'name': 'git_snapshot', **_ci_git_snapshot()})
    unity = _ci_unity_regression(include_playmode=include_playmode)
    checks.append({'name': 'unity_regression', **unity})

    failed = [c for c in checks if c.get('status') == 'fail' or c.get('ok') is False]
    warns = [c for c in checks if c.get('status') == 'warn']
    overall = 'fail' if failed else ('warn' if warns else 'pass')
    report = {
        'ci_version': '4.6',
        'timestamp': datetime.now().isoformat(timespec='seconds'),
        'status': overall,
        'elapsed_ms': round((time.perf_counter() - started) * 1000, 2),
        'checks': checks,
        'failed_checks': [c.get('name') for c in failed],
        'warning_checks': [c.get('name') for c in warns],
        'policy': {
            'min_benchmark_score': CI_FAIL_ON_BENCHMARK_DROP,
            'git_push_allowed': False,
            'code_change_requires_user_approval': True,
        },
    }
    _ci_save(report)
    lines = [f'🧪 CI 회귀 게이트: {overall.upper()}', f"실행 {report['elapsed_ms']:.0f}ms"]
    for c in checks:
        state = c.get('status', 'warn').upper()
        extra = ''
        if c.get('score') is not None:
            extra = f" score={c.get('score')}"
        if c.get('message'):
            extra += f" — {c.get('message')}"
        lines.append(f"[{state}] {c.get('name')}{extra}")
    if failed:
        lines.append('❌ 실패한 검사: ' + ', '.join(c.get('name') for c in failed))
    elif warns:
        lines.append('⚠️ 경고: ' + ', '.join(c.get('name') for c in warns))
    else:
        lines.append('✅ 모든 CI 게이트 통과')
    lines.append(f'보고서: {CI_LATEST}')
    return '\n'.join(lines)


def ci_summary():
    try:
        r = load_json(CI_LATEST)
        if not isinstance(r, dict):
            return '아직 CI 평가 기록이 없어.'
        return (f"최근 CI 게이트: {str(r.get('status','unknown')).upper()} · "
                f"실행 {r.get('elapsed_ms',0)}ms · {r.get('timestamp','')}\n"
                f"실패: {', '.join(r.get('failed_checks') or []) or '없음'}\n"
                f"경고: {', '.join(r.get('warning_checks') or []) or '없음'}\n"
                f"상세: {CI_LATEST}")
    except Exception as e:
        return f'CI 결과를 읽지 못했어: {e}'


def handle_ci_command(text):
    n = normalize(str(text or '').strip())
    if n in ('ci검사', 'ci실행', '회귀테스트', '자동회귀테스트', 'ci게이트', '품질게이트'):
        return run_ci_regression_gate(include_playmode=False)
    if n in ('ci전체검사', 'ciunity검사', 'ci전체'):
        return run_ci_regression_gate(include_playmode=True)
    if n in ('ci상태', '최근ci', 'ci결과'):
        return ci_summary()
    return None

def think(text):
    ci_cmd = handle_ci_command(text)
    if ci_cmd:
        return ci_cmd
    git_cmd = handle_git_command(text)
    if git_cmd:
        return git_cmd
    dev_cmd = handle_development_orchestrator(text)
    if dev_cmd:
        return dev_cmd
    groundtruth_cmd = handle_groundtruth_command(text)
    if groundtruth_cmd:
        return groundtruth_cmd
    benchmark_cmd = handle_benchmark_command(text)
    if benchmark_cmd:
        return benchmark_cmd
    collector_cmd = handle_collector_message(text)
    if collector_cmd:
        return collector_cmd
    v50_review = _v50_review_commands(text)
    if v50_review is not None:
        return v50_review

    patch_cmd = handle_patch_review_command(text)
    if patch_cmd:
        return patch_cmd
    failure_cmd = handle_failure_analysis_command(text)
    if failure_cmd:
        return failure_cmd
    auto_repair_cmd = handle_auto_repair_command(text)
    if auto_repair_cmd:
        return auto_repair_cmd
    impact_cmd = handle_project_impact_command(text)
    if impact_cmd:
        return impact_cmd
    change_test_cmd = handle_change_test_command(text)
    if change_test_cmd:
        return change_test_cmd
    graph_cmd = handle_project_graph_command(text)
    if graph_cmd:
        return graph_cmd
    v30_cmd = handle_v30_unity_command(text)
    if v30_cmd:
        return v30_cmd
    direct_cmd = handle_unity_direct_command(text)
    if direct_cmd:
        return direct_cmd
    project_cmd = handle_project_command(text)
    if project_cmd:
        return project_cmd

    text = text.strip()
    if not text:
        return "응? 아무 말도 안 했어!"

    mp = handle_memory_plan_command(text)
    if mp:
        return mp

    # (0) C# 코드 생성 전/후 자동 검증
    verify_result = handle_verify_command(text)
    if verify_result:
        return verify_result

    # (0.5) C#/Unity 코드 생성 및 정적 분석
    code_result = handle_code_command(text)
    if code_result:
        generated_code = extract_csharp_code(code_result)
        if generated_code:
            vr = verify_csharp(generated_code, auto_fix=True, rounds=VERIFY_MAX_ROUNDS)
            if vr.get("ok") or vr.get("code") != generated_code:
                prefix = code_result.split("```csharp", 1)[0].rstrip() if "```csharp" in code_result else "생성된 코드야."
                return prefix + "\n\n" + format_verification_result(vr)
        return code_result

    # (1) 지금 배우는 중이라면, 이번 말은 '정답'
    if pending["question"]:
        if text.rstrip().endswith("?"):
            pending["question"] = None    # 답 대신 새 질문이 왔네 -> 배우기 취소
        else:
            q = pending["question"]
            pending["question"] = None
            if normalize(text) in ("패스", "몰라도돼", "됐어", "몰라", "스킵", "넘어가"):
                return "알겠어! 그건 그냥 넘어갈게."
            LEARNED.append({"q": [q], "a": [text]})
            save_memory()
            return f"오! 하나 배웠다. 이제 '{q}'라고 하면 그렇게 대답할게. 한번 다시 물어봐!"

    # (2) 네가 직접 가르쳐준 문답이 최우선!
    entry, sc = best_knowledge(text, LEARNED)
    if entry and sc >= 0.6:
        return random.choice(entry["a"])

    # (3) 짧은 인사말("안녕", "농담해줘")은 파일 검색보다 잡담이 먼저
    b_entry, b_sc = best_knowledge(text, BUILT_IN)
    if b_entry and b_sc >= 0.999 and len(normalize(text)) <= 6:
        return random.choice(b_entry["a"])

    # (4) "내 이름은 민수야" 같은 네 얘기 -> 기억!
    if looks_like_self_fact(text):
        remember_fact(text)
        remember_long_term(text, source="conversation", importance=0.9)
        CONTEXT["topic"] = extract_keywords(text)[:4]
        return f"오, 그렇구나! \"{text.strip()}\" 기억해 둘게."

    # (5) 핵심 파악 -> 여러 지식 검색 -> 답변 생성 (자신 있을 때)
    #     이어지는 질문("그럼 간식은?", "걔는?")일 때만 직전 주제를 붙여서 검색
    followup = is_followup(text)
    extra = CONTEXT["topic"] if followup else []
    mem_answer = long_memory_answer(text)
    doc_answer, doc_sc = search_docs(text, extra)
    if mem_answer and not doc_answer:
        CONTEXT["topic"] = (extract_keywords(text) + extra)[:4]
        return mem_answer
    if doc_answer and doc_sc >= HIGH_MATCH:
        CONTEXT["topic"] = (extract_keywords(text) + extra)[:4]
        return doc_answer

    # (5.5) 이어지는 질문이면 애매한 지식이라도 스킬보다 먼저
    if followup and doc_answer and doc_sc >= LOW_MATCH:
        CONTEXT["topic"] = (extract_keywords(text) + extra)[:4]
        return doc_answer

    # (5.8) 자체 답변 생성 + 자기검증
    # 외부 LLM 없이 검색 근거를 조합한 뒤, 한 번 더 근거/수치/모순을 검사한다.
    if doc_answer and doc_sc >= LOW_MATCH:
        generated, verify_info = compose_and_verify_local_answer(text, doc_answer, doc_sc, HISTORY)
        if generated:
            CONTEXT["topic"] = (extract_keywords(text) + extra)[:4]
            return generated

    # (6) 특수 능력 (계산, 시간, 게임...)
    for skill in SKILLS:
        answer = skill(text)
        if answer:
            return answer

    # (7) 내장 지식 (인사, 잡담...)
    if b_entry and b_sc >= 0.6:
        return random.choice(b_entry["a"])

    # (8) 애매하지만 파일에 비슷한 지식이 있으면 그거라도
    if doc_answer and doc_sc >= LOW_MATCH:
        CONTEXT["topic"] = (extract_keywords(text) + extra)[:4]
        return doc_answer

    # (9) 그래도 모르면 -> 사용자에게 배운다!
    pending["question"] = text
    return "음... 그건 아직 모르는 말이야. 내가 뭐라고 답하면 좋을지 알려줄래? (넘어가려면 '패스')"


# ──────────────────────────────────────────────
# 7. 웹 화면 (크롬에 보여줄 채팅 페이지)
# ──────────────────────────────────────────────

# ========================= v6.0 UNIFIED WORKSPACE =========================
V6_NOTES_FILE = Path(HERE) / "ai_notes.json"

def _v6_load_json(path, default):
    try:
        p=Path(path)
        if p.exists(): return json.loads(p.read_text(encoding="utf-8"))
    except Exception: pass
    return default

def _v6_save_json(path, obj):
    try:
        Path(path).write_text(json.dumps(obj, ensure_ascii=False, indent=2), encoding="utf-8"); return True
    except Exception: return False

def v6_load_notes():
    d=_v6_load_json(V6_NOTES_FILE, []); return d if isinstance(d,list) else []

def v6_add_note(title, content, tags=None):
    notes=v6_load_notes(); now=datetime.now().isoformat(timespec="seconds")
    note={"id":secrets.token_hex(6),"title":str(title or "제목 없음").strip()[:200],"content":str(content or "").strip(),"tags":[str(x).strip() for x in (tags or []) if str(x).strip()],"created_at":now,"updated_at":now}
    notes.insert(0,note); v6_load_notes(); _v6_save_json(V6_NOTES_FILE, notes[:500]); return note

def v6_workspace_status():
    root=PROJECT.get('path') if isinstance(PROJECT,dict) else None
    cs=0
    if root and os.path.isdir(root):
        try: cs=sum(1 for _ in Path(root).rglob('*.cs'))
        except Exception: pass
    try: ds=dataset_stats()
    except Exception: ds={}
    try: bench=_v6_load_json(Path(HERE)/'ai_benchmark'/'latest.json',{})
    except Exception: bench={}
    return {"project":root or "","cs_files":cs,"notes":len(v6_load_notes()),"dataset":ds,"benchmark":bench if isinstance(bench,dict) else {},"mode":CURRENT_MODE if 'CURRENT_MODE' in globals() else MODE}

V6_PAGE = r'''<!doctype html><html lang="ko"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>my_ai v6.1</title>
<style>
:root{--bg:#f7f8fb;--card:#fff;--ink:#1d2433;--muted:#6b7280;--line:#dde2ea;--accent:#2b59c3;--accent2:#e9efff}
*{box-sizing:border-box}html,body{height:100%;margin:0}body{font-family:system-ui,-apple-system,Segoe UI,Roboto,Apple SD Gothic Neo,sans-serif;color:var(--ink);background:var(--bg)}
.app{display:flex;height:100vh;overflow:hidden}.side{width:220px;border-right:1px solid var(--line);background:#fff;padding:14px;display:flex;flex-direction:column;gap:7px}.brand{font-weight:800;font-size:18px;padding:8px 10px}.sub{font-size:11px;color:var(--muted);padding:0 10px 8px}.nav{border:0;background:transparent;text-align:left;padding:10px;border-radius:10px;cursor:pointer;font-size:13px}.nav:hover,.nav.active{background:var(--accent2);color:var(--accent);font-weight:700}.spacer{flex:1}.status{font-size:11px;color:var(--muted);padding:8px 10px;border-top:1px solid var(--line)}
.main{flex:1;display:flex;flex-direction:column;min-width:0}.top{height:56px;border-bottom:1px solid var(--line);background:#fff;display:flex;align-items:center;padding:0 18px}.title{font-weight:800;flex:1}.mode{font-size:12px;border:1px solid var(--line);padding:7px 10px;border-radius:8px}.panel{flex:1;overflow:auto;padding:20px}.section{display:none}.section.active{display:block}.grid{display:grid;grid-template-columns:repeat(auto-fit,minmax(220px,1fr));gap:14px}.card{background:#fff;border:1px solid var(--line);border-radius:14px;padding:16px}.card h3{margin:0 0 8px;font-size:14px}.metric{font-size:28px;font-weight:800}.muted{color:var(--muted);font-size:12px}.row{display:flex;gap:8px;flex-wrap:wrap}.btn{border:1px solid var(--line);background:#fff;padding:8px 12px;border-radius:9px;cursor:pointer}.btn.primary{background:var(--accent);color:#fff;border-color:var(--accent)}input,textarea{font:inherit;width:100%;border:1px solid var(--line);border-radius:10px;padding:10px}.note{border:1px solid var(--line);padding:12px;border-radius:10px;background:#fff;margin-top:10px}.note h4{margin:0 0 6px}.tag{display:inline-block;background:#f1f3f7;border-radius:999px;padding:3px 7px;font-size:11px;margin:2px}.chat{height:78vh;display:flex;flex-direction:column}.msgs{flex:1;overflow:auto}.bubble{max-width:80%;padding:10px 12px;border-radius:12px;margin:8px 0;white-space:pre-wrap}.u{margin-left:auto;background:#dfe8ff}.a{border:1px solid var(--line);background:#fff}.composer{display:flex;gap:8px;margin-top:10px}.composer textarea{height:70px;resize:none}
</style><style>
#chatWorkspace{height:78vh;display:flex;gap:10px}#chatSidebar{width:230px;display:flex;flex-direction:column;border:1px solid var(--line);border-radius:12px;background:#fbfcfe;overflow:hidden}#chatMain{flex:1;display:flex;flex-direction:column;min-width:0}.chatSideHead{display:flex;align-items:center;justify-content:space-between;padding:10px 12px;border-bottom:1px solid var(--line)}#chatSessions{overflow:auto;padding:8px}.chatSession{display:flex;gap:4px;align-items:center;margin-bottom:6px}.chatSession button:first-child{flex:1;text-align:left;border:0;background:transparent;padding:8px;border-radius:8px;cursor:pointer;font-size:12px}.chatSession.active button:first-child{background:#eaf0ff;font-weight:700}.chatSession .del{border:0;background:transparent;cursor:pointer;color:#999;padding:5px}.chatSession .del:hover{color:#d33}@media(max-width:800px){#chatSidebar{display:none}}
</style>
</head><body><div class="app"><aside class="side"><div class="brand">my_ai v6.1</div><div class="sub">Unified AI Workspace</div>
<button class="nav active" data-tab="home">🏠 홈</button><button class="nav" data-tab="chat">💬 채팅</button><button class="nav" data-tab="notes">📝 노트</button><button class="nav" data-tab="knowledge">📚 지식</button><button class="nav" data-tab="coding">💻 코딩</button><button class="nav" data-tab="unity">🎮 Unity</button><button class="nav" data-tab="tests">🧪 테스트</button><button class="nav" data-tab="eval">📊 평가</button><button class="nav" data-tab="git">🔧 Git</button><div class="spacer"></div><div id="sideStatus" class="status">상태 읽는 중…</div></aside>
<main class="main"><header class="top"><div id="pageTitle" class="title">홈</div><select id="modeSelect" class="mode" onchange="setMode(this.value)"><option value="flash">⚡ Flash</option><option value="think">🧠 사고</option><option value="deep">🔬 심층</option><option value="coding">💻 코딩</option><option value="unity">🎮 Unity</option></select></header><div class="panel">
<section id="home" class="section active"><div class="grid"><div class="card"><h3>프로젝트</h3><div id="mProject" class="metric">-</div><div id="mPath" class="muted"></div></div><div class="card"><h3>지식 자료</h3><div id="mDocs" class="metric">-</div></div><div class="card"><h3>노트</h3><div id="mNotes" class="metric">-</div></div><div class="card"><h3>벤치마크</h3><div id="mBench" class="metric">-</div></div></div><div class="card" style="margin-top:14px"><h3>빠른 작업</h3><div class="row"><button class="btn primary" onclick="openTab('chat')">새 채팅</button><button class="btn" onclick="openTab('notes')">노트</button><button class="btn" onclick="preset('통합 수집 시작 최대 50')">📚 수집 시작</button><button class="btn" onclick="preset('개발상태')">💻 작업 상태</button><button class="btn" onclick="preset('ci 검사')">🧪 CI</button><button class="btn" onclick="preset('git 상태')">🔧 Git</button></div></div></section>
<section id="chat" class="section"><div class="chat"><div id="msgs" class="msgs"></div><div class="composer"><textarea id="chatInput" placeholder="질문하거나 작업을 지시해…"></textarea><button class="btn primary" onclick="sendChat()">보내기</button></div></div></section>
<section id="notes" class="section"><div class="card"><h3>새 노트</h3><input id="noteTitle" placeholder="제목" style="margin-bottom:8px"><textarea id="noteBody" placeholder="내용" style="height:120px"></textarea><div class="row" style="margin-top:8px"><button class="btn primary" onclick="saveNote()">저장</button><button class="btn" onclick="loadNotes()">새로고침</button></div></div><div id="notesList"></div></section>
<section id="knowledge" class="section"><div class="card"><h3>지식</h3><p class="muted">수집된 지식을 검색하거나 현재 데이터 파이프라인 상태를 확인해.</p><div class="row"><button class="btn primary" onclick="preset('통합 파이프라인 상태')">파이프라인 상태</button><button class="btn" onclick="promptKnowledge()">지식 검색</button></div><pre id="knowledgeStats" class="muted" style="margin-top:12px"></pre></div></section>
<section id="coding" class="section"><div class="card"><h3>코딩</h3><p class="muted">요구사항 → 계획 → Diff → 승인 → 테스트 → 검토 → Git</p><div class="row"><button class="btn primary" onclick="promptDev()">개발 요청</button><button class="btn" onclick="preset('개발상태')">작업 상태</button><button class="btn" onclick="preset('검토상태')">최종 검토</button><button class="btn" onclick="preset('코드리뷰')">코드 리뷰</button><button class="btn" onclick="preset('영향커버리지상태')">영향 커버리지</button><button class="btn" onclick="preset('작업을 노트로 저장')">작업 → 노트</button></div></div></section>
<section id="unity" class="section"><div class="card"><h3>Unity</h3><div class="row"><button class="btn primary" onclick="preset('프로젝트 선택')">프로젝트 선택</button><button class="btn" onclick="preset('프로젝트 분석')">프로젝트 분석</button><button class="btn" onclick="preset('씬 구조 분석')">씬 구조</button><button class="btn" onclick="preset('GUI벤치마크')">GUI 벤치마크</button></div></div></section>
<section id="tests" class="section"><div class="card"><h3>테스트</h3><div class="row"><button class="btn primary" onclick="preset('ci 검사')">CI 검사</button><button class="btn" onclick="preset('GroundTruth 평가')">GroundTruth</button><button class="btn" onclick="preset('GUI벤치마크')">GUI 벤치마크</button><button class="btn" onclick="preset('코딩벤치마크 실행')">코딩 벤치마크</button></div></div></section>
<section id="eval" class="section"><div class="card"><h3>평가</h3><pre id="evalStats" class="muted"></pre></div></section>
<section id="git" class="section"><div class="card"><h3>Git</h3><div class="row"><button class="btn" onclick="preset('git 상태')">상태</button><button class="btn" onclick="preset('git diff')">Diff</button><button class="btn" onclick="preset('git 커밋 준비')">커밋 준비</button></div></div></section>
</div></main></div>
<script>
const $=s=>document.querySelector(s), $$=s=>document.querySelectorAll(s); const titles={home:'홈',chat:'채팅',notes:'노트',knowledge:'지식',coding:'코딩',unity:'Unity',tests:'테스트',eval:'평가',git:'Git'};
function openTab(id){$$('.section').forEach(x=>x.classList.toggle('active',x.id===id));$$('.nav').forEach(x=>x.classList.toggle('active',x.dataset.tab===id));$('#pageTitle').textContent=titles[id]||id;if(id==='notes')loadNotes();if(id!=='chat')loadStatus();}
$$('.nav').forEach(b=>b.onclick=()=>openTab(b.dataset.tab));
function msg(t,c){const d=document.createElement('div');d.className='bubble '+c;d.textContent=t;$('#msgs').appendChild(d);$('#msgs').scrollTop=$('#msgs').scrollHeight;}
async function sendChat(){const el=$('#chatInput'),m=el.value.trim();if(!m)return;el.value='';msg(m,'u');const r=await fetch('/chat',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({message:m})});const j=await r.json();msg(j.reply||j.answer||j.error||'응답 없음','a');loadStatus();}
function preset(t){openTab('chat');$('#chatInput').value=t;sendChat();}
function esc(s){return String(s??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));}
async function loadNotes(){const a=await fetch('/notes').then(r=>r.json());$('#notesList').innerHTML=a.map(n=>`<div class="note"><h4>${esc(n.title)}</h4><div class="muted">${esc(n.created_at)}</div><p style="white-space:pre-wrap">${esc(n.content)}</p></div>`).join('');}
async function saveNote(){const t=$('#noteTitle').value.trim(),c=$('#noteBody').value.trim();if(!c)return;await fetch('/notes',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({title:t,content:c,tags:[]})});$('#noteTitle').value='';$('#noteBody').value='';loadNotes();loadStatus();}
async function loadStatus(){try{const s=await fetch('/workspace-status').then(r=>r.json());$('#mProject').textContent=s.project?'연결됨':'없음';$('#mPath').textContent=s.project||'';$('#mNotes').textContent=s.notes??'-';$('#mDocs').textContent=(s.dataset&&s.dataset.count)||'-';$('#mBench').textContent=(s.benchmark&&s.benchmark.score!=null)?Number(s.benchmark.score).toFixed(2):'-';$('#sideStatus').textContent='온라인';$('#knowledgeStats').textContent=JSON.stringify(s.dataset||{},null,2);$('#evalStats').textContent=JSON.stringify(s.benchmark||{},null,2);}catch(e){$('#sideStatus').textContent='상태 읽기 실패';}}
loadStatus();
async function setMode(m){try{await fetch('/mode',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({mode:m})});loadStatus();}catch(e){}}
async function promptKnowledge(){const q=prompt('지식 검색어를 입력해줘');if(q){openTab('chat');$('#chatInput').value='지식검색: '+q;sendChat();}}
async function promptDev(){const q=prompt('개발할 기능을 입력해줘');if(q){openTab('chat');$('#chatInput').value='개발요청: '+q;sendChat();}}

</script></body></html>'''

PAGE = r"""<!DOCTYPE html>
<html lang="ko">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0, viewport-fit=cover">
<title>나의 수제 AI</title>
<style>
  :root{
    --paper:#F6F7F2; --ink:#22303A; --ink-soft:#5B6B76;
    --line:rgba(34,48,58,.16); --grid:rgba(34,48,58,.055);
    --cobalt:#2B59C3; --cobalt-deep:#1F449C; --card:#FFF;
    --ok:#2FA36B; --radius:14px;
    --mono:ui-monospace,"SF Mono","Cascadia Mono",Consolas,monospace;
  }
  *{box-sizing:border-box;margin:0;padding:0}
  html,body{height:100%}
  body{
    font-family:-apple-system,BlinkMacSystemFont,"Apple SD Gothic Neo","Pretendard","Malgun Gothic","Noto Sans KR",sans-serif;
    background:var(--paper); color:var(--ink);
    display:flex; flex-direction:column; height:100dvh; overflow:hidden;
  }
  header{
    position:relative;
    flex:none; display:flex; align-items:center; gap:10px;
    padding:12px 16px; border-bottom:1.5px solid var(--ink); background:var(--paper);
  }
  .avatar{width:34px;height:34px;border:1.5px solid var(--ink);border-radius:50%;
    display:grid;place-items:center;background:var(--card);font-size:15px;flex:none}
  .head-txt{flex:1;min-width:0}
  .head-txt h1{font-size:16px;font-weight:700;letter-spacing:-.02em}
  .status{display:flex;align-items:center;gap:5px;font-size:11.5px;color:var(--ink-soft)}
  .status .led{width:7px;height:7px;border-radius:50%;background:var(--ok);animation:pulse 2.2s infinite}
  @keyframes pulse{0%,100%{opacity:1}50%{opacity:.35}}
  .tag{font-family:var(--mono);font-size:10.5px;letter-spacing:.04em;color:var(--ink-soft);
    border:1px solid var(--line);border-radius:6px;padding:3px 7px;background:var(--card);flex:none}
  .hbtn{flex:none;font-size:12px;color:var(--ink-soft);background:none;border:none;
    padding:6px 4px;cursor:pointer;font-family:inherit}
  .hbtn:hover{color:var(--ink)}
  .mode-wrap{position:relative;flex:none}
  .mode-btn{display:flex;align-items:center;gap:6px;font-size:12px;color:var(--ink);
    background:var(--card);border:1.5px solid var(--ink);border-radius:8px;padding:7px 9px;
    cursor:pointer;font-family:inherit;white-space:nowrap}
  .mode-btn .chev{font-size:10px;color:var(--ink-soft)}
  .mode-menu{position:absolute;z-index:30;right:0;top:44px;width:236px;background:var(--card);
    border:1.5px solid var(--ink);border-radius:12px;box-shadow:0 10px 28px rgba(34,48,58,.16);padding:6px;display:none}
  .mode-menu.open{display:block}
  .mode-item{display:flex;align-items:center;gap:9px;width:100%;padding:10px;border:none;background:transparent;
    border-radius:8px;cursor:pointer;text-align:left;font-family:inherit;color:var(--ink)}
  .mode-item:hover{background:var(--paper)}
  .mode-check{width:16px;text-align:center;font-size:14px;flex:none}
  .mode-copy{min-width:0}
  .mode-name{font-size:13px;font-weight:700;line-height:1.2}
  .mode-desc{font-size:11px;color:var(--ink-soft);margin-top:2px}
  .mode-item.active{background:#F0F3FB}
  #power{color:#C0452F;font-weight:600}
  #chat{
    flex:1; overflow-y:auto; padding:18px 14px 10px;
    background-image:linear-gradient(var(--grid) 1px,transparent 1px),
      linear-gradient(90deg,var(--grid) 1px,transparent 1px);
    background-size:24px 24px; scroll-behavior:smooth;
  }
  #chat.dragging{outline:3px dashed var(--cobalt);outline-offset:-8px}
  .msg{display:flex;margin-bottom:12px;animation:rise .25s ease both}
  @keyframes rise{from{opacity:0;transform:translateY(6px)}to{opacity:1;transform:none}}
  .msg.user{justify-content:flex-end}
  .bubble{max-width:80%;padding:10px 14px;font-size:14.5px;line-height:1.55;
    white-space:pre-wrap;word-break:break-word;border-radius:var(--radius)}
  .msg.ai .bubble{background:var(--card);border:1.5px solid var(--ink);border-bottom-left-radius:4px}
  .msg.user .bubble{background:var(--cobalt);color:#fff;border-bottom-right-radius:4px}
  .dots{display:inline-flex;gap:4px;padding:3px 0}
  .dots i{width:6px;height:6px;border-radius:50%;background:var(--ink-soft);animation:hop 1.1s infinite}
  .dots i:nth-child(2){animation-delay:.15s}
  .dots i:nth-child(3){animation-delay:.3s}
  @keyframes hop{0%,60%,100%{transform:none;opacity:.4}30%{transform:translateY(-4px);opacity:1}}
  #chips{flex:none;display:flex;gap:8px;padding:0 14px 10px;overflow-x:auto}
  .chip{flex:none;font-size:13px;font-family:inherit;color:var(--ink);background:var(--card);
    border:1.5px solid var(--ink);border-radius:999px;padding:8px 14px;cursor:pointer}
  .chip:active{background:var(--ink);color:var(--paper)}
  footer{flex:none;display:flex;gap:8px;padding:10px 14px calc(12px + env(safe-area-inset-bottom));
    background:var(--paper);border-top:1.5px solid var(--ink)}
  #clip{flex:none;width:46px;height:46px;border-radius:50%;border:1.5px solid var(--ink);
    background:var(--card);font-size:17px;cursor:pointer;display:grid;place-items:center}
  #clip:hover{background:var(--paper)}
  #input{flex:1;min-width:0;font-size:16px;font-family:inherit;color:var(--ink);background:var(--card);
    border:1.5px solid var(--ink);border-radius:999px;padding:11px 16px;outline:none}
  #input:focus-visible{box-shadow:0 0 0 3px rgba(43,89,195,.25)}
  #send{flex:none;width:46px;height:46px;border-radius:50%;border:1.5px solid var(--cobalt-deep);
    background:var(--cobalt);color:#fff;font-size:18px;cursor:pointer;display:grid;place-items:center;
    transition:transform .12s ease}
  #send:hover{transform:scale(1.06)}
  #send:disabled{opacity:.45;cursor:default;transform:none}
  #bye{height:100%;display:none;place-items:center;text-align:center;padding:20px}
  @media (prefers-reduced-motion:reduce){*{animation:none!important;transition:none!important}}
</style>
</head>
<body>

<header>
  <div class="avatar">🤖</div>
  <div class="head-txt">
    <h1>나의 수제 AI</h1>
    <div class="status"><span class="led"></span>온라인 · 인터넷 없이 작동</div>
  </div>
  <div class="mode-wrap">
    <button class="mode-btn" id="modeBtn" type="button"><span id="modeBtnName">5.4 사고 모델</span><span class="chev">⌄</span></button>
    <div class="mode-menu" id="modeMenu" role="menu" aria-label="AI 모델 선택">
      <button class="mode-item" data-mode="flash" role="menuitem"><span class="mode-check" id="check-flash"></span><span class="mode-copy"><div class="mode-name">5.4 Flash</div><div class="mode-desc">빠른 답변</div></span></button>
      <button class="mode-item" data-mode="think" role="menuitem"><span class="mode-check" id="check-think">✓</span><span class="mode-copy"><div class="mode-name">5.4 사고 모델</div><div class="mode-desc">복잡한 문제 해결</div></span></button>
      <button class="mode-item" data-mode="deep" role="menuitem"><span class="mode-check" id="check-deep"></span><span class="mode-copy"><div class="mode-name">5.4 심층 분석</div><div class="mode-desc">근거와 충돌까지 깊게 분석</div></span></button>
      <button class="mode-item" data-mode="coding" role="menuitem"><span class="mode-check" id="check-coding"></span><span class="mode-copy"><div class="mode-name">5.4 코딩</div><div class="mode-desc">코드 생성·디버깅·리뷰</div></span></button>
      <button class="mode-item" data-mode="unity" role="menuitem"><span class="mode-check" id="check-unity"></span><span class="mode-copy"><div class="mode-name">5.4 Unity</div><div class="mode-desc">Unity 프로젝트 전용</div></span></button>
    </div>
  </div>
  <button class="hbtn" id="reset">새 대화</button>
  <button class="hbtn" id="power">끄기</button>
</header>

<div id="chatWorkspace"><aside id="chatSidebar"><div class="chatSideHead"><b>채팅 기록</b><button id="newChatBtn" class="hbtn">＋</button></div><div id="chatSessions"></div></aside><div id="chatMain"><div id="chat"></div><div id="chips">
  <button class="chip">플레이어가 벽을 통과해! Rigidbody는 정상이고 Collider도 있어</button>
  <button class="chip">3 + 5 * 2</button>
  <button class="chip">가위바위보</button>
  <button class="chip">농담해줘</button>
  <button class="chip">무슨 파일 배웠어?</button>
</div>

<footer>
  <button id="project" class="hbtn" title="Unity 프로젝트 선택/분석">🎮</button><button id="bulk" class="hbtn" title="폴더째 대량 학습">📚</button><button id="clip" title="파일 가르쳐주기">📎</button>
  <input type="file" id="file" accept=".txt,.md,.csv,.log,.cs,.json,.xml,.uxml,.uss,.shader" hidden>
  <input type="file" id="dirIn" webkitdirectory directory multiple hidden>
  <input id="input" type="text" placeholder="메시지 입력 · 📎로 파일 학습" autocomplete="off">
  <button id="send" aria-label="보내기">➤</button>
</footer></div></div>

<div id="bye">
  <div>
    <div style="font-size:42px;margin-bottom:12px">💤</div>
    <b>AI를 재웠어요</b><br>
    <span style="color:var(--ink-soft);font-size:14px">이 창은 닫아도 돼요.<br>다시 켜려면 파일을 더블클릭!</span>
  </div>
</div>

<script>
const MYAI_AUTH = new URLSearchParams(location.search).get("token") || "";
const withToken = (path) => MYAI_AUTH ? path + (path.includes("?") ? "&" : "?") + "token=" + encodeURIComponent(MYAI_AUTH) : path;
const chat  = document.getElementById("chat");
const input = document.getElementById("input");
const send  = document.getElementById("send");
const chips = document.getElementById("chips");
const reset = document.getElementById("reset");
const power = document.getElementById("power");
const clip  = document.getElementById("clip");
const fileIn = document.getElementById("file");
const dirIn = document.getElementById("dirIn");
const bulk = document.getElementById("bulk");
const projectBtn = document.getElementById("project");
const modeBtn = document.getElementById("modeBtn");
const modeBtnName = document.getElementById("modeBtnName");
const modeMenu = document.getElementById("modeMenu");
const modeItems = Array.from(document.querySelectorAll(".mode-item"));

const GREETING = "안녕! 나는 API 없이 밑바닥부터 만들어진 AI야 🤖 모르는 건 너한테 배우고, 📎 버튼으로 파일을 주면 그 내용도 공부해!";
let busy = false;

const MODE_UI = {
  flash: {name:"5.4 Flash", msg:"⚡ Flash 모드로 바꿨어. 빠르게 답할게!"},
  think: {name:"5.4 사고 모델", msg:"✓ 사고 모델로 바꿨어. 복잡한 문제는 더 깊게 확인할게!"},
  deep: {name:"5.4 심층 분석", msg:"🔬 심층 분석 모드야. 근거와 충돌까지 더 깊게 볼게!"},
  coding: {name:"5.4 코딩", msg:"💻 코딩 모드야. 코드·테스트·리뷰에 집중할게!"},
  unity: {name:"5.4 Unity", msg:"🎮 Unity 모드야. 프로젝트 구조와 Unity 문제에 집중할게!"},
};
function updateModeUI(status){
  const mode = status?.mode || "think";
  const meta = MODE_UI[mode] || MODE_UI.think;
  modeBtnName.textContent = meta.name;
  modeItems.forEach(item => {
    const active = item.dataset.mode === mode;
    item.classList.toggle("active", active);
    const c = item.querySelector(".mode-check");
    if(c) c.textContent = active ? "✓" : "";
  });
}

async function loadMode(){
  try{
    const r = await fetch(withToken("/mode_status"));
    if(r.ok) updateModeUI(await r.json());
  }catch(e){}
}

modeBtn.addEventListener("click", (e) => {
  e.stopPropagation();
  modeMenu.classList.toggle("open");
});

document.addEventListener("click", () => modeMenu.classList.remove("open"));
modeMenu.addEventListener("click", e => e.stopPropagation());
modeItems.forEach(item => {
  item.addEventListener("click", async () => {
    if(busy) return;
    const mode = item.dataset.mode;
    modeBtn.disabled = true;
    try{
      const r = await fetch(withToken("/mode"), {
        method:"POST",
        headers:{"Content-Type":"application/json"},
        body:JSON.stringify({mode})
      });
      const data = await r.json();
      if(r.ok && data.ok){
        updateModeUI(data);
        modeMenu.classList.remove("open");
        addMsg("ai", (MODE_UI[mode] || MODE_UI.think).msg);
      } else {
        addMsg("ai", "모드 변경에 실패했어.");
      }
    }catch(e){
      addMsg("ai", "모드 변경 중 문제가 생겼어.");
    }finally{
      modeBtn.disabled = false;
    }
  });
});

async function refreshChatSessions(){try{const r=await fetch(withToken("/chat_sessions"));const d=await r.json();const box=document.getElementById("chatSessions");if(!box)return;box.innerHTML="";(d.sessions||[]).forEach(s=>{const row=document.createElement("div");row.className="chatSession "+(s.id===d.current_id?"active":"");const b=document.createElement("button");b.textContent=(s.title||"새 채팅")+" · "+(s.message_count||0);b.onclick=()=>openChatSession(s.id);const del=document.createElement("button");del.className="del";del.textContent="×";del.onclick=async(e)=>{e.stopPropagation();if(confirm("이 채팅을 삭제할까?")){await fetch(withToken("/chat_session"),{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify({action:"delete",id:s.id})});await openChatSession(null);}};row.appendChild(b);row.appendChild(del);box.appendChild(row);});}catch(e){}}
async function openChatSession(id){try{const body=id?{action:"select",id}:{action:"new"};const r=await fetch(withToken("/chat_session"),{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify(body)});const d=await r.json();if(r.ok&&d.ok){chat.innerHTML="";const msgs=(d.session?.messages)||[];if(!msgs.length)addMsg("ai",GREETING);msgs.forEach(m=>addMsg(m.role==="user"?"user":"ai",m.content||""));chips.style.display=msgs.length?"none":"flex";await refreshChatSessions();input.focus();}}catch(e){}}
async function exportCurrentChat(){try{const r=await fetch(withToken("/chat_sessions"));const d=await r.json();const id=d.current_id;if(!id)return;const rr=await fetch(withToken("/chat_session"),{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify({action:"select",id})});const x=await rr.json();const title=(x.session?.title||"chat").replace(/[\\/:*?"<>|]/g,"_");const text=(x.session?.messages||[]).map(m=>`[${m.role}] ${m.content||""}`).join("\n\n");const a=document.createElement("a");a.href=URL.createObjectURL(new Blob([text],{type:"text/plain;charset=utf-8"}));a.download=title+".txt";a.click();setTimeout(()=>URL.revokeObjectURL(a.href),500);}catch(e){}}

function addMsg(role, text){
  const wrap = document.createElement("div");
  wrap.className = "msg " + role;
  const b = document.createElement("div");
  b.className = "bubble";
  b.textContent = text;
  wrap.appendChild(b);
  chat.appendChild(wrap);
  chat.scrollTop = chat.scrollHeight;
  return wrap;
}

function addTyping(){
  const wrap = document.createElement("div");
  wrap.className = "msg ai";
  wrap.innerHTML = '<div class="bubble"><span class="dots"><i></i><i></i><i></i></span></div>';
  chat.appendChild(wrap);
  chat.scrollTop = chat.scrollHeight;
  return wrap;
}

async function ask(text){
  if(busy) return;
  const t = text.trim();
  if(!t) return;

  busy = true; send.disabled = true;
  chips.style.display = "none";
  input.value = "";

  addMsg("user", t);
  const typing = addTyping();

  try{
    const res = await fetch(withToken("/chat"), {
      method:"POST",
      headers:{"Content-Type":"application/json"},
      body:JSON.stringify({message:t})
    });
    const data = await res.json();
    await new Promise(r => setTimeout(r, 250 + Math.random()*450));
    typing.remove();
    addMsg("ai", data.reply || data.error || "응답 없음");
    refreshChatSessions();
  }catch(err){
    typing.remove();
    addMsg("ai", "(AI가 꺼져 있나 봐. 파일을 다시 더블클릭해서 켜줘!)");
  }finally{
    busy = false; send.disabled = false;
    input.focus();
  }
}

// ── 파일 학습 ──
async function sendFile(f){
  if(busy || !f) return;
  if(f.size > 100*1024*1024){
    addMsg("ai", "으, 파일이 너무 커! 100MB보다 작은 파일로 부탁해.");
    return;
  }
  busy = true; send.disabled = true;
  chips.style.display = "none";

  addMsg("user", "📄 " + f.name);
  const typing = addTyping();

  try{
    const b64 = await new Promise((res, rej) => {
      const r = new FileReader();
      r.onload = () => res(r.result.split(",")[1]);
      r.onerror = () => rej(new Error("read fail"));
      r.readAsDataURL(f);
    });
    const resp = await fetch(withToken("/learn_file"), {
      method:"POST",
      headers:{"Content-Type":"application/json"},
      body:JSON.stringify({name:f.name, data:b64})
    });
    const data = await resp.json();
    await new Promise(r => setTimeout(r, 500));
    typing.remove();
    addMsg("ai", data.reply);
  }catch(err){
    typing.remove();
    addMsg("ai", "(파일을 읽다가 뭔가 꼬였어. 텍스트 파일(.txt)로 다시 줘볼래?)");
  }finally{
    busy = false; send.disabled = false;
    input.focus();
  }
}

async function sendFolder(files){
  const list = Array.from(files || []).filter(f => {
    const path = String(f.webkitRelativePath || f.name || "").replace(/\\/g, "/");
    if (/\/(?:ai_benchmark|ai_groundtruth|groundtruth|evaluation|benchmark)(?:\/|$)/i.test("/" + path)) return false;
    if (/^(?:latest\.json|history\.jsonl|ai_coding_benchmark_cases\.jsonl)$/i.test(f.name)) return false;
    return /\.(txt|md|csv|log|cs|json|xml|uxml|uss|shader)$/i.test(f.name);
  });
  if(!list.length){ addMsg("ai", "폴더 안에 읽을 수 있는 텍스트/C#/Unity 파일이 없어."); return; }
  if(busy) return;
  busy = true; send.disabled = true; chips.style.display = "none";
  addMsg("user", "📚 폴더 학습: " + list.length + "개 파일");
  const typing = addTyping();
  let ok=0, fail=0, chunks=0;
  try{
    for(const f of list){
      if(f.size > 100*1024*1024){ fail++; continue; }
      const b64 = await new Promise((res, rej) => { const r=new FileReader(); r.onload=()=>res(r.result.split(",")[1]); r.onerror=()=>rej(new Error("read")); r.readAsDataURL(f); });
      const resp = await fetch("/learn_file", {method:"POST", headers:{"Content-Type":"application/json"}, body:JSON.stringify({name:f.webkitRelativePath||f.name, data:b64})});
      const data = await resp.json();
      if(resp.ok){ ok++; const m = String(data.reply).match(/청크 (\d+)개/); if(m) chunks += Number(m[1]); } else fail++;
    }
    typing.remove();
    addMsg("ai", `폴더 학습 완료!\n성공 ${ok}개 / 실패 ${fail}개 / 처리한 청크 약 ${chunks}개\n지식은 디스크에 저장했고 검색용 인덱스는 RAM 보호를 위해 제한해서 올렸어.`);
  }catch(err){ typing.remove(); addMsg("ai", "대량 학습 중 문제가 생겼어: " + err.message); }
  finally{ busy=false; send.disabled=false; input.focus(); }
}

clip.addEventListener("click", () => fileIn.click());
fileIn.addEventListener("change", () => { if(fileIn.files[0]) sendFile(fileIn.files[0]); fileIn.value = ""; });

bulk.addEventListener("click", () => dirIn.click());
dirIn.addEventListener("change", () => { sendFolder(dirIn.files); dirIn.value = ""; });

// 파일을 채팅창에 끌어다 놓아도 학습
chat.addEventListener("dragover", e => { e.preventDefault(); chat.classList.add("dragging"); });
chat.addEventListener("dragleave", () => chat.classList.remove("dragging"));
chat.addEventListener("drop", e => {
  e.preventDefault();
  chat.classList.remove("dragging");
  if(e.dataTransfer.files[0]) sendFile(e.dataTransfer.files[0]);
});


projectBtn.addEventListener("click", async () => {
  if(busy) return;
  busy=true; send.disabled=true;
  addMsg("user", "🎮 Unity 프로젝트 선택");
  const typing=addTyping();
  try{
    const r1=await fetch(withToken("/project_choose"), {method:"POST"});
    const d1=await r1.json();
    typing.remove();
    addMsg("ai", d1.reply);
    if(d1.path){
      addMsg("ai", "프로젝트를 분석할까? 채팅에 '프로젝트 분석'이라고 입력하면 돼.");
    }
  }catch(e){ typing.remove(); addMsg("ai", "프로젝트 선택 중 문제가 생겼어."); }
  finally{busy=false; send.disabled=false; input.focus();}
});

send.addEventListener("click", () => ask(input.value));
input.addEventListener("keydown", e => {
  if(e.key === "Enter" && e.ctrlKey && !e.isComposing && e.keyCode !== 229){
    e.preventDefault();
    ask(input.value);
  }
});
chips.addEventListener("click", e => {
  if(e.target.classList.contains("chip")) ask(e.target.textContent);
});
reset.addEventListener("click", async () => { await openChatSession(null); input.focus(); });

document.getElementById("newChatBtn")?.addEventListener("click",()=>openChatSession(null));
document.getElementById("chatListBtn")?.addEventListener("click",()=>document.getElementById("chatSidebar")?.scrollIntoView({behavior:"smooth"}));
document.getElementById("exportChat")?.addEventListener("click",exportCurrentChat);
refreshChatSessions();

power.addEventListener("click", async () => {
  if(!confirm("AI를 끌까? (다시 켜려면 파일을 더블클릭)")) return;
  try{ await fetch(withToken("/shutdown"), {method:"POST"}); }catch(e){}
  document.querySelector("header").style.display = "none";
  chat.style.display = "none";
  chips.style.display = "none";
  document.querySelector("footer").style.display = "none";
  document.getElementById("bye").style.display = "grid";
});

// 3초마다 "나 살아있어" 신호 -> 창을 닫으면 AI가 알아서 꺼짐
setInterval(() => { fetch(withToken("/ping")).catch(() => {}); }, 3000);

addMsg("ai", GREETING);
</script>
</body>
</html>
"""




import argparse
import hashlib
import json
import os
import re
import time
import urllib.error
import urllib.parse
import urllib.request
import urllib.robotparser
import xml.etree.ElementTree as ET
from collections import Counter, deque
from pathlib import Path
from typing import Iterable

DEFAULT_UA = "MyAI-AutoCollector/2.2 (+local Unity-CSharp collector)"
CATEGORY_BUDGET_GB = {
    "csharp": 400,
    "unity_api": 300,
    "unity_projects": 300,
    "game_systems": 200,
    "debugging": 150,
    "optimization": 100,
    "qa": 50,
}
CATEGORY_ORDER = list(CATEGORY_BUDGET_GB)
CATEGORY_LABELS = {
    "csharp": "C#",
    "unity_api": "Unity API",
    "unity_projects": "Unity 프로젝트",
    "game_systems": "게임 시스템",
    "debugging": "디버깅",
    "optimization": "최적화",
    "qa": "문제 해결/Q&A",
}
CATEGORY_BUDGET_BYTES = {k: v * 1_000_000_000 for k, v in CATEGORY_BUDGET_GB.items()}

CATEGORY_TERMS = {
    "csharp": {"c#": 8, "csharp": 8, "linq": 8, "async": 8, "await": 8, "garbage collection": 6, "oop": 6, "generics": 6, "delegate": 5, "interface": 5, "dotnet": 5},
    "unity_api": {"unityengine": 10, "monobehaviour": 9, "gameobject": 8, "transform": 7, "rigidbody": 7, "collider": 7, "physics": 7, "animator": 7, "scriptableobject": 8, "canvas": 5, "shader": 5, "scene": 5, "prefab": 6},
    "unity_projects": {"assets/scripts": 10, "projectsettings": 8, "prefab": 7, "scene": 7, "asmdef": 8, "unity project": 10, "repository": 2, "project": 3},
    "game_systems": {"inventory": 10, "combat": 10, "battle": 9, "quest": 9, "save/load": 8, "save system": 8, "dialogue": 7, "enemy ai": 8, "equipment": 7, "skill system": 8},
    "debugging": {"debug": 9, "troubleshoot": 10, "error": 8, "exception": 8, "nullreference": 10, "missingreference": 9, "stack trace": 8, "bug": 7, "fix": 5, "issue": 5},
    "optimization": {"optimization": 10, "profiler": 10, "performance": 10, "cpu": 7, "gpu": 7, "draw call": 10, "memory": 8, "gc alloc": 9, "batching": 7, "frame time": 7},
    "qa": {"q&a": 10, "faq": 10, "how to": 8, "question": 6, "answer": 6, "why": 5, "discussion": 5},
}
RELEVANT = {"unity": 5, "unityengine": 7, "monobehaviour": 8, "gameobject": 6, "component": 4, "transform": 4, "rigidbody": 6, "collider": 6, "physics": 5, "animator": 5, "prefab": 5, "scriptableobject": 7, "scene": 3, "shader": 5, "c#": 6, "csharp": 5, "linq": 4, "async": 4, "task": 3, "exception": 2, "dotnet": 4}

DEFAULT_SEEDS = [
    ("unity_api", "https://docs.unity3d.com/kr/current/Manual/index.html"),
    ("unity_api", "https://docs.unity3d.com/kr/current/ScriptReference/index.html"),
    ("csharp", "https://learn.microsoft.com/ko-kr/dotnet/csharp/"),
]
DEFAULT_ALLOWED = ["docs.unity3d.com", "learn.microsoft.com"]
OPEN_LICENSES = {"MIT", "Apache-2.0", "BSD-2-Clause", "BSD-3-Clause", "MPL-2.0", "Unlicense", "CC0-1.0", "CC-BY-4.0", "CC-BY-SA-4.0"}
CODE_EXTS = {".cs", ".asmdef", ".unity", ".prefab", ".asset", ".shader", ".compute", ".cginc", ".uxml", ".uss", ".json", ".xml", ".md", ".txt", ".yml", ".yaml"}
SKIP_EXTS = {".png", ".jpg", ".jpeg", ".gif", ".webp", ".svg", ".ico", ".bmp", ".zip", ".7z", ".rar", ".tar", ".gz", ".mp4", ".webm", ".mp3", ".wav", ".woff", ".woff2", ".ttf", ".otf", ".exe", ".dll", ".so", ".bin", ".apk", ".aab", ".unitypackage"}

TAG_RE = re.compile(r"<[^>]+>")
SCRIPT_STYLE_RE = re.compile(r"<\s*(script|style|noscript|svg)[^>]*>.*?<\s*/\s*\1\s*>", re.I | re.S)
TITLE_RE = re.compile(r"<title[^>]*>(.*?)</title>", re.I | re.S)
HEAD_RE = re.compile(r"<\s*(h1|h2|h3|h4|h5|h6)[^>]*>(.*?)<\s*/\s*\1\s*>", re.I | re.S)
CODE_RE = re.compile(r"<\s*(pre|code)[^>]*>(.*?)<\s*/\s*\1\s*>", re.I | re.S)
HREF_RE = re.compile(r"href\s*=\s*[\"']([^\"']+)[\"']", re.I)
BLOCK_TAG_RE = re.compile(r"<\s*(br|p|div|li|h[1-6]|pre|section|article|tr|td|dt|dd)\b[^>]*>", re.I)
WS_RE = re.compile(r"[ \t\r\f\v]+")


def sha256_bytes(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()


def sha256_text(text: str) -> str:
    return sha256_bytes(text.encode("utf-8", errors="ignore"))


def normalize_url(url: str) -> str:
    p = urllib.parse.urlsplit(url.strip())
    scheme = p.scheme.lower()
    host = (p.hostname or "").lower()
    netloc = host
    if p.port and not ((scheme == "http" and p.port == 80) or (scheme == "https" and p.port == 443)):
        netloc = f"{host}:{p.port}"
    path = re.sub(r"/{2,}", "/", p.path or "/")
    keep = []
    for k, v in urllib.parse.parse_qsl(p.query, keep_blank_values=True):
        if k.lower() in {"page", "lang", "version", "locale"}:
            keep.append((k, v))
    return urllib.parse.urlunsplit((scheme, netloc, path, urllib.parse.urlencode(keep), ""))


def allowed_domain(url: str, domains: list[str]) -> bool:
    host = (urllib.parse.urlsplit(url).hostname or "").lower()
    return any(host == d or host.endswith("." + d) for d in domains)


def should_skip(url_or_path: str) -> bool:
    return Path(urllib.parse.urlsplit(url_or_path).path).suffix.lower() in SKIP_EXTS


def decode_html(raw: bytes, headers: dict) -> str:
    ctype = str(headers.get("Content-Type", ""))
    m = re.search(r"charset\s*=\s*([\w-]+)", ctype, re.I)
    encs = [m.group(1) if m else None, "utf-8", "cp949", "euc-kr"]
    for enc in encs:
        if not enc:
            continue
        try:
            return raw.decode(enc)
        except Exception:
            pass
    return raw.decode("utf-8", errors="replace")


def html_record(html: str) -> dict:
    title_m = TITLE_RE.search(html)
    title = re.sub(r"\s+", " ", TAG_RE.sub("", title_m.group(1))).strip() if title_m else ""
    headings = [re.sub(r"\s+", " ", TAG_RE.sub("", m.group(2))).strip() for m in HEAD_RE.finditer(html)]
    headings = [h for h in headings if h]
    code_blocks = [TAG_RE.sub("", m.group(2)).replace("\r\n", "\n").replace("\r", "\n").strip() for m in CODE_RE.finditer(html)]
    code_blocks = [c for c in code_blocks if len(c) >= 20]
    cleaned = SCRIPT_STYLE_RE.sub("\n", html)
    cleaned = BLOCK_TAG_RE.sub("\n", cleaned)
    cleaned = TAG_RE.sub(" ", cleaned)
    cleaned = re.sub(r"\s+", " ", cleaned)
    cleaned = cleaned.replace(" \n ", "\n").strip()
    prefix = []
    if title:
        prefix.append("TITLE: " + title)
    if headings:
        prefix.append("HEADINGS: " + " | ".join(dict.fromkeys(headings[:30])))
    text = "\n".join(prefix) + ("\n\n" if prefix else "") + cleaned
    if code_blocks:
        text += "\n\n[CODE BLOCKS]\n\n" + "\n\n".join(code_blocks[:50])
    return {"title": title, "headings": headings, "code_blocks": code_blocks, "text": text.strip()}


def extract_links(base: str, html: str, domains: list[str]) -> Iterable[str]:
    for m in HREF_RE.finditer(html):
        href = m.group(1).strip()
        if href.startswith(("javascript:", "mailto:", "tel:", "#")):
            continue
        u = normalize_url(urllib.parse.urljoin(base, href))
        if u.startswith(("http://", "https://")) and allowed_domain(u, domains) and not should_skip(u):
            yield u


def score_terms(text: str, table: dict[str, int]) -> float:
    s = text.lower()
    total = 0
    hits = 0
    for term, w in table.items():
        if term in s:
            total += w
            hits += 1
    return min(1.0, total / 40.0 + min(0.25, hits / 80.0))


def classify_category(title: str, text: str, url: str, hint: str | None = None) -> str:
    if hint in CATEGORY_BUDGET_BYTES:
        return hint
    sample = f"{title}\n{url}\n{text[:40000]}".lower()
    scores = {k: score_terms(sample, v) for k, v in CATEGORY_TERMS.items()}
    if "docs.unity3d.com" in url.lower():
        scores["unity_api"] += 0.25
    if "learn.microsoft.com" in url.lower():
        scores["csharp"] += 0.25
    return max(scores, key=scores.get) if max(scores.values()) > 0.04 else "qa"


def classify_type(title: str, text: str, url: str, code_blocks: list[str]) -> str:
    s = f"{title}\n{url}\n{text[:12000]}".lower()
    path = urllib.parse.urlsplit(url).path.lower()
    if "stackoverflow" in s or "q&a" in s or "faq" in s or "how to" in s:
        return "qa"
    if code_blocks or Path(path).suffix.lower() in CODE_EXTS:
        return "code" if not ("api" in s or "reference" in s) else "api_code"
    if "api" in s or "reference" in s or "/scripting" in path:
        return "api_documentation"
    if "tutorial" in s or "guide" in s:
        return "tutorial"
    return "documentation"


def source_trust(url: str, license_name: str | None = None) -> float:
    host = (urllib.parse.urlsplit(url).hostname or "").lower()
    if host.endswith("docs.unity3d.com"):
        base = 0.99
    elif host == "learn.microsoft.com" or host.endswith("learn.microsoft.com"):
        base = 0.99
    elif host.endswith("github.com") or host.endswith("raw.githubusercontent.com"):
        base = 0.86
    else:
        base = 0.58
    if license_name and license_name in OPEN_LICENSES:
        base += 0.03
    return min(1.0, base)


def quality_score(title: str, text: str, headings: list[str], code_blocks: list[str]) -> float:
    n = len(text)
    score = 0.25
    if title: score += 0.10
    if len(headings) >= 2: score += 0.12
    if n >= 1500: score += 0.16
    if n >= 5000: score += 0.10
    if code_blocks: score += 0.12
    if text.count("\n") >= 8: score += 0.05
    noise = sum(text.lower().count(x) for x in ["cookie", "privacy policy", "subscribe", "sign in", "로그인"])
    score -= min(0.18, noise / 120.0)
    return max(0.0, min(1.0, score))


def relevance_score(title: str, text: str) -> float:
    s = f"{title}\n{text[:30000]}".lower()
    raw = sum(w for term, w in RELEVANT.items() if term in s)
    return min(1.0, raw / 35.0)


def normalize_content(text: str) -> str:
    return re.sub(r"\s+", " ", text).strip().lower()


def shingles(text: str, n: int = 5, limit: int = 2500) -> set[str]:
    flat = normalize_content(text)
    if len(flat) <= n:
        return {flat}
    return {flat[i:i+n] for i in range(0, min(len(flat)-n+1, limit))}


def near_duplicate(history: list[set[str]], text: str, threshold: float = 0.92) -> bool:
    cur = shingles(text)
    if not cur:
        return False
    for old in history[-1200:]:
        union = len(cur | old)
        if union and len(cur & old) / union >= threshold:
            return True
    return False


def chunk_text(text: str, size: int = 900, overlap: int = 140) -> list[str]:
    words = text.split()
    out = []
    step = max(1, size - overlap)
    for start in range(0, len(words), step):
        chunk = " ".join(words[start:start+size]).strip()
        if len(chunk) >= 120:
            out.append(chunk)
        if start + size >= len(words):
            break
    return out


def fetch(url: str, timeout: int, ua: str) -> tuple[bytes, dict]:
    req = urllib.request.Request(url, headers={"User-Agent": ua, "Accept": "text/html,application/xhtml+xml,text/plain,*/*;q=0.5"})
    with urllib.request.urlopen(req, timeout=timeout) as r:
        return r.read(), dict(r.headers.items())


def github_repo_parts(url: str) -> tuple[str, str] | None:
    p = urllib.parse.urlsplit(url)
    if p.netloc.lower() not in {"github.com", "www.github.com"}:
        return None
    parts = [x for x in p.path.strip("/").split("/") if x]
    if len(parts) < 2:
        return None
    return parts[0], parts[1].removesuffix(".git")


def github_api(url: str, ua: str, timeout: int) -> dict | list:
    req = urllib.request.Request(url, headers={"User-Agent": ua, "Accept": "application/vnd.github+json"})
    with urllib.request.urlopen(req, timeout=timeout) as r:
        return json.loads(r.read().decode("utf-8"))


class CollectorV22:
    VERSION = "2.2"
    def __init__(self, out_dir: Path, ai_dir: Path, allowed_domains: list[str], **kwargs):
        self.out_dir = out_dir.resolve(); self.ai_dir = ai_dir.resolve()
        self.raw_dir = self.out_dir / "documents"
        self.category_dir = self.out_dir / "by_category"
        self.meta_file = self.out_dir / "manifest.jsonl"
        self.state_file = self.out_dir / "state.json"
        self.quality_file = self.out_dir / "quality_report.json"
        self.ai_dataset = self.ai_dir / "ai_dataset"
        self.ai_chunks = self.ai_dataset / "chunks.jsonl"
        self.ai_manifest = self.ai_dataset / "manifest.json"
        for d in (self.raw_dir, self.category_dir, self.ai_dataset): d.mkdir(parents=True, exist_ok=True)
        self.allowed_domains = sorted({d.lower() for d in allowed_domains})
        self.delay = max(0.0, float(kwargs.get("delay", 1.0))); self.timeout = int(kwargs.get("timeout", 20))
        self.max_pages = max(1, int(kwargs.get("max_pages", 5000))); self.max_depth = max(0, int(kwargs.get("max_depth", 8)))
        self.max_bytes = max(10_000, int(kwargs.get("max_bytes", 5_000_000))); self.min_chars = max(50, int(kwargs.get("min_chars", 500)))
        self.min_quality = float(kwargs.get("min_quality", 0.35)); self.min_relevance = float(kwargs.get("min_relevance", 0.05))
        self.chunk_size = max(200, int(kwargs.get("chunk_size", 900))); self.chunk_overlap = min(int(kwargs.get("chunk_overlap", 140)), self.chunk_size // 2)
        self.max_chunks = max(1, int(kwargs.get("max_chunks_per_doc", 100))); self.retries = max(1, int(kwargs.get("retries", 3)))
        self.ua = kwargs.get("user_agent", DEFAULT_UA)
        self.visited: set[str] = set(); self.seen_hashes: set[str] = set(); self.fingerprints: list[set[str]] = []
        self.category_bytes = {k: 0 for k in CATEGORY_ORDER}; self.category_docs = {k: 0 for k in CATEGORY_ORDER}; self.category_chunks = {k: 0 for k in CATEGORY_ORDER}
        self.saved_docs = 0; self.saved_chunks = 0; self.failed = 0; self.skipped = 0; self.last_request = 0.0
        self.robots = {}; self._load_state(); self._load_existing()

    def _load_state(self):
        if not self.state_file.exists(): return
        try:
            d=json.loads(self.state_file.read_text(encoding="utf-8")); self.visited=set(d.get("visited",[])); self.seen_hashes=set(d.get("seen_hashes",[]))
            for k,v in d.get("category_bytes",{}).items():
                if k in self.category_bytes: self.category_bytes[k]=int(v)
        except Exception: pass

    def _load_existing(self):
        if not self.meta_file.exists(): return
        try:
            for line in self.meta_file.read_text(encoding="utf-8").splitlines():
                rec=json.loads(line); d=rec.get("sha256")
                if d: self.seen_hashes.add(d)
                cat=rec.get("category")
                if cat in self.category_bytes:
                    self.category_bytes[cat]+=int(rec.get("bytes",0)); self.category_docs[cat]+=1; self.category_chunks[cat]+=int(rec.get("chunks",0))
        except Exception: pass

    def _save_state(self):
        self.state_file.write_text(json.dumps({"version":self.VERSION,"updated_at":int(time.time()),"visited":sorted(self.visited),"seen_hashes":sorted(self.seen_hashes),"category_bytes":self.category_bytes}, ensure_ascii=False), encoding="utf-8")

    def _robots(self, url: str):
        p=urllib.parse.urlsplit(url); root=f"{p.scheme}://{p.netloc}"
        if root in self.robots: return self.robots[root]
        rp=urllib.robotparser.RobotFileParser(root+"/robots.txt")
        try: rp.read(); self.robots[root]=rp
        except Exception: self.robots[root]=None
        return self.robots[root]

    def allowed_robots(self,url):
        rp=self._robots(url); return bool(rp and rp.can_fetch(self.ua,url))

    def rate(self):
        wait=self.delay-(time.monotonic()-self.last_request)
        if wait>0: time.sleep(wait)
        self.last_request=time.monotonic()

    def get(self,url):
        last=None
        for i in range(self.retries):
            try:
                self.rate(); return fetch(url,self.timeout,self.ua)
            except Exception as e:
                last=e; time.sleep(min(8,2**i))
        raise last or RuntimeError("fetch failed")

    def sitemap_urls(self, seed):
        p=urllib.parse.urlsplit(seed); root=f"{p.scheme}://{p.netloc}"; found=[]
        candidates=[root+"/sitemap.xml"]
        rp=self._robots(seed)
        if rp:
            try: candidates += list(rp.site_maps())
            except Exception: pass
        for sm in dict.fromkeys(candidates):
            try:
                if not self.allowed_robots(sm): continue
                raw,h=self.get(sm); xml=raw.decode("utf-8",errors="replace")
                for loc in re.findall(r"<loc>\s*(.*?)\s*</loc>",xml,re.I|re.S):
                    u=normalize_url(loc)
                    if allowed_domain(u,self.allowed_domains) and not should_skip(u): found.append(u)
            except Exception: pass
        return list(dict.fromkeys(found))

    def save(self,url,record,category_hint=None, license_name=None, extra_meta=None):
        title=record.get("title",""); text=record.get("text",""); heads=record.get("headings",[]); code=record.get("code_blocks",[])
        flat=re.sub(r"\s+"," ",text).strip()
        if len(flat)<self.min_chars: return False
        category=classify_category(title,text,url,category_hint)
        if self.category_bytes[category]>=CATEGORY_BUDGET_BYTES[category]: return False
        q=quality_score(title,text,heads,code); r=relevance_score(title,text); trust=source_trust(url,license_name)
        quality_total=round(min(1.0, q*0.5+r*0.2+trust*0.3),4)
        if q<self.min_quality or r<self.min_relevance or quality_total<0.45: return False
        digest=sha256_text(normalize_content(text))
        if digest in self.seen_hashes or near_duplicate(self.fingerprints,text): return False
        typ=classify_type(title,text,url,code)
        chunks=chunk_text(text,self.chunk_size,self.chunk_overlap)[:self.max_chunks]
        if not chunks: return False
        doc_id=digest[:20]; raw_path=self.category_dir/category/f"{doc_id}.txt"; raw_path.parent.mkdir(parents=True,exist_ok=True)
        raw_payload=f"TITLE: {title}\nSOURCE: {url}\nCATEGORY: {category}\nTYPE: {typ}\nQUALITY: {quality_total:.4f}\nTRUST: {trust:.4f}\nRELEVANCE: {r:.4f}\nLICENSE: {license_name or 'unknown'}\n\n{text}\n"
        raw_path.write_text(raw_payload,encoding="utf-8")
        source_file=f"web::{urllib.parse.urlsplit(url).hostname or 'unknown'}::{doc_id}"
        records=[]; now=int(time.time())
        for i,c in enumerate(chunks):
            cid=hashlib.sha1(f"{url}\0{sha256_text(c)}".encode()).hexdigest()
            records.append({"id":cid,"file":source_file,"text":c,"source_url":url,"title":title,"chunk_index":i,"quality":quality_total,"source_trust":round(trust,4),"relevance":round(r,4),"category":category,"document_type":typ,"license":license_name or "unknown","collected_at":now,"collector_version":self.VERSION,**(extra_meta or {})})
        serialized=sum(len((json.dumps(x,ensure_ascii=False)+"\n").encode("utf-8")) for x in records)+raw_path.stat().st_size
        if serialized > CATEGORY_BUDGET_BYTES[category]-self.category_bytes[category]:
            raw_path.unlink(missing_ok=True); return False
        with self.ai_chunks.open("a",encoding="utf-8") as f:
            for rec in records: f.write(json.dumps(rec,ensure_ascii=False)+"\n")
        with self.meta_file.open("a",encoding="utf-8") as f:
            f.write(json.dumps({"id":doc_id,"url":url,"title":title,"sha256":digest,"category":category,"document_type":typ,"quality":quality_total,"source_trust":trust,"relevance":r,"license":license_name or "unknown","chars":len(flat),"chunks":len(records),"bytes":serialized,"collected_at":now,"collector_version":self.VERSION},ensure_ascii=False)+"\n")
        self.seen_hashes.add(digest); self.fingerprints.append(shingles(text)); self.fingerprints=self.fingerprints[-6000:]
        self.category_bytes[category]+=serialized; self.category_docs[category]+=1; self.category_chunks[category]+=len(records); self.saved_docs+=1; self.saved_chunks+=len(records)
        return True

    def crawl(self,seeds,use_sitemap=True):
        q=deque((normalize_url(url),0,cat) for cat,url in seeds); queued={normalize_url(url) for _,url in seeds}
        if use_sitemap:
            for cat,seed in seeds:
                for u in self.sitemap_urls(seed):
                    if u not in queued: queued.add(u); q.append((u,0,cat))
        while q and len(self.visited)<self.max_pages:
            url,depth,hint=q.popleft()
            if url in self.visited or depth>self.max_depth: continue
            if not allowed_domain(url,self.allowed_domains) or should_skip(url): continue
            self.visited.add(url)
            if not self.allowed_robots(url): self.skipped+=1; continue
            try:
                raw,h=self.get(url); ctype=str(h.get("Content-Type",""))
                if "text/html" not in ctype and "xhtml" not in ctype: self.skipped+=1; continue
                if len(raw)>self.max_bytes: self.skipped+=1; continue
                html=decode_html(raw,h); rec=html_record(html)
                if self.save(url,rec,hint): print(f"[저장] {rec['title'][:60] or url} | total_chunks={self.saved_chunks}")
                else: self.skipped+=1
                for child in extract_links(url,html,self.allowed_domains):
                    if child not in self.visited and child not in queued: queued.add(child); q.append((child,depth+1,hint))
            except Exception as e:
                self.failed+=1; print(f"[실패] {url} :: {e}")
            if len(self.visited)%25==0: self._save_state(); print(f"[상태] visited={len(self.visited)} saved_docs={self.saved_docs} saved_chunks={self.saved_chunks}")
        self._save_state(); self.write_quality_report()
        return self.summary()

    def crawl_github(self, repo_url, category, allow_unlicensed=False):
        parts=github_repo_parts(repo_url)
        if not parts: return {"repo":repo_url,"status":"invalid"}
        owner,repo=parts; api=f"https://api.github.com/repos/{owner}/{repo}"; meta=github_api(api,self.ua,self.timeout)
        lic=((meta.get("license") or {}).get("spdx_id") or "").strip()
        if not lic and not allow_unlicensed: return {"repo":repo_url,"status":"skipped","reason":"license_unknown"}
        branch=meta.get("default_branch","main"); tree=github_api(f"{api}/git/trees/{branch}?recursive=1",self.ua,self.timeout); items=tree.get("tree",[]) if isinstance(tree,dict) else []
        saved=chunks=0
        for item in items:
            if item.get("type")!="blob": continue
            path=item.get("path",""); ext=Path(path).suffix.lower()
            if ext not in CODE_EXTS or should_skip(path): continue
            raw_url=f"https://raw.githubusercontent.com/{owner}/{repo}/{branch}/{urllib.parse.quote(path)}"
            try:
                raw,_=self.get(raw_url); text=raw.decode("utf-8",errors="replace")
                rec={"title":f"{owner}/{repo}: {path}","headings":[],"code_blocks":[],"text":text}
                if self.save(raw_url,rec,category,license_name=lic,extra_meta={"github_repository":f"{owner}/{repo}","repo_license":lic}): saved+=1; chunks+=1
            except Exception as e: self.failed+=1; print(f"[GitHub 실패] {path} :: {e}")
        return {"repo":repo_url,"status":"ok","license":lic or "unknown","saved_documents":saved,"saved_chunks":chunks}

    def write_quality_report(self):
        counts=Counter(); types=Counter(); trust=[]; quality=[]
        if self.meta_file.exists():
            for line in self.meta_file.read_text(encoding="utf-8").splitlines():
                try:
                    r=json.loads(line); counts[r.get("category","unknown")]+=1; types[r.get("document_type","unknown")]+=1; trust.append(float(r.get("source_trust",0))); quality.append(float(r.get("quality",0)))
                except Exception: pass
        self.quality_file.write_text(json.dumps({"version":self.VERSION,"updated_at":int(time.time()),"documents_by_category":counts,"documents_by_type":types,"average_source_trust":sum(trust)/len(trust) if trust else 0.0,"average_quality":sum(quality)/len(quality) if quality else 0.0,"category_bytes":self.category_bytes},ensure_ascii=False,indent=2,default=lambda x:dict(x)),encoding="utf-8")

    def summary(self):
        return {"version":self.VERSION,"category_bytes":self.category_bytes,"saved_documents":self.saved_docs,"saved_chunks":self.saved_chunks,"failed":self.failed,"skipped":self.skipped,"visited_total":len(self.visited),"ai_chunks":str(self.ai_chunks.resolve()),"quality_report":str(self.quality_file.resolve())}


def maybe_build_index(ai_dir: Path, model_name: str, batch_size: int = 64, min_quality: float = 0.0):
    """선택적 증분 인덱싱. sentence-transformers/FAISS가 없으면 명확한 안내 후 종료."""
    chunks = ai_dir / "ai_dataset" / "chunks.jsonl"
    idx_dir = ai_dir / "ai_dataset" / "vector_index"
    idx_dir.mkdir(parents=True, exist_ok=True)
    try:
        import numpy as np
        from sentence_transformers import SentenceTransformer
    except Exception as e:
        print("[인덱싱 생략] sentence-transformers/numpy가 없습니다:", e)
        print("설치 예: pip install numpy sentence-transformers")
        return 0
    try:
        import faiss
    except Exception as e:
        print("[인덱싱 생략] faiss가 없습니다:", e)
        print("설치 예: pip install faiss-cpu")
        return 0
    meta_path=idx_dir/"metadata.jsonl"; faiss_path=idx_dir/"index.faiss"; state_path=idx_dir/"state.json"
    done=set()
    if meta_path.exists():
        for line in meta_path.read_text(encoding="utf-8").splitlines():
            try: done.add(json.loads(line)["id"])
            except Exception: pass
    texts=[]; metas=[]
    with chunks.open(encoding="utf-8") as f:
        for line in f:
            try:
                r=json.loads(line)
                if r.get("id") in done or float(r.get("quality",0))<min_quality: continue
                texts.append(r.get("text","")); metas.append(r)
            except Exception: continue
    if not texts:
        print("[인덱싱] 새 문서 없음"); return 0
    model=SentenceTransformer(model_name)
    vec=model.encode(texts,batch_size=batch_size,normalize_embeddings=True,show_progress_bar=True)
    vec=np.asarray(vec,dtype="float32")
    if faiss_path.exists():
        index=faiss.read_index(str(faiss_path))
    else:
        index=faiss.IndexFlatIP(vec.shape[1])
    index.add(vec); faiss.write_index(index,str(faiss_path))
    with meta_path.open("a",encoding="utf-8") as f:
        for r in metas: f.write(json.dumps(r,ensure_ascii=False)+"\n")
    state={"version":"2.2","model":model_name,"vectors":int(index.ntotal),"updated_at":int(time.time())}; state_path.write_text(json.dumps(state,ensure_ascii=False,indent=2),encoding="utf-8")
    print(f"[인덱싱 완료] +{len(texts)} vectors | total={index.ntotal}")
    return len(texts)


def load_config(path: Path):
    if not path.exists(): return [], []
    data=json.loads(path.read_text(encoding="utf-8")); seeds=[]; repos=[]
    for cat,urls in (data.get("category_seeds",{}) or {}).items():
        for u in ([urls] if isinstance(urls,str) else urls or []): seeds.append((cat,u))
    for cat,urls in (data.get("github_repos",{}) or {}).items():
        for u in ([urls] if isinstance(urls,str) else urls or []): repos.append((cat,u))
    return seeds,repos


def parse_cat_seed(spec):
    if "::" not in spec: raise ValueError("CATEGORY::URL 형식 필요")
    c,u=spec.split("::",1); c=c.strip().lower(); u=u.strip()
    if c not in CATEGORY_BUDGET_BYTES: raise ValueError(f"알 수 없는 category: {c}")
    return c,u


def find_ai_dir(explicit):
    if explicit: return explicit.resolve()
    here=Path(__file__).resolve().parent
    return here



# ──────────────────────────────────────────────
# 8.1 통합 Collector + 원격 접속 (v4.0)
# ──────────────────────────────────────────────
COLLECTOR_STATE = {
    "running": False,
    "thread": None,
    "status": "stopped",
    "started_at": None,
    "finished_at": None,
    "last_summary": None,
    "error": None,
    "max_pages": int(os.environ.get("MYAI_COLLECTOR_MAX_PAGES", "500")),
}
COLLECTOR_LOCK = threading.Lock()

# v4.3: 수집 → 저장 → 인덱싱 → 즉시 검색 가능 파이프라인 상태
PIPELINE_STATE = {
    "enabled": False,
    "watcher_running": False,
    "last_index_sync": None,
    "last_dataset_size": 0,
    "error": None,
}
PIPELINE_LOCK = threading.Lock()
PIPELINE_WATCH_INTERVAL = float(os.environ.get("MYAI_PIPELINE_WATCH_INTERVAL", "8"))


CATEGORY_SEEDS_V40 = {
    "csharp": [
        "https://learn.microsoft.com/ko-kr/dotnet/csharp/",
        "https://learn.microsoft.com/ko-kr/dotnet/csharp/language-reference/",
        "https://learn.microsoft.com/ko-kr/dotnet/csharp/how-to/",
    ],
    "unity_api": [
        "https://docs.unity3d.com/kr/current/Manual/index.html",
        "https://docs.unity3d.com/kr/current/ScriptReference/index.html",
    ],
    "qa": ["https://learn.microsoft.com/ko-kr/answers/questions/"],
}
GITHUB_REPOS_V40 = {
    "unity_projects": [
        "https://github.com/Unity-Technologies/DesktopSamples",
        "https://github.com/UnityTechnologies/open-project-1",
    ],
    "game_systems": ["https://github.com/Unity-Technologies/ml-agents"],
}


def collector_status():
    with COLLECTOR_LOCK:
        result = {k: v for k, v in COLLECTOR_STATE.items() if k not in {"thread"}}
    try:
        q = CollectorV22(COLLECTOR_DATA_DIR, Path(HERE), [
            "learn.microsoft.com", "docs.unity3d.com", "github.com", "raw.githubusercontent.com"
        ], max_pages=1)
        s = q.summary()
        result["category_bytes"] = s.get("category_bytes", {})
        result["saved_documents"] = s.get("saved_documents", 0)
        result["saved_chunks"] = s.get("saved_chunks", 0)
    except Exception as e:
        result["status_error"] = str(e)
    with PIPELINE_LOCK:
        result["pipeline"] = {k: v for k, v in PIPELINE_STATE.items()}
    return result


def _dataset_signature_for_pipeline():
    """데이터셋 변경 여부를 빠르게 확인한다. 전체 파일을 읽지 않는다."""
    try:
        st = DATASET_JSONL and os.stat(DATASET_JSONL)
        return (st.st_size, st.st_mtime_ns)
    except OSError:
        return (0, 0)


def _pipeline_index_sync_worker():
    try:
        rebuild_index(force=True)
        sig = _dataset_signature_for_pipeline()
        with PIPELINE_LOCK:
            PIPELINE_STATE["last_index_sync"] = int(time.time())
            PIPELINE_STATE["last_dataset_size"] = int(sig[0])
            PIPELINE_STATE["error"] = None
    except Exception as e:
        with PIPELINE_LOCK:
            PIPELINE_STATE["error"] = repr(e)


def _pipeline_watcher():
    """Collector가 실행되는 동안 새 chunk가 생기면 인덱스를 자동 갱신한다."""
    with PIPELINE_LOCK:
        if PIPELINE_STATE["watcher_running"]:
            return
        PIPELINE_STATE["watcher_running"] = True
        PIPELINE_STATE["enabled"] = True
    last_sig = _dataset_signature_for_pipeline()
    pending_sync = False
    last_trigger = 0.0
    try:
        while True:
            with COLLECTOR_LOCK:
                running = bool(COLLECTOR_STATE.get("running"))
            sig = _dataset_signature_for_pipeline()
            if sig != last_sig:
                last_sig = sig
                pending_sync = True
                last_trigger = time.monotonic()
            # 데이터가 마지막 변경 후 1.5초 이상 안정되었을 때 한 번만 재색인
            if pending_sync and time.monotonic() - last_trigger >= 1.5:
                pending_sync = False
                threading.Thread(target=_pipeline_index_sync_worker, daemon=True).start()
            if not running and not pending_sync:
                break
            time.sleep(max(1.0, PIPELINE_WATCH_INTERVAL))
    finally:
        with PIPELINE_LOCK:
            PIPELINE_STATE["watcher_running"] = False


def start_pipeline(max_pages=None):
    """수집 시작 + 백그라운드 인덱스 감시를 한 번에 시작한다."""
    result = start_collector(max_pages)
    if not result.get("ok"):
        return result
    with PIPELINE_LOCK:
        PIPELINE_STATE["enabled"] = True
        PIPELINE_STATE["error"] = None
    threading.Thread(target=_pipeline_watcher, daemon=True).start()
    return {"ok": True, "message": result["message"] + " 수집되는 동안 새 데이터가 자동으로 검색 인덱스에 반영돼."}


def _collector_worker(max_pages):
    try:
        with COLLECTOR_LOCK:
            COLLECTOR_STATE["status"] = "running"
            COLLECTOR_STATE["running"] = True
            COLLECTOR_STATE["started_at"] = int(time.time())
            COLLECTOR_STATE["finished_at"] = None
            COLLECTOR_STATE["error"] = None
        seeds = [(cat, url) for cat, urls in CATEGORY_SEEDS_V40.items() for url in urls]
        allowed = [
            "learn.microsoft.com", "docs.unity3d.com", "github.com", "raw.githubusercontent.com"
        ]
        collector = CollectorV22(
            COLLECTOR_DATA_DIR, Path(HERE), allowed,
            max_pages=max_pages,
            delay=float(os.environ.get("MYAI_COLLECTOR_DELAY", "1.0")),
            max_depth=int(os.environ.get("MYAI_COLLECTOR_MAX_DEPTH", "8")),
        )
        web_summary = collector.crawl(seeds, use_sitemap=True)
        gh_results = []
        for category, repos in GITHUB_REPOS_V40.items():
            for repo in repos:
                try:
                    gh_results.append(collector.crawl_github(repo, category))
                except Exception as e:
                    gh_results.append({"repo": repo, "status": "error", "error": str(e)})
        # 수집 완료 직후 한 번 더 동기화해 마지막 변경도 반드시 반영한다.
        try:
            rebuild_index(force=True)
            with PIPELINE_LOCK:
                sig = _dataset_signature_for_pipeline()
                PIPELINE_STATE["last_index_sync"] = int(time.time())
                PIPELINE_STATE["last_dataset_size"] = int(sig[0])
                PIPELINE_STATE["error"] = None
        except Exception as e:
            web_summary["index_error"] = str(e)
            with PIPELINE_LOCK:
                PIPELINE_STATE["error"] = repr(e)
        with COLLECTOR_LOCK:
            COLLECTOR_STATE["last_summary"] = {"web": web_summary, "github": gh_results}
            COLLECTOR_STATE["status"] = "finished"
            COLLECTOR_STATE["running"] = False
            COLLECTOR_STATE["finished_at"] = int(time.time())
    except Exception as e:
        with COLLECTOR_LOCK:
            COLLECTOR_STATE["status"] = "error"
            COLLECTOR_STATE["running"] = False
            COLLECTOR_STATE["finished_at"] = int(time.time())
            COLLECTOR_STATE["error"] = repr(e)


def start_collector(max_pages=None):
    with COLLECTOR_LOCK:
        if COLLECTOR_STATE["running"]:
            return {"ok": False, "message": "이미 데이터 수집 중이야."}
        pages = int(max_pages or COLLECTOR_STATE["max_pages"])
        if pages < 1: pages = 1
        COLLECTOR_STATE["max_pages"] = pages
        t = threading.Thread(target=_collector_worker, args=(pages,), daemon=True)
        COLLECTOR_STATE["thread"] = t
        t.start()
    return {"ok": True, "message": f"데이터 수집을 시작했어. 최대 {pages}페이지씩 진행해."}


def handle_collector_message(text):
    t = text.strip().lower()
    if any(x in t for x in ["통합 파이프라인 상태", "자동 수집 상태", "수집+인덱스 상태"]):
        s = collector_status()
        p = s.get("pipeline", {})
        return (f"수집기: {s.get('status')}\n"
                f"수집 문서: {s.get('saved_documents', 0)} / 청크: {s.get('saved_chunks', 0)}\n"
                f"자동 인덱싱: {'ON' if p.get('enabled') else 'OFF'}\n"
                f"마지막 인덱스 동기화: {p.get('last_index_sync') or '없음'}\n"
                f"최대 페이지: {s.get('max_pages')}")
    if any(x in t for x in ["통합 수집 시작", "자동 수집 시작", "수집+인덱스 시작", "파이프라인 시작"]):
        m = re.search(r"(?:최대|max)[ ]*(\d+)", t)
        pages = int(m.group(1)) if m else None
        return start_pipeline(pages)["message"]
    if any(x in t for x in ["데이터 수집 상태", "수집 상태", "collector 상태"]):
        s = collector_status()
        return "수집기 상태: %s\n수집 문서: %s\n수집 청크: %s\n최대 페이지: %s" % (
            s.get("status"), s.get("saved_documents", 0), s.get("saved_chunks", 0), s.get("max_pages")
        )
    if any(x in t for x in ["데이터 수집 시작", "수집 시작", "collector 시작"]):
        m = re.search(r"(?:최대|max)[ ]*(\d+)", t)
        pages = int(m.group(1)) if m else None
        return start_pipeline(pages)["message"]
    return None

# collector 데이터 디렉터리. AI와 같은 폴더의 ai_dataset은 그대로 공유.
COLLECTOR_DATA_DIR = Path(HERE) / "collector_data"


# ──────────────────────────────────────────────
# 8. 미니 웹서버 (크롬과 파이썬 두뇌를 연결)
# ──────────────────────────────────────────────
SERVER = {"instance": None}
LAST_SEEN = {"t": None}


def stop_server():
    if SERVER["instance"]:
        threading.Thread(target=SERVER["instance"].shutdown, daemon=True).start()


def watchdog():
    """브라우저 신호가 12초 넘게 끊기면(창을 닫으면) 스스로 종료"""
    while True:
        time.sleep(3)
        if LAST_SEEN["t"] and time.time() - LAST_SEEN["t"] > 12:
            stop_server()
            return



# Remote modes:
#   MYAI_REMOTE=1             -> bind 0.0.0.0 (LAN/VPN, existing behavior)
#   MYAI_TAILSCALE=1          -> bind only to the local Tailscale 100.x IPv4 address
# You can also set MYAI_TOKEN to a fixed secret instead of an auto-generated token.
REMOTE_MODE = os.environ.get("MYAI_REMOTE", "0") == "1"
TAILSCALE_MODE = os.environ.get("MYAI_TAILSCALE", "0") == "1"
SERVER_TOKEN = os.environ.get("MYAI_TOKEN") or _SECURITY_CFG.get("server_token") or (secrets.token_urlsafe(18) if (REMOTE_MODE or TAILSCALE_MODE) else "")

def _get_tailscale_ipv4():
    """Return the local Tailscale IPv4 address when the Tailscale CLI is available."""
    candidates = [
        ["tailscale", "ip", "-4"],
        ["tailscale", "ip"],
    ]
    for cmd in candidates:
        try:
            proc = subprocess.run(cmd, capture_output=True, text=True, timeout=3, check=False)
            if proc.returncode != 0:
                continue
            for line in proc.stdout.splitlines():
                value = line.strip()
                # Tailscale IPv4 addresses are in 100.64.0.0/10.
                if re.fullmatch(r"100\.(?:6[4-9]|[78]\d|9\d)\.\d{1,3}\.\d{1,3}", value):
                    return value
        except (OSError, subprocess.SubprocessError):
            continue
    return ""

TAILSCALE_IP = _get_tailscale_ipv4() if TAILSCALE_MODE else ""
if TAILSCALE_MODE and not TAILSCALE_IP:
    raise RuntimeError("Tailscale 모드인데 Tailscale IPv4 주소를 찾지 못했어. Tailscale이 로그인/실행 중인지 확인해줘.")

if TAILSCALE_MODE:
    # Bind only to the Tailscale interface, not to the public/LAN interfaces.
    BIND_HOST = TAILSCALE_IP
elif REMOTE_MODE:
    BIND_HOST = "0.0.0.0"
else:
    BIND_HOST = "127.0.0.1"

def _client_token(handler):
    token = handler.headers.get("X-MyAI-Token", "")
    if not token:
        try:
            query = urllib.parse.urlsplit(handler.path).query
            token = urllib.parse.parse_qs(query).get("token", [""])[0]
        except Exception:
            token = ""
    return token

def _auth_ok(handler):
    if not (REMOTE_MODE or TAILSCALE_MODE):
        return True
    return bool(SERVER_TOKEN) and secrets.compare_digest(_client_token(handler), SERVER_TOKEN)

def local_lan_urls(port):
    urls = []
    if TAILSCALE_IP:
        urls.append(f"http://{TAILSCALE_IP}:{port}/?token={urllib.parse.quote(SERVER_TOKEN)}")
    try:
        ip = socket.gethostbyname(socket.gethostname())
        if ip and not ip.startswith("127."):
            urls.append(f"http://{ip}:{port}/?token={urllib.parse.quote(SERVER_TOKEN)}")
    except Exception:
        pass
    # UDP 연결 없이도 알아낼 수 있는 보조 경로
    try:
        s=socket.socket(socket.AF_INET, socket.SOCK_DGRAM); s.connect(("8.8.8.8",80)); ip=s.getsockname()[0]; s.close()
        if ip and not ip.startswith("127."):
            u=f"http://{ip}:{port}/?token={urllib.parse.quote(SERVER_TOKEN)}"
            if u not in urls: urls.append(u)
    except Exception:
        pass
    return urls


PAGE = V6_PAGE


# v6.5 web features: chat search, streaming, attachments
CHAT_ATTACH_DIR = APP_DIR / "data" / "memory" / "chat_attachments"
CHAT_ATTACH_DIR.mkdir(parents=True, exist_ok=True)
TEXT_ATTACHMENT_EXTS = {".txt",".md",".csv",".json",".xml",".uxml",".uss",".cs",".py",".js",".ts",".html",".css",".shader",".log"}

def _safe_filename(name):
    base = Path(str(name)).name
    keep = "".join(ch if (ch.isalnum() or ch in " ._-()[]") else "_" for ch in base)
    return (keep or "attachment.bin")[:160]

def _chat_search(query, limit=30):
    q = str(query or "").strip().lower()
    if not q:
        return []
    out=[]
    for sess in _chat_db_load().get("sessions", []):
        title=str(sess.get("title", ""))
        for m in sess.get("messages", []):
            content=str(m.get("content", ""))
            hay=(title+"\n"+content).lower()
            if q in hay:
                pos=hay.find(q)
                start=max(0,pos-100); end=min(len(content), pos+240)
                out.append({"session_id":sess.get("id"),"title":title,"role":m.get("role"),"ts":m.get("ts"),"snippet":content[start:end]})
    out.sort(key=lambda x:x.get("ts",0), reverse=True)
    return out[:max(1,min(int(limit),100))]

def _decode_attachment(data_b64, name):
    raw=base64.b64decode(data_b64 or "", validate=False)
    if len(raw)>15*1024*1024:
        raise ValueError("첨부 파일은 15MB 이하만 지원해.")
    fname=_safe_filename(name)
    path=CHAT_ATTACH_DIR / f"{int(time.time()*1000)}_{fname}"
    path.write_bytes(raw)
    ext=path.suffix.lower()
    preview=""
    if ext in TEXT_ATTACHMENT_EXTS:
        try: preview=raw.decode("utf-8",errors="replace")[:30000]
        except Exception: preview=""
    return {"name":fname,"path":str(path.relative_to(APP_DIR)),"size":len(raw),"preview":preview}

def _stream_chunks(text, size=24):
    text=str(text or "")
    for i in range(0,len(text),size):
        yield text[i:i+size]


# v6.6 Diagnostics Center
def _diag_cmd(cmd, timeout=3):
    try:
        r=subprocess.run(cmd, capture_output=True, text=True, timeout=timeout, shell=isinstance(cmd,str))
        return {"ok": r.returncode==0, "code": r.returncode, "stdout": r.stdout.strip(), "stderr": r.stderr.strip()}
    except Exception as e:
        return {"ok": False, "code": None, "stdout": "", "stderr": str(e)}

def _diag_version(exe, args=("--version",)):
    r=_diag_cmd([exe, *args], timeout=4)
    if r["ok"]:
        return (r["stdout"] or r["stderr"]).splitlines()[0][:160]
    return None

def _diagnostics():
    import platform
    os_name=platform.system()
    result={"version":"6.6-diagnostics","timestamp":datetime.now().isoformat(timespec="seconds"),"os":os_name,"host":platform.node(),"checks":[],"hardware":{},"software":{},"recommendations":[]}
    def add(name,status,detail,category="environment"):
        result["checks"].append({"name":name,"status":status,"detail":str(detail)[:500],"category":category})
    result["hardware"]["cpu"]=platform.processor() or platform.machine()
    # RAM / disk 
    try:
        if os_name=="Windows":
            ps=_diag_cmd('powershell -NoProfile -Command "(Get-CimInstance Win32_ComputerSystem).TotalPhysicalMemory"')
            if ps["ok"] and ps["stdout"].isdigit():
                ram_gb=round(int(ps["stdout"])/(1024**3),1); result["hardware"]["ram_gb"]=ram_gb; add("RAM", "PASS" if ram_gb>=16 else "WARN", f"{ram_gb} GB", "hardware")
            else: add("RAM","WARN","확인 실패","hardware")
        else:
            mem=Path('/proc/meminfo')
            if mem.exists():
                total_kb=int(next((ln.split()[1] for ln in mem.read_text().splitlines() if ln.startswith('MemTotal:')),0)); ram_gb=round(total_kb/1024/1024,1); result["hardware"]["ram_gb"]=ram_gb; add("RAM","PASS" if ram_gb>=16 else "WARN",f"{ram_gb} GB","hardware")
    except Exception as e: add("RAM","WARN",e,"hardware")
    try:
        usage=shutil.disk_usage(str(APP_DIR)); free_gb=round(usage.free/(1024**3),1); total_gb=round(usage.total/(1024**3),1); result["hardware"]["disk_free_gb"]=free_gb; result["hardware"]["disk_total_gb"]=total_gb; add("시스템 디스크 여유", "PASS" if free_gb>=50 else "WARN", f"{free_gb} GB / {total_gb} GB", "hardware")
    except Exception as e: add("디스크","WARN",e,"hardware")
    # Python/Git/.NET/Tailscale
    py=platform.python_version(); result["software"]["python"]=py; add("Python", "PASS", py, "software")
    for exe,label,args,cat in [("git","Git",("--version",),"software"),("dotnet",".NET",("--version",),"software"),("tailscale","Tailscale",("version",),"network")]:
        v=_diag_version(exe,args); result["software"][label.lower().replace('.','_')]=v; add(label,"PASS" if v else "WARN",v or "설치되지 않았거나 PATH에서 찾지 못함",cat)
    # NVIDIA GPU / nvidia-smi
    nv=_diag_cmd(["nvidia-smi","--query-gpu=name,memory.total,driver_version,utilization.gpu","--format=csv,noheader,nounits"],timeout=5)
    if nv["ok"] and nv["stdout"]:
        line=nv["stdout"].splitlines()[0]; result["hardware"]["gpu"]=line; add("NVIDIA GPU","PASS",line,"hardware")
    else:
        result["hardware"]["gpu"]=None; add("NVIDIA GPU","WARN","nvidia-smi를 찾지 못함","hardware")
    # CUDA torch if installed
    try:
        import torch
        cuda=bool(torch.cuda.is_available()); detail=f"torch {getattr(torch,'__version__','?')}" + (f", {torch.cuda.get_device_name(0)}" if cuda else ", CUDA unavailable")
        result["software"]["torch"]=detail; add("PyTorch/CUDA","PASS" if cuda else "WARN",detail,"ai")
    except Exception as e: result["software"]["torch"]=None; add("PyTorch/CUDA","WARN",f"미설치 또는 로드 실패: {e}","ai")
    # Unity path / project
    unity_path=_PATHS_CFG.get("unity_path") or os.environ.get("UNITY_PATH") or ""
    if unity_path and Path(unity_path).exists(): add("Unity Editor","PASS",unity_path,"unity")
    else:
        which=_diag_cmd(["where","Unity.exe"] if os_name=="Windows" else ["which","unity"])
        add("Unity Editor","PASS" if which["ok"] else "WARN", which["stdout"] or "경로 설정 필요", "unity")
    # project
    proj=PROJECT_ROOT if 'PROJECT_ROOT' in globals() else None
    add("Unity 프로젝트", "PASS" if proj and Path(proj).exists() else "WARN", str(proj or "연결되지 않음"), "unity")
    # NAS path / network
    nas_path=_PATHS_CFG.get("nas_root") or _PATHS_CFG.get("knowledge_root") or ""
    if nas_path:
        add("NAS 경로", "PASS" if Path(nas_path).exists() else "WARN", nas_path, "storage")
    else: add("NAS 경로","WARN","config/paths.json에 nas_root를 설정하면 확인 가능","storage")
    # dataset
    try:
        docs=Path(DOCS_FILE); size=docs.stat().st_size if docs.exists() else 0; add("지식 데이터", "PASS" if docs.exists() else "WARN", f"파일 {docs.name}, {round(size/(1024**2),2)} MB", "ai")
    except Exception as e: add("지식 데이터","WARN",e,"ai")
    # network endpoint summary
    add("Tailscale 인증", "PASS" if _SECURITY_CFG.get("remote_token") or os.environ.get("MYAI_TOKEN") else "WARN", "원격 인증 토큰 설정 여부", "network")
    # recommendations
    warns=[c for c in result["checks"] if c["status"]=="WARN"]; fails=[c for c in result["checks"] if c["status"]=="FAIL"]; result["summary"]={"pass":sum(c["status"]=="PASS" for c in result["checks"]),"warn":len(warns),"fail":len(fails),"total":len(result["checks"]),"health":"PASS" if not fails and not warns else ("WARN" if not fails else "FAIL")}
    for c in warns:
        if c["name"] in ("NVIDIA GPU","PyTorch/CUDA"): result["recommendations"].append("GPU 가속을 쓰려면 NVIDIA 드라이버/nvidia-smi와 CUDA용 PyTorch를 확인하세요.")
        elif c["name"]=="Unity Editor": result["recommendations"].append("config/paths.json의 unity_path 또는 UNITY_PATH 환경변수를 설정하세요.")
        elif c["name"]=="NAS 경로": result["recommendations"].append("NAS를 연결하면 config/paths.json의 nas_root에 공유 폴더 경로를 지정하세요.")
        elif c["name"]=="시스템 디스크 여유": result["recommendations"].append("여유 공간을 50GB 이상 확보하세요. 1.5TB 데이터 수집에는 별도 저장소가 필요합니다.")
    return result

class Handler(http.server.BaseHTTPRequestHandler):
    def _send(self, code, body, ctype):
        data = body.encode("utf-8")
        self.send_response(code)
        self.send_header("Content-Type", ctype + "; charset=utf-8")
        self.send_header("Content-Length", str(len(data)))
        self.end_headers()
        self.wfile.write(data)

    def do_GET(self):
        if not _auth_ok(self):
            self._send(401, "인증 토큰이 필요해요.", "text/plain")
            return
        route = self.path.split("?", 1)[0]
        if route in ("/", "/index.html", "/app.js", "/style.css"):
            web_root = APP_DIR / "web"
            asset = web_root / ("index.html" if route in ("/", "/index.html") else route.lstrip("/"))
            try:
                data = asset.read_bytes()
                ctype = {".html":"text/html", ".js":"application/javascript", ".css":"text/css"}.get(asset.suffix, "application/octet-stream")
                self.send_response(200)
                self.send_header("Content-Type", ctype + "; charset=utf-8")
                self.send_header("Content-Length", str(len(data)))
                self.end_headers()
                self.wfile.write(data)
            except Exception:
                # 배포 폴더가 없거나 파일이 손상된 경우 기존 내장 페이지로 폴백
                if route in ("/", "/index.html"):
                    self._send(200, PAGE, "text/html")
                else:
                    self._send(404, "asset not found", "text/plain")
        elif route == "/ping":
            LAST_SEEN["t"] = time.time()
            self._send(200, "{}", "application/json")
        elif self.path.split("?",1)[0] == "/notes":
            self._send(200, json.dumps(v6_load_notes(), ensure_ascii=False), "application/json")
        elif self.path.split("?",1)[0] == "/chat_sessions":
            d=_chat_db_load()
            items=[{"id":s.get("id"),"title":s.get("title","새 채팅"),"updated_at":s.get("updated_at",0),"message_count":len(s.get("messages",[]))} for s in d.get("sessions",[])]
            self._send(200, json.dumps({"current_id":CURRENT_CHAT_ID,"sessions":items}, ensure_ascii=False), "application/json")
        elif self.path.split("?",1)[0] == "/chat_search":
            q=urllib.parse.parse_qs(urllib.parse.urlsplit(self.path).query).get("q", [""])[0]
            self._send(200, json.dumps({"results":_chat_search(q)}, ensure_ascii=False), "application/json")
        elif self.path.split("?",1)[0] == "/chat_attachment":
            self._send(404, json.dumps({"error":"attachment_download_disabled"}, ensure_ascii=False), "application/json")
        elif self.path.split("?",1)[0] == "/workspace-status":
            self._send(200, json.dumps(v6_workspace_status(), ensure_ascii=False), "application/json")
        else:
            self._send(404, "없는 페이지예요", "text/plain")

    def do_POST(self):
        if not _auth_ok(self):
            self._send(401, json.dumps({"error":"unauthorized"}, ensure_ascii=False), "application/json")
            return
        LAST_SEEN["t"] = time.time()
        if self.path == "/notes":
            try:
                length=int(self.headers.get("Content-Length",0)); data=json.loads(self.rfile.read(length).decode("utf-8"))
                note=v6_add_note(data.get("title",""), data.get("content",""), data.get("tags",[]))
                self._send(200, json.dumps(note, ensure_ascii=False), "application/json")
            except Exception as e:
                self._send(400, json.dumps({"error":str(e)}, ensure_ascii=False), "application/json")
            return
        if self.path == "/chat_stream":
            try:
                length=int(self.headers.get('Content-Length',0)); data=json.loads(self.rfile.read(length).decode('utf-8'))
                msg=str(data.get("message","")).strip()
                if not msg: raise ValueError("empty_message")
                if data.get("session_id"): _chat_select(str(data.get("session_id")))
                attachments=data.get("attachments") or []
                attachment_context=[]
                for a in attachments[:5]:
                    preview=str(a.get("preview", ""))
                    if preview: attachment_context.append(f"[첨부: {a.get('name','파일')}]\n{preview[:12000]}")
                _chat_append("user", msg)
                # run the existing engine before opening the SSE stream so the actual answer remains authoritative
                prompt = msg
                if attachment_context:
                    prompt += "\n\n" + "\n\n".join(attachment_context)
                result=[None]
                error=[None]
                def worker():
                    try: result[0]=think(prompt)
                    except Exception as e: error[0]=e
                t=threading.Thread(target=worker,daemon=True); t.start()
                self.send_response(200)
                self.send_header("Content-Type","text/event-stream; charset=utf-8")
                self.send_header("Cache-Control","no-cache")
                self.send_header("Connection","keep-alive")
                self.end_headers()
                while t.is_alive():
                    self.wfile.write(b": keep-alive\n\n"); self.wfile.flush(); time.sleep(0.08)
                if error[0] is not None:
                    raise error[0]
                reply=str(result[0] or "")
                _chat_append("ai", reply)
                for chunk in _stream_chunks(reply):
                    payload=json.dumps({"type":"delta","text":chunk}, ensure_ascii=False)
                    self.wfile.write(("data: "+payload+"\n\n").encode("utf-8")); self.wfile.flush()
                sess=_chat_current(True)
                done=json.dumps({"type":"done","session_id":sess.get("id"),"title":sess.get("title")}, ensure_ascii=False)
                self.wfile.write(("data: "+done+"\n\n").encode("utf-8")); self.wfile.flush()
            except Exception as e:
                try:
                    self.wfile.write(("data: "+json.dumps({"type":"error","error":str(e)},ensure_ascii=False)+"\n\n").encode("utf-8")); self.wfile.flush()
                except Exception: pass
            return
        if self.path == "/chat_attachment":
            try:
                length=int(self.headers.get('Content-Length',0)); data=json.loads(self.rfile.read(length).decode('utf-8'))
                saved=_decode_attachment(data.get("data",""), data.get("name","attachment.bin"))
                self._send(200,json.dumps({"ok":True,"attachment":saved},ensure_ascii=False),"application/json")
            except Exception as e:
                self._send(400,json.dumps({"ok":False,"error":str(e)},ensure_ascii=False),"application/json")
            return
        if self.path == "/chat":
            try:
                length=int(self.headers.get("Content-Length",0)); data=json.loads(self.rfile.read(length).decode("utf-8"))
                msg=str(data.get("message","")).strip()
                if not msg: raise ValueError("empty_message")
                if data.get("session_id"): _chat_select(str(data.get("session_id")))
                _chat_append("user",msg)
                reply=think(msg)
                _chat_append("ai",reply)
                sess=_chat_current(True)
                self._send(200,json.dumps({"reply":reply,"session_id":sess.get("id"),"title":sess.get("title")},ensure_ascii=False),"application/json")
            except Exception as e:
                self._send(400,json.dumps({"reply":"채팅 처리 중 문제가 생겼어. 다시 시도해줘.","error":str(e)},ensure_ascii=False),"application/json")
            return
        elif self.path == "/chat_sessions":
            d=_chat_db_load()
            items=[{"id":s.get("id"),"title":s.get("title","새 채팅"),"updated_at":s.get("updated_at",0),"message_count":len(s.get("messages",[]))} for s in d.get("sessions",[])]
            self._send(200,json.dumps({"current_id":CURRENT_CHAT_ID,"sessions":items},ensure_ascii=False),"application/json")
            return
        elif self.path == "/chat_session":
            try:
                length=int(self.headers.get("Content-Length",0)); data=json.loads(self.rfile.read(length).decode("utf-8")); action=str(data.get("action","list"))
                if action=="new":
                    sess=_chat_new(str(data.get("title","새 채팅")))
                    out={"ok":True,"session":sess}
                elif action=="select":
                    sess=_chat_select(str(data.get("id","")))
                    if not sess: raise ValueError("session_not_found")
                    out={"ok":True,"session":sess}
                elif action=="rename":
                    sid=str(data.get("id","")); title=str(data.get("title","새 채팅"))[:80]; d=_chat_db_load(); found=False
                    for ss in d["sessions"]:
                        if ss.get("id")==sid: ss["title"]=title; ss["updated_at"]=time.time(); found=True; break
                    if not found: raise ValueError("session_not_found")
                    _chat_db_save(d); out={"ok":True}
                elif action=="delete":
                    sid=str(data.get("id","")); d=_chat_db_load(); d["sessions"]=[ss for ss in d["sessions"] if ss.get("id")!=sid]; _chat_db_save(d)
                    if sid==CURRENT_CHAT_ID: _chat_new()
                    out={"ok":True,"current_id":CURRENT_CHAT_ID}
                else:
                    out={"ok":True,"sessions":_chat_db_load().get("sessions",[])}
                self._send(200,json.dumps(out,ensure_ascii=False),"application/json")
            except Exception as e:
                self._send(400,json.dumps({"ok":False,"error":str(e)},ensure_ascii=False),"application/json")
            return
        elif self.path == "/learn_file":
            try:
                length = int(self.headers.get("Content-Length", 0))
                data = json.loads(self.rfile.read(length).decode("utf-8"))
                raw = base64.b64decode(data.get("data", ""))
                pending["question"] = None   # 배우던 건 잠시 접어두고
                reply = learn_from_file(str(data.get("name", "파일")), raw)
            except Exception:
                reply = "파일을 읽다가 문제가 생겼어. 텍스트 파일(.txt)이 맞는지 봐줄래?"
            self._send(200, json.dumps({"reply": reply}, ensure_ascii=False), "application/json")
        elif self.path == "/project_choose":
            try:
                path=choose_project_folder()
                self._send(200, json.dumps({"reply": (f"Unity 프로젝트 선택됨: {path}" if path else "프로젝트 선택을 취소했어."), "path": path if path else None}, ensure_ascii=False), "application/json")
            except Exception as e:
                self._send(500, json.dumps({"reply": f"프로젝트 선택 오류: {e}"}, ensure_ascii=False), "application/json")
        elif self.path == "/llm_status":
            # 기존 프론트엔드 호환용 엔드포인트. 이제 외부 LLM을 사용하지 않는다.
            self._send(200, json.dumps({
                "enabled": False,
                "reachable": False,
                "model": None,
                "url": None,
                "engine": "local_rule_reasoner",
                "version": LOCAL_ANSWER_VERSION,
            }, ensure_ascii=False), "application/json")
        elif self.path == "/mode_status":
            self._send(200, json.dumps(performance_profile_status(), ensure_ascii=False), "application/json")
        elif self.path == "/mode":
            try:
                length = int(self.headers.get("Content-Length", 0))
                body = self.rfile.read(length).decode("utf-8") if length else "{}"
                data = json.loads(body or "{}")
                mode = str(data.get("mode", "think"))
                if not apply_ai_mode(mode):
                    self._send(400, json.dumps({"ok": False, "error": "unknown_mode"}, ensure_ascii=False), "application/json")
                else:
                    self._send(200, json.dumps({"ok": True, **performance_profile_status()}, ensure_ascii=False), "application/json")
            except Exception as e:
                self._send(500, json.dumps({"ok": False, "error": str(e)}, ensure_ascii=False), "application/json")
        elif self.path == "/dataset_stats":
            total_chunks, total_files = dataset_stats()
            self._send(200, json.dumps({"files": total_files, "chunks": total_chunks}, ensure_ascii=False), "application/json")
        elif self.path == "/collector_status":
            self._send(200, json.dumps(collector_status(), ensure_ascii=False, default=str), "application/json")
        elif self.path == "/collector_start":
            try:
                length = int(self.headers.get("Content-Length", 0))
                body = self.rfile.read(length).decode("utf-8") if length else "{}"
                data = json.loads(body or "{}")
                result = start_collector(data.get("max_pages"))
                self._send(200, json.dumps(result, ensure_ascii=False), "application/json")
            except Exception as e:
                self._send(500, json.dumps({"ok": False, "message": str(e)}, ensure_ascii=False), "application/json")
        elif self.path == "/pipeline_start":
            try:
                length = int(self.headers.get("Content-Length", 0))
                body = self.rfile.read(length).decode("utf-8") if length else "{}"
                data = json.loads(body or "{}")
                result = start_pipeline(data.get("max_pages"))
                self._send(200, json.dumps(result, ensure_ascii=False), "application/json")
            except Exception as e:
                self._send(500, json.dumps({"ok": False, "message": str(e)}, ensure_ascii=False), "application/json")
        elif self.path == "/ci_status":
            self._send(200, json.dumps({"reply": ci_summary()}, ensure_ascii=False), "application/json")
        elif self.path == "/ci_run":
            try:
                length = int(self.headers.get('Content-Length', 0))
                body = self.rfile.read(length).decode('utf-8') if length else '{}'
                data = json.loads(body or '{}')
                result = run_ci_regression_gate(include_playmode=bool(data.get('playmode', False)))
                self._send(200, json.dumps({"reply": result}, ensure_ascii=False), "application/json")
            except Exception as e:
                self._send(500, json.dumps({"reply": str(e)}, ensure_ascii=False), "application/json")
        elif self.path == "/git_status":
            self._send(200, json.dumps({"reply": git_status()}, ensure_ascii=False), "application/json")
        elif self.path == "/git_diff":
            self._send(200, json.dumps({"reply": git_diff()}, ensure_ascii=False), "application/json")
        elif self.path == "/reset":
            pending["question"] = None
            HISTORY.clear()
            CONTEXT["topic"] = []
            self._send(200, "{}", "application/json")
        elif self.path == "/shutdown":
            self._send(200, "{}", "application/json")
            stop_server()
        else:
            self._send(404, "{}", "application/json")

    def log_message(self, *args):
        pass


def performance_profile_status():
    return {
        "profile": MYAI_PROFILE,
        "mode": AI_MODE,
        "mode_name": AI_MODE_LABELS[AI_MODE]["name"],
        "mode_description": AI_MODE_LABELS[AI_MODE]["desc"],
        "max_index_chunks": DATASET_MAX_INDEX_CHUNKS,
        "dataset_batch_size": DATASET_BATCH_SIZE,
        "auto_benchmark": MYAI_AUTO_BENCHMARK,
        "auto_groundtruth": MYAI_AUTO_GROUNDTRUTH,
        "auto_pipeline_default": MYAI_AUTO_PIPELINE_DEFAULT,
        "answer_max_chars": LOCAL_ANSWER_MAX_CHARS,
        "answer_max_evidence": LOCAL_ANSWER_MAX_EVIDENCE,
    }

def main():
    server = None
    for port in (8942, 8123, 8777, 0):
        try:
            server = http.server.ThreadingHTTPServer((BIND_HOST, port), Handler)
            break
        except OSError:
            continue
    if server is None:
        raise RuntimeError("AI 서버 포트를 열지 못했어.")
    SERVER["instance"] = server
    port = server.server_address[1]
    print("[성능 프로필]", json.dumps(performance_profile_status(), ensure_ascii=False))
    if TAILSCALE_MODE:
        tailscale_url = f"http://{TAILSCALE_IP}:{port}/?token={urllib.parse.quote(SERVER_TOKEN)}"
        print("[Tailscale 모드] Chromebook/원격 기기에서 아래 주소로 접속하세요:")
        print("  ", tailscale_url)
        print("[보안] 서버는 Tailscale 인터페이스에만 바인딩되어 있어요.")
        print("[보안] 토큰 인증도 활성화되어 있어요.")
        print("[주의] HTTPS는 사용하지 않으므로 Tailscale 네트워크 내부에서만 사용하세요.")
        url = tailscale_url
    elif REMOTE_MODE:
        lan_urls = local_lan_urls(port)
        local_url = f"http://127.0.0.1:{port}/?token={urllib.parse.quote(SERVER_TOKEN)}"
        print("[원격 모드] 같은 Wi-Fi의 Chromebook에서 아래 주소로 접속하세요:")
        for u in lan_urls: print("  ", u)
        print("[보안] 토큰:", SERVER_TOKEN)
        print("[보안] 인터넷에 포트를 직접 공개하지 말고 같은 LAN/VPN에서만 사용하세요.")
        url = local_url
    else:
        url = f"http://127.0.0.1:{port}"
        print(f"나의 수제 AI 실행 중 -> {url}  (화면의 '끄기' 버튼으로 종료)")

    # v5.2: 프로필별 자동 벤치마크
    if MYAI_AUTO_BENCHMARK:
        try:
            bench = run_ai_benchmark(full=False, announce=False)
            print(f"[AI 벤치마크] {bench['score']:.2f}/100 ({bench['passed']}/{bench['total']})")
            if bench.get("delta_vs_previous") is not None:
                print(f"[AI 벤치마크] 이전 대비 {bench['delta_vs_previous']:+.2f}점")
        except Exception as e:
            print("[AI 벤치마크] 자동 측정 실패:", e)
    if MYAI_AUTO_GROUNDTRUTH:
        try:
            if AI_GT_CASES.exists():
                gt = run_groundtruth_harness("test", announce=False)
                print(f"[GroundTruth] {gt['score']:.2f}/100 ({gt['passed']}/{gt['total']}) · EvidenceVerifier=미측정")
        except Exception as e:
            print("[GroundTruth] 자동 측정 실패:", e)

    # v4.3: 환경변수로 완전 자동 파이프라인 시작 가능
    if MYAI_AUTO_PIPELINE_DEFAULT or os.environ.get("MYAI_AUTO_PIPELINE", "0").strip().lower() in {"1", "true", "yes", "on"}:
        try:
            auto_result = start_pipeline(int(os.environ.get("MYAI_COLLECTOR_MAX_PAGES", COLLECTOR_STATE["max_pages"])))
            print("[자동 파이프라인]", auto_result.get("message"))
        except Exception as e:
            print("[자동 파이프라인] 시작 실패:", e)
    threading.Thread(target=watchdog, daemon=True).start()
    threading.Timer(0.7, lambda: webbrowser.open(url)).start()
    try:
        server.serve_forever()
    except KeyboardInterrupt:
        pass
    print("AI를 재웠어요. 다음에 또 만나요!")


if __name__ == "__main__":
    main()


# ========================= v4.7 CODE REVIEW ENGINE =========================
import ast as _ast_review
import re as _re_review
from pathlib import Path as _PathReview

_REVIEW_RULES = [
    ("SECURITY", "hardcoded_secret", re.compile(r"(?i)(api[_-]?key|password|secret|token)\s*=\s*['\"]"), 10,
     "하드코딩된 비밀값 가능성"),
    ("SECURITY", "dangerous_eval", re.compile(r"\b(eval|exec)\s*\("), 10,
     "eval/exec 사용"),
    ("PERFORMANCE", "unity_getcomponent_update", re.compile(r"void\s+Update\s*\([^)]*\).*?GetComponent\s*<", re.S|re.I), 7,
     "Update 내부 GetComponent 반복 가능성"),
    ("PERFORMANCE", "resources_load_update", re.compile(r"void\s+Update\s*\([^)]*\).*?Resources\.Load\s*\(", re.S|re.I), 8,
     "Update 내부 Resources.Load 반복 가능성"),
    ("QUALITY", "debug_log", re.compile(r"\bDebug\.Log(?:Warning|Error)?\s*\("), 2,
     "Debug.Log 사용 검토"),
]

def _review_python_file(path):
    p=_PathReview(path)
    text=p.read_text(encoding='utf-8-sig', errors='replace')
    findings=[]
    try:
        tree=_ast_review.parse(text, filename=str(p))
    except SyntaxError as e:
        findings.append({"severity":"HIGH","category":"SYNTAX","line":getattr(e,'lineno',0) or 0,"message":f"Python 구문 오류: {e.msg}"})
        return findings
    # Complexity-ish checks
    for node in _ast_review.walk(tree):
        if isinstance(node, (_ast_review.FunctionDef, _ast_review.AsyncFunctionDef)):
            end=getattr(node,'end_lineno',node.lineno)
            span=end-node.lineno+1
            if span>80:
                findings.append({"severity":"MEDIUM","category":"MAINTAINABILITY","line":node.lineno,"message":f"함수 {node.name}이 {span}줄로 큼. 분리 검토 권장."})
        if isinstance(node, _ast_review.For):
            for child in _ast_review.walk(node):
                if isinstance(child, _ast_review.Call) and isinstance(child.func,_ast_review.Attribute) and child.func.attr in {'append','extend'}:
                    pass
    # Regex heuristics line-aware
    for i,line in enumerate(text.splitlines(),1):
        if re.search(r'(?i)(api[_-]?key|password|secret|token)\s*=\s*[\'\"]', line):
            findings.append({"severity":"HIGH","category":"SECURITY","line":i,"message":"하드코딩된 비밀값 가능성"})
        if re.search(r'\b(eval|exec)\s*\(', line):
            findings.append({"severity":"HIGH","category":"SECURITY","line":i,"message":"eval/exec 사용"})
    return findings

def _review_csharp_file(path):
    p=_PathReview(path)
    text=p.read_text(encoding='utf-8-sig', errors='replace')
    lines=text.splitlines()
    findings=[]
    # Structural checks
    if text.count('{') != text.count('}'):
        findings.append({"severity":"HIGH","category":"SYNTAX","line":1,"message":"중괄호 수 불일치"})
    # Basic C# heuristics
    for i,line in enumerate(lines,1):
        if re.search(r'(?i)\b(?:api[_-]?key|password|secret|token)\s*=\s*"', line):
            findings.append({"severity":"HIGH","category":"SECURITY","line":i,"message":"하드코딩된 비밀값 가능성"})
        if re.search(r'\bDebug\.Log(?:Warning|Error)?\s*\(', line):
            findings.append({"severity":"LOW","category":"QUALITY","line":i,"message":"Debug.Log 사용. 릴리즈 로그 정책 확인 권장"})
        if re.search(r'(?i)Resources\.Load\s*<.*>\s*\(', line):
            findings.append({"severity":"MEDIUM","category":"PERFORMANCE","line":i,"message":"Resources.Load 사용. 빈번한 호출이면 캐싱 검토"})
        if re.search(r'(?i)GetComponent\s*<.*>\s*\(', line):
            findings.append({"severity":"LOW","category":"PERFORMANCE","line":i,"message":"GetComponent 호출. Update/반복 루프 내부라면 캐싱 검토"})
    # Long methods by braces (heuristic)
    method_re=re.compile(r'\b(?:public|private|protected|internal)?\s*(?:async\s+)?(?:static\s+)?[\w<>\[\],.?]+\s+\w+\s*\([^;{}]*\)\s*\{')
    for m in method_re.finditer(text):
        start=text[:m.start()].count('\n')+1
        depth=0; end=start
        for idx,ch in enumerate(text[m.end()-1:], start=m.end()-1):
            if ch=='{': depth+=1
            elif ch=='}':
                depth-=1
                if depth==0:
                    end=text[:idx].count('\n')+1; break
        span=max(0,end-start+1)
        if span>100:
            findings.append({"severity":"MEDIUM","category":"MAINTAINABILITY","line":start,"message":f"메서드 길이가 약 {span}줄입니다. 분리 검토 권장"})
    return findings

def review_code_file(path):
    ext=_PathReview(path).suffix.lower()
    if ext=='.py': return _review_python_file(path)
    if ext=='.cs': return _review_csharp_file(path)
    return []

def code_review_summary(path):
    findings=review_code_file(path)
    weights={"HIGH":10,"MEDIUM":5,"LOW":1}
    penalty=sum(weights.get(f.get('severity'),0) for f in findings)
    score=max(0,100-penalty)
    counts={k:sum(1 for f in findings if f.get('severity')==k) for k in ('HIGH','MEDIUM','LOW')}
    return {"path":str(path),"score":score,"findings":findings,"counts":counts}

def run_code_review_target(target):
    p=_PathReview(target)
    results=[]
    if p.is_file():
        results=[code_review_summary(p)]
    elif p.is_dir():
        for f in p.rglob('*'):
            if f.is_file() and f.suffix.lower() in {'.py','.cs'}:
                try: results.append(code_review_summary(f))
                except Exception as e: results.append({"path":str(f),"score":0,"findings":[{"severity":"HIGH","category":"REVIEW","line":0,"message":str(e)}],"counts":{}})
    overall=round(sum(r['score'] for r in results)/len(results),2) if results else 0.0
    report={"overall_score":overall,"files":results,"timestamp":time.time()}
    try:
        Path('ai_code_review').mkdir(exist_ok=True)
        Path('ai_code_review/latest.json').write_text(json.dumps(report,ensure_ascii=False,indent=2),encoding='utf-8')
    except Exception: pass
    return report

# Integrate with the existing command router without disturbing previous commands.
_original_handle_message_v47 = globals().get('handle_user_message')

def _handle_code_review_commands_v47(user_text):
    t=(user_text or '').strip()
    if t in {'코드리뷰','코드 리뷰','코드리뷰 실행'}:
        target=globals().get('PROJECT_ROOT') or globals().get('project_root') or '.'
        return 'CODE_REVIEW_JSON\n'+json.dumps(run_code_review_target(target), ensure_ascii=False, indent=2)
    if t.startswith('코드리뷰:'):
        target=t.split(':',1)[1].strip()
        return 'CODE_REVIEW_JSON\n'+json.dumps(run_code_review_target(target), ensure_ascii=False, indent=2)
    return None
if _original_handle_message_v47 and not globals().get('_V47_REVIEW_ROUTER_PATCHED'):
    def handle_user_message(user_text, *args, **kwargs):
        r=_handle_code_review_commands_v47(user_text)
        if r is not None: return r
        return _original_handle_message_v47(user_text, *args, **kwargs)
    globals()['_V47_REVIEW_ROUTER_PATCHED']=True

# Append benchmark record hook if a benchmark recorder exists.
def benchmark_record_code_review_v47():
    try:
        r=run_code_review_target(globals().get('PROJECT_ROOT') or globals().get('project_root') or '.')
        p=Path('ai_benchmark'); p.mkdir(exist_ok=True)
        hist=p/'history.jsonl'
        with hist.open('a',encoding='utf-8') as f:
            f.write(json.dumps({"metric":"code_review_score","score":r['overall_score'],"timestamp":time.time()},ensure_ascii=False)+'\n')
        return r
    except Exception as e:
        return {"overall_score":0,"error":str(e)}



# ==================== v4.8 REQUIREMENTS CLARIFIER ====================
# Deterministic requirements-clarification layer for Unity/C# development tasks.
# It asks only for missing requirements, auto-fills discoverable project facts,
# persists the session, and hands a confirmed spec to the existing orchestrator.

V48_REQ_VERSION = "4.8"
V48_REQ_FILE = Path("ai_requirements") / "latest.json"
_V48_REQ_SESSION = {"active": False, "request": "", "facts": {}, "missing": [], "confirmed": False, "timestamp": 0}


def _v48_save_session():
    try:
        V48_REQ_FILE.parent.mkdir(exist_ok=True)
        V48_REQ_FILE.write_text(json.dumps(_V48_REQ_SESSION, ensure_ascii=False, indent=2), encoding="utf-8")
    except Exception:
        pass


def _v48_load_session():
    global _V48_REQ_SESSION
    try:
        if V48_REQ_FILE.exists():
            data = json.loads(V48_REQ_FILE.read_text(encoding="utf-8"))
            if isinstance(data, dict):
                _V48_REQ_SESSION.update(data)
    except Exception:
        pass


def _v48_project_root():
    p = globals().get("PROJECT_ROOT") or globals().get("project_root")
    try:
        return Path(p) if p else None
    except Exception:
        return None


def _v48_project_facts():
    facts = {}
    root = _v48_project_root()
    if not root or not root.exists():
        return facts
    try:
        pv = root / "ProjectSettings" / "ProjectVersion.txt"
        if pv.exists():
            m = re.search(r"m_EditorVersion:\s*([^\s]+)", pv.read_text(encoding="utf-8", errors="ignore"))
            if m:
                facts["unity_version"] = m.group(1)
    except Exception:
        pass
    try:
        cs_files = list(root.rglob("*.cs"))
        facts["csharp_files"] = len(cs_files)
        names = {p.name.lower() for p in cs_files[:5000]}
        if any("inputsystem" in n for n in names):
            facts["input_system"] = "가능성: Input System 관련 코드/패키지 감지"
        elif any("playerinput" in n for n in names):
            facts["input_system"] = "PlayerInput 감지"
    except Exception:
        pass
    try:
        manifests = [root / "Packages" / "manifest.json", root / "Packages" / "packages-lock.json"]
        for mf in manifests:
            if mf.exists():
                raw = mf.read_text(encoding="utf-8", errors="ignore")
                if "com.unity.inputsystem" in raw:
                    facts["input_system"] = "Unity Input System"
                if "com.unity.netcode.gameobjects" in raw or "com.unity.transport" in raw:
                    facts["networking"] = "Unity Netcode/Transport 관련 패키지 감지"
                break
    except Exception:
        pass
    return facts


def _v48_missing_for(request):
    t = normalize(str(request or ""))
    # Core questions for common game-development requests.
    facts = _v48_project_facts()
    missing = []
    if not any(k in t for k in ("2d", "3d", "횡스크롤", "플랫포머", "탑다운")):
        missing.append(("dimension", "2D인지 3D인지?"))
    if any(k in t for k in ("대시", "dash")):
        if not re.search(r"\b\d+(?:\.\d+)?\s*(?:초|s|sec)\b", request, re.I):
            missing.append(("dash_duration", "대시 시간은 몇 초로 할까?"))
        if not re.search(r"쿨타임|cooldown|cool down", t):
            missing.append(("dash_cooldown", "대시 쿨타임이 필요해? 필요하다면 몇 초?"))
        if not any(k in t for k in ("공중", "에어", "air")):
            missing.append(("air_dash", "공중 대시를 허용할까?"))
    if any(k in t for k in ("인벤토리", "inventory")):
        if not any(k in t for k in ("슬롯", "stack", "스택", "최대")):
            missing.append(("inventory_capacity", "인벤토리 슬롯 수와 아이템 스택 가능 여부를 정할까?"))
    if any(k in t for k in ("저장", "세이브", "save", "load")) and "저장" in t:
        if not any(k in t for k in ("json", "binary", "scriptableobject", "playerprefs", "세이브파일")):
            missing.append(("save_format", "저장 형식은 JSON/바이너리/다른 방식 중 무엇을 사용할까?"))
    if "멀티" in t or "multiplayer" in t or "온라인" in t:
        if "networking" not in facts:
            missing.append(("networking_stack", "멀티플레이 네트워크는 어떤 솔루션을 사용할까? (예: Unity Netcode)"))
    if "애니" in t or "animation" in t:
        if not any(k in t for k in ("animator", "trigger", "state", "animation event")):
            missing.append(("animation", "애니메이션은 기존 Animator 상태를 사용할까, 새 상태를 추가할까?"))
    return missing, facts


def _v48_start(request):
    global _V48_REQ_SESSION
    missing, facts = _v48_missing_for(request)
    _V48_REQ_SESSION = {
        "active": True,
        "request": str(request).strip(),
        "facts": facts,
        "missing": [{"key": k, "question": q} for k, q in missing],
        "answers": {},
        "confirmed": False,
        "timestamp": time.time(),
    }
    _v48_save_session()
    if not missing:
        return _v48_confirm_message()
    lines = ["🧩 요구사항 분석을 시작했어.", f"요청: {_V48_REQ_SESSION['request']}"]
    if facts:
        lines.append("\n🔎 프로젝트에서 자동 확인한 정보:")
        lines.extend([f"- {k}: {v}" for k, v in facts.items()])
    lines.append("\n❓ 아직 필요한 조건:")
    for i, item in enumerate(_V48_REQ_SESSION["missing"], 1):
        lines.append(f"{i}. {item['question']}")
    lines.append("\n한 번에 답해도 되고 하나씩 답해도 돼. 모두 정해지면 '요구사항확정'이라고 말해줘.")
    return "\n".join(lines)


def _v48_apply_answer(text):
    global _V48_REQ_SESSION
    if not _V48_REQ_SESSION.get("active"):
        return None
    t = str(text or "").strip()
    norm = normalize(t)
    if norm in ("요구사항취소", "개발요청취소", "분석취소"):
        _V48_REQ_SESSION = {"active": False, "request": "", "facts": {}, "missing": [], "confirmed": False, "timestamp": time.time()}
        _v48_save_session()
        return "요구사항 분석을 취소했어."
    if norm in ("요구사항상태", "개발요구사항상태"):
        return _v48_status()
    if norm in ("요구사항확정", "요구사항완료", "개발요구사항확정"):
        if _V48_REQ_SESSION.get("missing"):
            return "아직 정하지 않은 조건이 있어. 먼저 남은 질문에 답해줘."
        return _v48_confirm_message()
    # Match an answer to the most likely outstanding slot instead of blindly
    # assigning it to the first question.
    missing = _V48_REQ_SESSION.get("missing") or []
    answers = _V48_REQ_SESSION.setdefault("answers", {})
    target = None
    if re.search(r"\b\d+(?:\.\d+)?\s*(?:초|초간|s|sec|seconds?)\b", t, re.I):
        for item in missing:
            if item["key"] in ("dash_duration", "dash_cooldown"):
                target = item; break
    elif norm in ("예", "응", "가능", "가능해", "허용", "허용해", "yes", "y", "네") or norm in ("아니", "아니요", "불가", "금지", "no", "n"):
        for item in missing:
            if item["key"] in ("air_dash",):
                target = item; break
    elif any(k in norm for k in ("2d", "2차원", "횡스크롤", "플랫포머")) or any(k in norm for k in ("3d", "3차원", "탑다운")):
        for item in missing:
            if item["key"] == "dimension": target = item; break
    if target is None:
        for item in missing:
            if item["key"] not in answers:
                target = item; break
    if target is not None:
        answers[target["key"]] = t
        _V48_REQ_SESSION["missing"] = [x for x in missing if x["key"] != target["key"]]
        _v48_save_session()
        if _V48_REQ_SESSION["missing"]:
            return f"좋아, '{target['key']}'에 저장했어. 다음 조건: {_V48_REQ_SESSION['missing'][0]['question']}"
        return _v48_confirm_message()
    return None


def _v48_confirm_message():
    req = _V48_REQ_SESSION.get("request", "")
    facts = _V48_REQ_SESSION.get("facts", {})
    answers = _V48_REQ_SESSION.get("answers", {})
    lines = ["✅ 현재 요구사항을 정리했어:", f"- 요청: {req}"]
    for k, v in facts.items():
        lines.append(f"- {k}: {v}")
    for k, v in answers.items():
        lines.append(f"- {k}: {v}")
    lines.append("\n이 내용으로 구현을 시작하려면 '요구사항확정'을 다시 입력하거나 '개발시작'이라고 해줘.")
    _V48_REQ_SESSION["confirmed_preview"] = True
    _v48_save_session()
    return "\n".join(lines)


def _v48_status():
    if not _V48_REQ_SESSION.get("active"):
        return "현재 진행 중인 요구사항 분석이 없어."
    return json.dumps(_V48_REQ_SESSION, ensure_ascii=False, indent=2)


def _v48_build_spec():
    spec = {
        "version": V48_REQ_VERSION,
        "request": _V48_REQ_SESSION.get("request", ""),
        "project_facts": _V48_REQ_SESSION.get("facts", {}),
        "answers": _V48_REQ_SESSION.get("answers", {}),
        "created_at": time.time(),
    }
    try:
        Path("ai_requirements").mkdir(exist_ok=True)
        Path("ai_requirements/spec.json").write_text(json.dumps(spec, ensure_ascii=False, indent=2), encoding="utf-8")
    except Exception:
        pass
    return spec


def _v48_start_development():
    if not _V48_REQ_SESSION.get("active"):
        return "먼저 '개발요청: ...'으로 요구사항 분석을 시작해줘."
    if _V48_REQ_SESSION.get("missing"):
        return "아직 필요한 조건이 남아 있어. '요구사항상태'를 확인하고 답해줘."
    spec = _v48_build_spec()
    _V48_REQ_SESSION["confirmed"] = True
    _V48_REQ_SESSION["active"] = False
    _v48_save_session()
    # Handoff to the existing development orchestrator.
    handoff = f"개발작업: {spec['request']}\n요구사항: {json.dumps(spec, ensure_ascii=False)}"
    try:
        result = handle_development_orchestrator(handoff)
        if result:
            return "🚀 요구사항 확정. 개발 오케스트레이터로 넘겼어.\n\n" + str(result)
    except Exception as e:
        return f"요구사항은 확정했지만 개발 오케스트레이터 실행에 실패했어: {e}"
    return "✅ 요구사항을 확정하고 저장했어. 다음 단계는 개발 오케스트레이터야."


def _v48_requirement_intercept(text):
    raw = str(text or "").strip()
    n = normalize(raw)
    if n.startswith("개발요청") or n.startswith("요구사항분석"):
        parts = re.split(r"[:：]", raw, maxsplit=1)
        request = parts[1].strip() if len(parts) == 2 and parts[1].strip() else ""
        if not request:
            return "개발할 기능을 뒤에 적어줘. 예: 개발요청: 플레이어 대시 기능 추가"
        return _v48_start(request)
    if n in ("요구사항상태", "요구사항확인", "요구사항취소", "요구사항확정", "개발요구사항확정", "개발시작"):
        if n in ("개발시작",):
            return _v48_start_development()
        return _v48_apply_answer(raw)
    if _V48_REQ_SESSION.get("active"):
        return _v48_apply_answer(raw)
    return None

# Wrap think() once so the requirement layer runs before executing development commands.
if not globals().get("_V48_THINK_PATCHED"):
    _v48_load_session()
    _v48_original_think = think
    def think(text):
        r = _v48_requirement_intercept(text)
        if r is not None:
            return r
        return _v48_original_think(text)
    globals()["_V48_THINK_PATCHED"] = True

# Extend the deterministic benchmark with requirement-clarification regression tests.
def run_requirement_benchmark_v48():
    tests = []
    old = dict(_V48_REQ_SESSION)
    try:
        r = _v48_start("플레이어 대시 기능 추가")
        ok1 = "요구사항" in r and "대시" in r
        tests.append({"name":"요구사항 시작", "passed":ok1})
        r2 = _v48_apply_answer("0.2초")
        ok2 = "저장했어" in r2 or "다음 조건" in r2
        tests.append({"name":"요구사항 답변 저장", "passed":ok2})
        ok3 = bool(_V48_REQ_SESSION.get("request")) and bool(_V48_REQ_SESSION.get("answers"))
        tests.append({"name":"요구사항 세션 유지", "passed":ok3})
    finally:
        _V48_REQ_SESSION.clear(); _V48_REQ_SESSION.update(old)
    return tests


# ==================== v4.9 LONG-RUNNING JOB MANAGER ====================
# Persistent, resumable development jobs. This layer does not bypass existing
# approval gates; it only remembers what is being worked on and what to do next.
V49_JOB_VERSION = "4.9"
V49_JOB_DIR = Path("ai_jobs")
V49_JOB_DIR.mkdir(exist_ok=True)
V49_JOB_FILE = V49_JOB_DIR / "current.json"
V49_JOB_HISTORY = V49_JOB_DIR / "history.jsonl"
V49_JOB = {
    "version": V49_JOB_VERSION,
    "job_id": "",
    "status": "idle",
    "request": "",
    "created_at": 0,
    "updated_at": 0,
    "stage": "idle",
    "stage_index": 0,
    "last_action": "",
    "last_result": "",
    "notes": [],
    "context": {},
}

V49_STAGES = [
    ("requirements", "요구사항 확정"),
    ("analysis", "프로젝트 분석"),
    ("impact", "영향도 분석"),
    ("plan", "구현 계획"),
    ("patch", "수정안/Diff"),
    ("approval", "사용자 승인 대기"),
    ("apply", "코드 적용"),
    ("test", "테스트"),
    ("repair", "실패 분석/수정 제안"),
    ("benchmark", "벤치마크"),
    ("git", "Git 결과 정리"),
    ("complete", "완료"),
]


def _v49_save_job(extra_history=True):
    try:
        V49_JOB_DIR.mkdir(exist_ok=True)
        V49_JOB["updated_at"] = time.time()
        V49_JOB_FILE.write_text(json.dumps(V49_JOB, ensure_ascii=False, indent=2), encoding="utf-8")
        if extra_history:
            with V49_JOB_HISTORY.open("a", encoding="utf-8") as f:
                f.write(json.dumps(dict(V49_JOB), ensure_ascii=False) + "\n")
    except Exception:
        pass


def _v49_load_job():
    global V49_JOB
    try:
        if V49_JOB_FILE.exists():
            data = json.loads(V49_JOB_FILE.read_text(encoding="utf-8"))
            if isinstance(data, dict):
                V49_JOB.update(data)
    except Exception:
        pass


def _v49_new_id():
    return "JOB-" + datetime.now().strftime("%Y%m%d-%H%M%S") + "-" + uuid.uuid4().hex[:6].upper()


def _v49_stage_label(stage):
    for key, label in V49_STAGES:
        if key == stage:
            return label
    return stage


def _v49_status_text():
    _v49_load_job()
    if not V49_JOB.get("job_id"):
        return "진행 중인 장기 작업이 없어. '장기작업: ...' 또는 '개발요청: ...'으로 시작해줘."
    lines = [
        f"🧭 작업 ID: {V49_JOB.get('job_id')}",
        f"상태: {V49_JOB.get('status')}",
        f"요청: {V49_JOB.get('request')}",
        f"현재 단계: {_v49_stage_label(V49_JOB.get('stage'))}",
        f"마지막 작업: {V49_JOB.get('last_action') or '(없음)'}",
    ]
    if V49_JOB.get("last_result"):
        lines.append("마지막 결과:")
        lines.append(str(V49_JOB["last_result"])[:2000])
    if V49_JOB.get("notes"):
        lines.append("메모:")
        lines.extend(f"- {n}" for n in V49_JOB["notes"][-10:])
    return "\n".join(lines)


def _v49_start_job(request):
    global V49_JOB
    _v49_load_job()
    if V49_JOB.get("status") in ("running", "waiting_approval", "paused") and V49_JOB.get("job_id"):
        return f"이미 진행 중인 작업 {V49_JOB['job_id']}가 있어. '작업상태' 또는 '작업계속'으로 확인해줘."
    V49_JOB = {
        "version": V49_JOB_VERSION,
        "job_id": _v49_new_id(),
        "status": "running",
        "request": str(request).strip(),
        "created_at": time.time(),
        "updated_at": time.time(),
        "stage": "requirements",
        "stage_index": 0,
        "last_action": "job_created",
        "last_result": "",
        "notes": [],
        "context": {},
    }
    _v49_save_job()
    # Hand off to the existing requirement clarifier. It remains the authority
    # for asking questions and never bypasses approval.
    result = None
    try:
        result = _V49_PREV_THINK("개발요청: " + str(request).strip())
        if _V48_REQ_SESSION.get("missing"):
            V49_JOB["status"] = "paused"
        elif _V48_REQ_SESSION.get("active"):
            V49_JOB["status"] = "paused"
        else:
            V49_JOB["stage"] = "analysis"
            V49_JOB["stage_index"] = 1
        V49_JOB["last_action"] = "requirements_started"
        V49_JOB["last_result"] = str(result or "")
        _v49_save_job()
    except Exception as e:
        V49_JOB["status"] = "paused"
        V49_JOB["last_action"] = "requirements_error"
        V49_JOB["last_result"] = str(e)
        _v49_save_job()
        return f"작업 {V49_JOB['job_id']}를 만들었지만 요구사항 단계에서 오류가 났어: {e}"
    return f"🧭 장기 작업 {V49_JOB['job_id']}를 시작했어.\n\n{result or _v49_status_text()}"


def _v49_advance_job():
    _v49_load_job()
    if not V49_JOB.get("job_id"):
        return "진행 중인 작업이 없어. '장기작업: ...' 또는 '개발요청: ...'으로 시작해줘."
    if V49_JOB.get("status") == "complete":
        return _v49_status_text()
    stage = V49_JOB.get("stage", "requirements")
    command = None
    if stage == "requirements":
        if _V48_REQ_SESSION.get("missing"):
            V49_JOB["status"] = "paused"
            V49_JOB["last_result"] = _v48_status()
            V49_JOB["last_action"] = "waiting_for_requirements"
        else:
            command = "개발시작"
    elif stage == "analysis":
        command = "개발다음"
    elif stage in {"impact", "plan", "patch", "apply", "test", "repair", "benchmark"}:
        command = "개발다음"
    elif stage == "approval":
        V49_JOB["status"] = "waiting_approval"
        V49_JOB["last_action"] = "waiting_for_user_approval"
        V49_JOB["last_result"] = "수정안 확인 후 '수정적용 승인'이 필요해."
    elif stage == "git":
        command = "git 커밋 준비"
    elif stage == "complete":
        V49_JOB["status"] = "complete"
    if command:
        try:
            result = _V49_PREV_THINK(command)
            V49_JOB["last_action"] = command
            V49_JOB["last_result"] = str(result or "")
            # Mirror the existing development orchestrator's state into our job state.
            try:
                dev_state = _dev_load()
                if dev_state.get("request"):
                    cur = int(dev_state.get("current_step", 0) or 0)
                    steps = dev_state.get("steps") or []
                    if cur < len(steps):
                        V49_JOB["stage_index"] = min(cur, len(V49_STAGES)-1)
                        if dev_state.get("status") == "awaiting_approval":
                            V49_JOB["stage"] = "approval"
                            V49_JOB["status"] = "waiting_approval"
                        elif dev_state.get("status") == "complete":
                            V49_JOB["stage"] = "complete"
                            V49_JOB["status"] = "complete"
                        else:
                            stage_map = ["analysis", "impact", "plan", "patch", "approval", "test", "repair", "benchmark"]
                            if cur < len(stage_map):
                                V49_JOB["stage"] = stage_map[cur]
                                V49_JOB["status"] = "running"
                    elif dev_state.get("status") == "complete":
                        V49_JOB["stage"] = "git"
                        V49_JOB["status"] = "running"
            except Exception:
                pass
            _v49_save_job()
            return result or _v49_status_text()
        except Exception as e:
            V49_JOB["status"] = "paused"
            V49_JOB["last_action"] = "advance_error"
            V49_JOB["last_result"] = str(e)
    _v49_save_job()
    return _v49_status_text()


def _v49_resume_job():
    _v49_load_job()
    if not V49_JOB.get("job_id"):
        return "복구할 장기 작업이 없어."
    if V49_JOB.get("status") == "complete":
        return _v49_status_text()
    V49_JOB["status"] = "running"
    V49_JOB["last_action"] = "job_resumed"
    _v49_save_job()
    return _v49_advance_job()


def _v49_pause_job():
    _v49_load_job()
    if not V49_JOB.get("job_id"):
        return "진행 중인 작업이 없어."
    V49_JOB["status"] = "paused"
    V49_JOB["last_action"] = "job_paused"
    _v49_save_job()
    return f"⏸️ 작업 {V49_JOB['job_id']}를 일시정지했어. 파일 변경은 하지 않았어. 나중에 '작업계속'으로 이어서 할 수 있어."


def _v49_cancel_job():
    global V49_JOB
    _v49_load_job()
    if not V49_JOB.get("job_id"):
        return "진행 중인 작업이 없어."
    old = dict(V49_JOB)
    old["status"] = "cancelled"
    old["last_action"] = "job_cancelled"
    with V49_JOB_HISTORY.open("a", encoding="utf-8") as f:
        f.write(json.dumps(old, ensure_ascii=False) + "\n")
    V49_JOB = {
        "version": V49_JOB_VERSION,
        "job_id": "",
        "status": "idle",
        "request": "",
        "created_at": 0,
        "updated_at": time.time(),
        "stage": "idle",
        "stage_index": 0,
        "last_action": "",
        "last_result": "",
        "notes": [],
        "context": {},
    }
    _v49_save_job(extra_history=False)
    return "작업을 취소했어. 이미 승인되어 적용된 코드나 Git 변경은 자동으로 되돌리지 않았어."


def _v49_handle_command(text):
    raw = str(text or "").strip()
    n = normalize(raw)
    if n.startswith("장기작업"):
        parts = re.split(r"[:：]", raw, maxsplit=1)
        req = parts[1].strip() if len(parts) == 2 else ""
        if not req:
            return "작업 내용을 적어줘. 예: 장기작업: 플레이어 대시 기능 추가"
        return _v49_start_job(req)
    if n.startswith("작업시작"):
        parts = re.split(r"[:：]", raw, maxsplit=1)
        req = parts[1].strip() if len(parts) == 2 else ""
        if not req:
            return "작업 내용을 적어줘. 예: 작업시작: 플레이어 대시 기능 추가"
        return _v49_start_job(req)
    if n in ("작업상태", "장기작업상태", "작업진행상황"):
        return _v49_status_text()
    if n in ("작업계속", "장기작업계속", "작업재개", "작업복구"):
        return _v49_resume_job()
    if n in ("작업일시정지", "장기작업일시정지", "작업멈춤"):
        return _v49_pause_job()
    if n in ("작업취소", "장기작업취소"):
        return _v49_cancel_job()
    return None


def run_job_benchmark_v49():
    tests = []
    old = dict(V49_JOB)
    try:
        r = _v49_start_job("플레이어 대시 기능 추가")
        tests.append({"name":"장기작업 생성", "passed":"장기 작업" in r and V49_JOB.get("job_id")})
        s = _v49_status_text()
        tests.append({"name":"작업 상태 조회", "passed":"작업 ID" in s and V49_JOB.get("request") == "플레이어 대시 기능 추가"})
        p = _v49_pause_job()
        tests.append({"name":"작업 일시정지", "passed":V49_JOB.get("status") == "paused" and "일시정지" in p})
    finally:
        V49_JOB.clear(); V49_JOB.update(old)
        _v49_save_job(extra_history=False)
    return tests

# Load the persisted job as the program starts. This does not execute any work.
_v49_load_job()

# Wrap the current think() so job-management commands are handled first.
if not globals().get("_V49_THINK_PATCHED"):
    _V49_PREV_THINK = think
    def think(text):
        r = _v49_handle_command(text)
        if r is not None:
            return r
        return _V49_PREV_THINK(text)
    globals()["_V49_THINK_PATCHED"] = True


# ──────────────────────────────────────────────
# v5.1: 변경 영향 + 테스트 커버리지 게이트
# ──────────────────────────────────────────────
V51_DIR = Path(HERE) / "ai_impact_coverage"
V51_DIR.mkdir(exist_ok=True)
V51_LATEST = V51_DIR / "latest.json"
V51_HISTORY = V51_DIR / "history.jsonl"
V51_VERSION = "5.1"


def _v51_find_impacted_nodes(target):
    root = PROJECT.get('path')
    if not root or not os.path.isdir(root):
        return {"ok": False, "message": "Unity 프로젝트가 연결되지 않았어.", "nodes": [], "seeds": []}
    try:
        r = build_project_graph(True)
        if not r.get('ok'):
            return {"ok": False, "message": r.get('message', '프로젝트 그래프를 만들지 못했어.'), "nodes": [], "seeds": []}
        g = r['graph']
        nodes = {n['id']: n for n in g.get('nodes', [])}
        seeds = _find_graph_seeds(g, target)
        if not seeds:
            return {"ok": True, "message": f"'{target}' 관련 그래프 항목을 찾지 못했어.", "nodes": [], "seeds": []}
        adj = _graph_neighbors(g)
        dist = {n['id']: 0 for n in seeds}
        q = [n['id'] for n in seeds]
        qi = 0
        while qi < len(q):
            cur = q[qi]; qi += 1
            if dist[cur] >= 3:
                continue
            for other, rel, direction in adj.get(cur, []):
                if other not in dist:
                    dist[other] = dist[cur] + 1
                    q.append(other)
        impacted = []
        for nid, d in sorted(dist.items(), key=lambda x: (x[1], _graph_node_label(nodes.get(x[0], {})))):
            n = dict(nodes.get(nid, {}))
            n['distance'] = d
            impacted.append(n)
        return {"ok": True, "message": "", "nodes": impacted, "seeds": [dict(x) for x in seeds]}
    except Exception as e:
        return {"ok": False, "message": f"영향도 분석 실패: {e}", "nodes": [], "seeds": []}


def _v51_required_test_keys(node):
    kind = node.get('kind')
    req = []
    if kind == 'script':
        req += ['compile_static', 'dependency']
        path = node.get('path', '')
        root = PROJECT.get('path') or ''
        full = os.path.abspath(os.path.join(root, path))
        code = _read_small(full) if os.path.isfile(full) else ''
        if 'Update(' in code or 'FixedUpdate(' in code:
            req.append('runtime_logic')
        if any(x in code for x in ('OnCollision', 'OnTrigger', 'Physics.')):
            req.append('physics')
        if 'Animator' in code or 'Animation' in code:
            req.append('animation')
        if 'Input.' in code or 'InputSystem' in code:
            req.append('input')
    elif kind == 'prefab':
        req.append('prefab')
    elif kind == 'scene':
        req.append('scene')
    elif kind == 'gameobject':
        req.append('gameobject')
    return req


def _v51_test_covers_node(test, node):
    kind = node.get('kind')
    action = test.get('action')
    title = str(test.get('title', '')).lower()
    target = str(test.get('target', ''))
    label = str(_graph_node_label(node))
    related = target == label or target.endswith(label) or label.endswith(target) or label in title or target in title
    if not related:
        return False
    if kind == 'script':
        return action in _v51_required_test_keys(node) or action in {'unity_editmode_tests', 'unity_playmode_tests'}
    if kind == 'prefab':
        return action == 'asset'
    if kind == 'scene':
        return action == 'scene'
    if kind == 'gameobject':
        return action == 'object'
    return False


def _v51_generate_or_load_plan(target):
    _load_change_test_plan()
    current_target = CHANGE_TEST_PLAN.get('target') if isinstance(CHANGE_TEST_PLAN, dict) else None
    if not CHANGE_TEST_PLAN.get('tests') or current_target != target:
        res = create_change_test_plan(target)
        if not CHANGE_TEST_PLAN.get('tests'):
            return False, res
    return True, ""


def v51_run_impact_coverage(target=None):
    _load_change_test_plan()
    target = target or CHANGE_TEST_PLAN.get('target')
    if not target:
        return {"version": V51_VERSION, "ok": False, "message": "먼저 '변경테스트계획: 대상'을 실행해줘."}
    ok, msg = _v51_generate_or_load_plan(target)
    if not ok:
        return {"version": V51_VERSION, "ok": False, "message": msg}
    impact = _v51_find_impacted_nodes(target)
    if not impact.get('ok'):
        return {"version": V51_VERSION, "ok": False, "message": impact.get('message')}
    nodes = impact.get('nodes', [])
    tests = CHANGE_TEST_PLAN.get('tests', [])
    required = []
    covered = []
    uncovered = []
    for node in nodes:
        req = _v51_required_test_keys(node)
        # Graph seed itself is the change target; focus on impacted nodes with actual testable behavior.
        if node.get('distance', 0) == 0 and not req:
            req = []
        for key in req:
            item = {"node": _graph_node_label(node), "kind": node.get('kind'), "test_kind": key, "distance": node.get('distance', 0)}
            required.append(item)
            matches = [t for t in tests if t.get('kind') == key and _v51_test_covers_node(t, node)]
            if matches:
                item['covered_by'] = [m.get('title') for m in matches[:3]]
                covered.append(item)
            else:
                uncovered.append(item)
    # Add project-wide Unity tests as supplemental coverage, not as a substitute for static/asset checks.
    has_edit = any(t.get('action') == 'unity_editmode_tests' for t in tests)
    has_play = any(t.get('action') == 'unity_playmode_tests' for t in tests)
    impact_count = len(required)
    coverage = 100.0 if impact_count == 0 else (100.0 * len(covered) / impact_count)
    verdict = 'PASS' if coverage >= 90 and not uncovered else ('REVIEW_REQUIRED' if coverage >= 70 else 'FAIL')
    report = {
        "version": V51_VERSION,
        "timestamp": time.time(),
        "target": target,
        "verdict": verdict,
        "coverage_percent": round(coverage, 2),
        "impacted_nodes": len(nodes),
        "required_checks": len(required),
        "covered_checks": len(covered),
        "uncovered_checks": len(uncovered),
        "unity_editmode_planned": has_edit,
        "unity_playmode_planned": has_play,
        "uncovered": uncovered[:200],
        "covered": covered[:200],
    }
    try:
        V51_LATEST.write_text(json.dumps(report, ensure_ascii=False, indent=2), encoding='utf-8')
        with V51_HISTORY.open('a', encoding='utf-8') as f:
            f.write(json.dumps(report, ensure_ascii=False) + '\n')
    except Exception:
        pass
    return report


def _v51_report_text(report):
    if not report.get('ok', True):
        return f"v5.1 영향 커버리지 실패: {report.get('message', '알 수 없는 오류')}"
    lines = [
        f"v5.1 변경 영향/테스트 커버리지",
        f"대상: {report.get('target')}",
        f"영향 노드: {report.get('impacted_nodes', 0)}개",
        f"필수 검사: {report.get('required_checks', 0)}개",
        f"커버된 검사: {report.get('covered_checks', 0)}개",
        f"미커버 검사: {report.get('uncovered_checks', 0)}개",
        f"커버리지: {report.get('coverage_percent', 0):.2f}%",
        f"판정: {report.get('verdict')}",
    ]
    unc = report.get('uncovered') or []
    if unc:
        lines.append('')
        lines.append('[테스트가 부족한 영향 영역]')
        for x in unc[:12]:
            lines.append(f"- {x['node']} / {x['test_kind']} (거리 {x['distance']})")
    if report.get('unity_editmode_planned') or report.get('unity_playmode_planned'):
        lines.append('')
        lines.append(f"Unity EditMode: {'계획됨' if report.get('unity_editmode_planned') else '없음'}")
        lines.append(f"Unity PlayMode: {'계획됨' if report.get('unity_playmode_planned') else '없음'}")
    return '\n'.join(lines)


def _v51_coverage_commands(text):
    raw = str(text or '').strip()
    n = normalize(raw)
    if n in ('영향커버리지', '변경영향커버리지', '테스트커버리지', '영향테스트커버리지'):
        r = v51_run_impact_coverage()
        return _v51_report_text(r)
    if n.startswith('영향커버리지:') or n.startswith('테스트커버리지:'):
        target = raw.split(':', 1)[1].strip()
        r = v51_run_impact_coverage(target)
        return _v51_report_text(r)
    if n in ('영향커버리지상태', '테스트커버리지상태'):
        try:
            if V51_LATEST.exists():
                return V51_LATEST.read_text(encoding='utf-8')
        except Exception:
            pass
        return '저장된 v5.1 커버리지 결과가 없어.'
    return None


def run_benchmark_v51_impact_coverage():
    global CHANGE_TEST_PLAN, PROJECT, V33_TEST_PLAN_FILE
    results = []
    old_plan = dict(CHANGE_TEST_PLAN)
    old_project = dict(PROJECT)
    old_plan_file = V33_TEST_PLAN_FILE
    import tempfile
    temp_root = tempfile.mkdtemp(prefix='myai_v51_bench_')
    try:
        original_build = globals().get('build_project_graph')
        original_find = globals().get('_find_graph_seeds')
        original_neighbors = globals().get('_graph_neighbors')
        def fake_build(_force=False):
            return {"ok": True, "graph": {"nodes": [
                {"id": "script:PlayerController.cs", "kind": "script", "path": "PlayerController.cs"},
                {"id": "prefab:Player.prefab", "kind": "prefab", "path": "Player.prefab"},
            ]}}
        def fake_seeds(g, target):
            return [n for n in g['nodes'] if 'PlayerController' in n.get('path','')]
        def fake_adj(g):
            return {"script:PlayerController.cs": [("prefab:Player.prefab", "uses", "out")], "prefab:Player.prefab": [("script:PlayerController.cs", "uses", "in")]}
        globals()['build_project_graph'] = fake_build
        globals()['_find_graph_seeds'] = fake_seeds
        globals()['_graph_neighbors'] = fake_adj
        PROJECT.clear(); PROJECT.update({"path": temp_root})
        V33_TEST_PLAN_FILE = str(Path(temp_root) / 'test_plan.json')
        CHANGE_TEST_PLAN = {"version": "3.3", "target": "PlayerController.cs", "tests": [
            {"title": "C# 정적 검사: PlayerController.cs", "kind": "compile_static", "target": "PlayerController.cs", "action": "analyze_csharp"},
            {"title": "스크립트 관계 확인: PlayerController.cs", "kind": "dependency", "target": "PlayerController.cs", "action": "graph_related"},
            {"title": "Prefab 존재/참조 확인: Player.prefab", "kind": "prefab", "target": "Player.prefab", "action": "asset"},
        ]}
        _save_change_test_plan()
        r = v51_run_impact_coverage('PlayerController.cs')
        results.append({"name": "영향 그래프 탐색", "passed": r.get('impacted_nodes', 0) == 2})
        results.append({"name": "커버리지 계산", "passed": 0 <= float(r.get('coverage_percent', -1)) <= 100})
        results.append({"name": "미커버 영역 탐지", "passed": isinstance(r.get('uncovered'), list) and r.get('uncovered_checks', 0) >= 0})
    except Exception as e:
        results.append({"name": "v5.1 benchmark exception", "passed": False, "error": str(e)})
    finally:
        if 'original_build' in locals(): globals()['build_project_graph'] = original_build
        if 'original_find' in locals(): globals()['_find_graph_seeds'] = original_find
        if 'original_neighbors' in locals(): globals()['_graph_neighbors'] = original_neighbors
        CHANGE_TEST_PLAN.clear(); CHANGE_TEST_PLAN.update(old_plan)
        PROJECT.clear(); PROJECT.update(old_project)
        V33_TEST_PLAN_FILE = old_plan_file
    return results

# Integrate v5.1 into final review: coverage < 90 forces a review gate.
if not globals().get('_V51_REVIEW_WRAPPED'):
    _V51_PREV_FINAL_REVIEW = _v50_final_review
    def _v50_final_review():
        report_text = _V51_PREV_FINAL_REVIEW()
        try:
            job = dict(V49_JOB) if isinstance(V49_JOB, dict) else {}
            target = None
            ct = _load_change_test_plan() if '_load_change_test_plan' in globals() else None
            if isinstance(CHANGE_TEST_PLAN, dict):
                target = CHANGE_TEST_PLAN.get('target')
            if target:
                cov = v51_run_impact_coverage(target)
                # Load the v5.0 review we just wrote and amend it.
                if V50_REVIEW_LATEST.exists():
                    base = json.loads(V50_REVIEW_LATEST.read_text(encoding='utf-8'))
                    base.setdefault('checks', []).append({
                        'name': '변경 영향/테스트 커버리지',
                        'passed': cov.get('verdict') == 'PASS',
                        'score': cov.get('coverage_percent', 0),
                    })
                    if cov.get('verdict') != 'PASS':
                        base.setdefault('findings', []).append(
                            f"변경 영향 테스트 커버리지 {cov.get('coverage_percent', 0):.1f}% — 추가 회귀 테스트 필요"
                        )
                        base['verdict'] = 'REVIEW_REQUIRED'
                    base['version'] = '5.1'
                    _v50_write_review(base)
                    if V49_JOB.get('job_id'):
                        V49_JOB['last_review'] = base
                        _v49_save_job(extra_history=False)
                    report_text = _v51_report_text(cov) + '\n\n' + report_text
        except Exception as e:
            report_text += f"\n\n[v5.1] 영향 커버리지 검토를 실행하지 못함: {e}"
        return report_text
    globals()['_V51_REVIEW_WRAPPED'] = True

# Route v5.1 commands through the main think() path used by this .pyw.
if not globals().get('_V51_ROUTER_PATCHED'):
    _V51_PREV_THINK = think
    def think(text):
        r = _v51_coverage_commands(text)
        if r is not None:
            return r
        return _V51_PREV_THINK(text)
    globals()['_V51_ROUTER_PATCHED'] = True



# ==================== v5.2 PERFORMANCE PROFILE ====================
_original_handle_message_v52 = globals().get("handle_user_message")
def _handle_perf_profile_v52(user_text):
    t=(user_text or "").strip()
    if t in {"성능상태", "프로필상태", "속도설정"}:
        return "PERFORMANCE_PROFILE_JSON\n"+json.dumps(performance_profile_status(), ensure_ascii=False, indent=2)
    return None
if _original_handle_message_v52 and not globals().get("_V52_PROFILE_ROUTER_PATCHED"):
    def handle_user_message(user_text, *args, **kwargs):
        r=_handle_perf_profile_v52(user_text)
        if r is not None: return r
        return _original_handle_message_v52(user_text, *args, **kwargs)
    globals()["_V52_PROFILE_ROUTER_PATCHED"] = True

# ==================== v5.5 UNITY GUI AUTOMATION ====================
V55_VERSION = "5.5-unity-gui"
V55_DIR = Path(HERE) / "ai_gui_audit"
V55_DIR.mkdir(parents=True, exist_ok=True)
V55_LATEST = V55_DIR / "latest.json"
V55_HISTORY = V55_DIR / "history.jsonl"
V55_PLAN = {"status":"idle","target":"Unity Editor","actions":[],"created_at":None,"result":None}

try:
    import pyautogui as _pyautogui
except Exception:
    _pyautogui = None


def v55_gui_available():
    return _pyautogui is not None


def v55_unity_windows():
    if _pyautogui is None:
        return []
    try:
        wins = _pyautogui.getWindowsWithTitle("Unity")
        return [w for w in wins if getattr(w, "title", "").strip()]
    except Exception:
        return []


def v55_activate_unity():
    wins = v55_unity_windows()
    if not wins:
        return {"ok": False, "message": "Unity Editor 창을 찾지 못했어."}
    try:
        w = wins[0]
        if hasattr(w, "activate"):
            w.activate()
        time.sleep(0.35)
        return {"ok": True, "title": getattr(w, "title", "Unity")}
    except Exception as e:
        return {"ok": False, "message": f"Unity 창 활성화 실패: {e}"}


def v55_screenshot(label="screen"):
    if _pyautogui is None:
        return None
    try:
        ts = time.strftime("%Y%m%d_%H%M%S")
        path = V55_DIR / f"{ts}_{label}.png"
        img = _pyautogui.screenshot()
        img.save(path)
        return str(path)
    except Exception:
        return None


def v55_parse_plan(text):
    raw = str(text or "").strip()
    if not raw.startswith("GUI계획:"):
        return None
    spec = raw.split(":", 1)[1].strip()
    actions = []
    for part in [p.strip() for p in spec.split(";") if p.strip()]:
        if part.startswith("click(") and part.endswith(")"):
            vals = [x.strip() for x in part[6:-1].split(",")]
            if len(vals) == 2:
                actions.append({"type":"click","x":int(float(vals[0])),"y":int(float(vals[1]))})
        elif part.startswith("doubleclick(") and part.endswith(")"):
            vals = [x.strip() for x in part[12:-1].split(",")]
            if len(vals) == 2:
                actions.append({"type":"doubleclick","x":int(float(vals[0])),"y":int(float(vals[1]))})
        elif part.startswith("rightclick(") and part.endswith(")"):
            vals = [x.strip() for x in part[11:-1].split(",")]
            if len(vals) == 2:
                actions.append({"type":"rightclick","x":int(float(vals[0])),"y":int(float(vals[1]))})
        elif part.startswith("move(") and part.endswith(")"):
            vals = [x.strip() for x in part[5:-1].split(",")]
            if len(vals) == 2:
                actions.append({"type":"move","x":int(float(vals[0])),"y":int(float(vals[1]))})
        elif part.startswith("scroll(") and part.endswith(")"):
            actions.append({"type":"scroll","amount":int(float(part[7:-1].strip()))})
        elif part.startswith("type(") and part.endswith(")"):
            payload = part[5:-1].strip()
            if len(payload) >= 2 and payload[0] in ('"', "'") and payload[-1] == payload[0]:
                payload = payload[1:-1]
            actions.append({"type":"type","text":payload})
        elif part.startswith("key(") and part.endswith(")"):
            payload = part[4:-1].strip().strip('"\'')
            actions.append({"type":"key","key":payload})
        elif part.startswith("hotkey(") and part.endswith(")"):
            payload = part[7:-1].strip()
            keys = [x.strip().strip('"\'') for x in payload.split(",") if x.strip()]
            actions.append({"type":"hotkey","keys":keys})
        elif part.startswith("wait(") and part.endswith(")"):
            actions.append({"type":"wait","seconds":max(0.0,min(float(part[5:-1].strip()),10.0))})
        elif part.startswith("verify_object(") and part.endswith(")"):
            payload = part[len("verify_object("):-1].strip().strip('"\'')
            if payload:
                actions.append({"type":"verify_object","gameObjectName":payload})
        elif part.startswith("verify_component(") and part.endswith(")"):
            vals = [x.strip().strip('"\'') for x in part[len("verify_component("):-1].split(",", 1)]
            if len(vals) == 2 and vals[0] and vals[1]:
                actions.append({"type":"verify_component","gameObjectName":vals[0],"componentType":vals[1]})
        elif part in ("verify_scene()", "verify_scene"):
            actions.append({"type":"verify_scene"})
        else:
            return {"ok":False,"message":f"알 수 없는 GUI 액션: {part}"}
    if not actions:
        return {"ok":False,"message":"GUI 계획에 액션이 없어."}
    if len(actions) > 40:
        return {"ok":False,"message":"한 계획에서 최대 40개 액션만 허용해."}
    has_verification = any(a["type"].startswith("verify_") for a in actions)
    return {"ok":True,"actions":actions,"has_verification":has_verification}


def _v55_unity_scene_snapshot():
    if not unity_project_ok():
        return {"ok":False,"message":"유효한 Unity 프로젝트가 아니야."}
    try:
        r = _run_unity_batch_and_read({"action":"scan_scene"}, timeout=120)
        if not r.get("ok"):
            return {"ok":False,"message":r.get("message", "Scene 스캔 실패")}
        return {"ok":True,"data":r.get("bridge_message", "")}
    except Exception as e:
        return {"ok":False,"message":str(e)}


def _v55_verify_actions(actions):
    checks=[]
    all_ok=True
    for a in actions:
        typ=a.get("type")
        if typ == "verify_scene":
            r=_v55_unity_scene_snapshot()
            item={"type":typ,"ok":bool(r.get("ok")),"message":r.get("message"),"snapshot":r.get("data")}
        elif typ == "verify_object":
            r=unity_find_object(a.get("gameObjectName", ""))
            ok="NOT_FOUND" not in str(r)
            item={"type":typ,"target":a.get("gameObjectName"),"ok":ok,"message":r}
        elif typ == "verify_component":
            obj=a.get("gameObjectName", "")
            comp=a.get("componentType", "")
            r=unity_find_object(obj)
            text=str(r)
            ok=("NOT_FOUND" not in text) and (comp.lower() in text.lower())
            item={"type":typ,"target":obj,"component":comp,"ok":ok,"message":r}
        else:
            continue
        checks.append(item)
        all_ok = all_ok and bool(item.get("ok"))
    return {"all_ok": all_ok if checks else False, "checks": checks, "performed": bool(checks)}

def v55_save_plan(plan):
    V55_PLAN.update(plan)
    try:
        V55_LATEST.write_text(json.dumps(V55_PLAN, ensure_ascii=False, indent=2), encoding="utf-8")
    except Exception:
        pass


def v55_execute_plan():
    if _pyautogui is None:
        return "pyautogui가 없어. Windows에서 `pip install pyautogui` 후 다시 실행해줘."
    if V55_PLAN.get("status") != "awaiting_approval":
        return "실행할 GUI 계획이 없어. 먼저 `GUI계획: ...`을 입력해줘."
    if not V55_PLAN.get("has_verification", False):
        return "안전 검증 없는 GUI 계획은 실행하지 않아. `verify_scene()`, `verify_object(이름)` 또는 `verify_component(이름,컴포넌트)`를 계획에 추가해줘."
    act = v55_activate_unity()
    if not act.get("ok"):
        return act.get("message", "Unity 창을 찾지 못했어.")
    before = v55_screenshot("before")
    scene_before = _v55_unity_scene_snapshot()
    results = []
    verifiers = []
    try:
        screen_w, screen_h = _pyautogui.size()
        for idx, a in enumerate(V55_PLAN.get("actions", []), 1):
            typ = a["type"]
            if typ.startswith("verify_"):
                results.append({"index":idx,"action":a,"ok":True,"phase":"deferred_verification"})
                verifiers.append(a)
                continue
            if typ in {"click","doubleclick","rightclick","move"}:
                x, y = int(a["x"]), int(a["y"])
                if not (0 <= x < screen_w and 0 <= y < screen_h):
                    raise ValueError(f"화면 밖 좌표: {x},{y} / {screen_w}x{screen_h}")
                if typ == "click": _pyautogui.click(x,y)
                elif typ == "doubleclick": _pyautogui.doubleClick(x,y, interval=0.12)
                elif typ == "rightclick": _pyautogui.rightClick(x,y)
                else: _pyautogui.moveTo(x,y,duration=0.15)
            elif typ == "scroll": _pyautogui.scroll(int(a["amount"]))
            elif typ == "type": _pyautogui.write(str(a["text"]), interval=0.01)
            elif typ == "key": _pyautogui.press(str(a["key"]))
            elif typ == "hotkey": _pyautogui.hotkey(*[str(k) for k in a["keys"]])
            elif typ == "wait": time.sleep(float(a["seconds"]))
            results.append({"index":idx,"action":a,"ok":True})
        time.sleep(0.25)
        after = v55_screenshot("after")
        scene_after = _v55_unity_scene_snapshot()
        verification = _v55_verify_actions(verifiers)
        report = {
            "version": V55_VERSION,
            "timestamp": time.time(),
            "status": "completed" if verification.get("all_ok") else "verification_failed",
            "unity_window": act.get("title"),
            "before_screenshot": before,
            "after_screenshot": after,
            "scene_before_ok": scene_before.get("ok", False),
            "scene_after_ok": scene_after.get("ok", False),
            "scene_changed": bool(scene_before.get("ok") and scene_after.get("ok") and scene_before.get("data") != scene_after.get("data")),
            "results": results,
            "verification": verification,
            "note": "GUI 조작 성공 여부와 Unity 상태 검증을 분리해 기록함. 명시적 검증이 통과한 경우에만 성공으로 판정함."
        }
        V55_PLAN.update({"status":report["status"],"result":report})
    except Exception as e:
        after = v55_screenshot("error")
        report = {"version":V55_VERSION,"timestamp":time.time(),"status":"failed","unity_window":act.get("title"),"before_screenshot":before,"error":str(e),"after_screenshot":after,"results":results}
        V55_PLAN.update({"status":"failed","result":report})
    try:
        V55_LATEST.write_text(json.dumps(V55_PLAN, ensure_ascii=False, indent=2), encoding="utf-8")
        with V55_HISTORY.open("a", encoding="utf-8") as f: f.write(json.dumps(V55_PLAN, ensure_ascii=False)+"\n")
    except Exception:
        pass
    return json.dumps(V55_PLAN.get("result",{}), ensure_ascii=False, indent=2)

def _v55_gui_commands(text):
    raw = str(text or "").strip()
    n = normalize(raw)
    if n in ("gui상태","유니티gui상태","gui자동화상태"):
        return json.dumps({"version":V55_VERSION,"available":v55_gui_available(),"unity_windows":len(v55_unity_windows()),"plan_status":V55_PLAN.get("status"),"plan_actions":len(V55_PLAN.get("actions",[]))}, ensure_ascii=False, indent=2)
    if n in ("gui스크린샷","유니티스크린샷"):
        p=v55_screenshot("manual")
        return p or "스크린샷 저장 실패"
    parsed=v55_parse_plan(raw)
    if parsed is not None:
        if not parsed.get("ok"): return parsed.get("message","GUI 계획 오류")
        V55_PLAN.update({"status":"awaiting_approval","created_at":time.time(),"actions":parsed["actions"],"has_verification":parsed.get("has_verification",False),"result":None})
        v55_save_plan(V55_PLAN)
        return "GUI 계획을 만들었어. 실제 Unity 화면을 조작하려면 `GUI조작 승인`을 입력해줘."
    if n in ("gui조작승인","유니티gui조작승인"):
        return v55_execute_plan()
    if n in ("gui계획취소","gui취소"):
        V55_PLAN.update({"status":"cancelled","actions":[]})
        v55_save_plan(V55_PLAN)
        return "GUI 계획을 취소했어."
    return None

if not globals().get("_V55_ROUTER_PATCHED"):
    _V55_PREV_THINK = think
    def think(text):
        r = _v55_gui_commands(text)
        if r is not None:
            return r
        return _V55_PREV_THINK(text)
    globals()["_V55_ROUTER_PATCHED"] = True



# ========================= v5.6 GUI 실제 검증 벤치마크 =========================
V56_DIR = Path(HERE) / "ai_gui_benchmark"
V56_DIR.mkdir(parents=True, exist_ok=True)
V56_LATEST = V56_DIR / "latest.json"
V56_HISTORY = V56_DIR / "history.jsonl"
V56_CASES = Path(HERE) / "ai_gui_benchmark_cases.v5.6.json"

V56_DEFAULT_CASES = [
    {"id":"parse_verify_required","kind":"unit","description":"GUI 계획 파싱과 검증 액션 요구","plan":"GUI계획: click(1,1); verify_scene()","expected":"parse_ok_and_has_verification"},
    {"id":"reject_without_verification","kind":"unit","description":"검증 없는 계획은 실행 대기만 허용","plan":"GUI계획: click(1,1)","expected":"awaiting_approval_not_executed"},
    {"id":"reject_unknown_action","kind":"unit","description":"알 수 없는 GUI 액션 거부","plan":"GUI계획: magic(1,1); verify_scene()","expected":"parse_reject"},
    {"id":"dryrun_action_count","kind":"unit","description":"여러 액션 파싱","plan":"GUI계획: click(10,20); move(30,40); wait(0.1); verify_scene()","expected":"action_count_4"},
    {"id":"real_scene_probe","kind":"integration","description":"실제 Unity Scene 검증 가능 여부","plan":"GUI계획: verify_scene()","expected":"real_scene_verification"},
    {"id":"real_object_probe","kind":"integration","description":"실제 Unity 오브젝트 검증 가능 여부","plan":"GUI계획: verify_object(Player)","expected":"real_object_verification"},
    {"id":"real_component_probe","kind":"integration","description":"실제 Unity 컴포넌트 검증 가능 여부","plan":"GUI계획: verify_component(Player,Rigidbody)","expected":"real_component_verification"},
]


def _v56_load_cases():
    if not V56_CASES.exists():
        try:
            V56_CASES.write_text(json.dumps(V56_DEFAULT_CASES, ensure_ascii=False, indent=2), encoding='utf-8')
        except Exception:
            pass
        return list(V56_DEFAULT_CASES)
    try:
        data=json.loads(V56_CASES.read_text(encoding='utf-8'))
        return data if isinstance(data,list) else list(V56_DEFAULT_CASES)
    except Exception:
        return list(V56_DEFAULT_CASES)


def _v56_save_result(result):
    try:
        V56_LATEST.write_text(json.dumps(result, ensure_ascii=False, indent=2), encoding='utf-8')
        with V56_HISTORY.open('a', encoding='utf-8') as f:
            f.write(json.dumps(result, ensure_ascii=False) + '\n')
    except Exception:
        pass


def _v56_run_unit_case(case):
    plan=case.get('plan','')
    parsed=v55_parse_plan(plan)
    if case.get('expected')=='parse_ok_and_has_verification':
        ok=bool(parsed and parsed.get('ok') and parsed.get('has_verification'))
    elif case.get('expected')=='awaiting_approval_not_executed':
        # 실제 실행은 하지 않고, 파싱 결과만 확인한다. 승인 전 상태가 안전 경계다.
        ok=bool(parsed and parsed.get('ok') and not parsed.get('has_verification')) is False
        # 이 케이스는 '검증 없는 계획'이 실행 차단되어야 한다는 정책을 직접 확인한다.
        ok=bool(parsed and parsed.get('ok') and parsed.get('has_verification') is False)
    elif case.get('expected')=='parse_reject':
        ok=bool(parsed and not parsed.get('ok'))
    elif case.get('expected')=='action_count_4':
        ok=bool(parsed and parsed.get('ok') and len(parsed.get('actions',[]))==4)
    else:
        ok=False
    return {"status":"PASS" if ok else "FAIL", "observed": parsed}


def _v56_run_integration_case(case):
    # 실제 Unity가 연결되어 있지 않으면 SKIP. SKIP은 성공으로 계산하지 않는다.
    if not unity_project_ok():
        return {"status":"SKIP", "reason":"Unity project not configured"}
    plan=case.get('plan','')
    parsed=v55_parse_plan(plan)
    if not parsed or not parsed.get('ok'):
        return {"status":"FAIL", "reason":"plan_parse_failed", "observed":parsed}
    checks=[a for a in parsed.get('actions',[]) if a.get('type','').startswith('verify_')]
    if not checks:
        return {"status":"FAIL", "reason":"no_verification_action"}
    # 실행하지 않고 실제 verifier를 호출한다. GUI 입력 없는 순수 관측형 테스트.
    vr=v55_verify_actions(checks)
    return {"status":"PASS" if vr.get('ok') else "FAIL", "observed":vr}


def v56_run_gui_benchmark(real=True):
    cases=_v56_load_cases()
    started=time.time()
    results=[]
    for case in cases:
        try:
            if case.get('kind')=='unit':
                r=_v56_run_unit_case(case)
            elif real:
                r=_v56_run_integration_case(case)
            else:
                r={"status":"SKIP","reason":"real execution disabled"}
        except Exception as e:
            r={"status":"ERROR","error":str(e)}
        results.append({"id":case.get('id'),"kind":case.get('kind'),"description":case.get('description'),**r})
    tested=[r for r in results if r['status'] in ('PASS','FAIL')]
    passed=sum(r['status']=='PASS' for r in tested)
    failed=sum(r['status']=='FAIL' for r in tested)
    skipped=sum(r['status']=='SKIP' for r in results)
    score=round((passed/len(tested))*100,2) if tested else 0.0
    integration=[r for r in results if r['kind']=='integration' and r['status'] in ('PASS','FAIL')]
    int_pass=sum(r['status']=='PASS' for r in integration)
    int_score=round((int_pass/len(integration))*100,2) if integration else None
    result={
        "version":"v5.6",
        "benchmark":"unity_gui_verification",
        "timestamp":time.strftime('%Y-%m-%dT%H:%M:%SZ', time.gmtime()),
        "duration_sec":round(time.time()-started,3),
        "total_cases":len(results),
        "tested_cases":len(tested),
        "passed":passed,
        "failed":failed,
        "skipped":skipped,
        "score":score,
        "integration_score":int_score,
        "results":results,
    }
    _v56_save_result(result)
    return result


def _v56_benchmark_command(text):
    raw=str(text or '').strip().lower()
    if raw in ('gui벤치마크','유니티gui벤치마크','gui검증벤치마크'):
        r=v56_run_gui_benchmark(real=True)
        return f"v5.6 GUI 벤치마크: {r['score']:.2f}/100 | PASS {r['passed']} | FAIL {r['failed']} | SKIP {r['skipped']} | Integration={r['integration_score']}"
    if raw in ('gui벤치마크상태','gui검증상태'):
        if V56_LATEST.exists():
            try:
                r=json.loads(V56_LATEST.read_text(encoding='utf-8'))
                return f"최근 v5.6 GUI 벤치마크: {r.get('score')} / 100, PASS={r.get('passed')}, FAIL={r.get('failed')}, SKIP={r.get('skipped')}, Integration={r.get('integration_score')}"
            except Exception as e:
                return f"벤치마크 상태 읽기 실패: {e}"
        return "아직 v5.6 GUI 벤치마크 결과가 없어. `GUI벤치마크`를 실행해줘."
    if raw in ('gui벤치마크재설정','gui벤치마크초기화'):
        try:
            if V56_LATEST.exists(): V56_LATEST.unlink()
        except Exception: pass
        return "v5.6 GUI 벤치마크 최신 결과를 초기화했어."
    return None

if not globals().get('_V56_GUI_BENCH_PATCHED'):
    _V56_PREV_THINK = think
    def think(text):
        r=_v56_benchmark_command(text)
        if r is not None:
            return r
        return _V56_PREV_THINK(text)
    globals()['_V56_GUI_BENCH_PATCHED']=True


# ==================== v6.1 DEEP INTEGRATION PATCH ====================
V61_VERSION = "6.1"
V61_STATE_DIR = Path(HERE) / "ai_workspace"
V61_STATE_DIR.mkdir(parents=True, exist_ok=True)
V61_ACTIVITY = V61_STATE_DIR / "activity.jsonl"


def _v61_log(kind, payload):
    try:
        with V61_ACTIVITY.open("a", encoding="utf-8") as f:
            f.write(json.dumps({"ts": time.time(), "kind": kind, "payload": payload}, ensure_ascii=False) + "\n")
    except Exception:
        pass


def _v61_note_search(query):
    q = normalize(query)
    notes = v6_load_notes()
    scored = []
    for n in notes:
        blob = f"{n.get('title','')} {n.get('content','')} {' '.join(n.get('tags',[]))}"
        s = score(q, blob)
        if s > 0:
            scored.append((s, n))
    scored.sort(key=lambda x: x[0], reverse=True)
    if not scored:
        return "일치하는 노트가 없어."
    return json.dumps([{**n, "match": round(s, 4)} for s,n in scored[:8]], ensure_ascii=False, indent=2)


def _v61_knowledge_search(query):
    hits = vector_search(query, top_n=max(8, int(VECTOR_TOP_N if 'VECTOR_TOP_N' in globals() else 8)))
    if not hits:
        # Fallback to lexical index if vector index isn't ready.
        hits = search_index(query, top_n=8) if 'search_index' in globals() else []
    out=[]
    for h in hits[:8]:
        if isinstance(h, dict):
            out.append(h)
        else:
            try:
                fname, sent, *rest = h
                out.append({"file":fname,"text":sent})
            except Exception:
                out.append({"text":str(h)})
    return json.dumps(out, ensure_ascii=False, indent=2)


def _v61_job_to_note():
    try:
        status = _v49_status_text()
        jid = V49_JOB.get("job_id") or "job"
        note = v6_add_note(f"개발 작업 {jid}", status, ["job", "development"])
        _v61_log("job_to_note", {"job_id": jid, "note_id": note.get("id")})
        return f"작업 상태를 노트에 저장했어: {note.get('title')}"
    except Exception as e:
        return f"작업을 노트로 저장하지 못했어: {e}"


def _v61_workspace_summary():
    s = v6_workspace_status()
    try:
        s["collector"] = collector_status()
    except Exception: pass
    try:
        s["job"] = json.loads(V49_JOB_FILE.read_text(encoding="utf-8")) if V49_JOB_FILE.exists() else {}
    except Exception: s["job"] = {}
    try:
        s["ci"] = json.loads((Path(HERE)/"ai_ci_audit"/"latest.json").read_text(encoding="utf-8")) if (Path(HERE)/"ai_ci_audit"/"latest.json").exists() else {}
    except Exception: s["ci"] = {}
    try:
        s["review"] = json.loads((Path(HERE)/"ai_review"/"latest.json").read_text(encoding="utf-8")) if (Path(HERE)/"ai_review"/"latest.json").exists() else {}
    except Exception: s["review"] = {}
    try:
        s["git"] = git_status()
    except Exception: s["git"] = ""
    s["mode"] = AI_MODE_LABELS.get(AI_MODE, {}).get("name", AI_MODE)
    s["version"] = V61_VERSION
    return s


def _v61_command(text):
    raw = str(text or '').strip()
    n = normalize(raw)
    if n in ("통합상태", "워크스페이스상태", "전체상태"):
        r = _v61_workspace_summary(); _v61_log("workspace_status", {"version":V61_VERSION}); return json.dumps(r, ensure_ascii=False, indent=2, default=str)
    if n.startswith("지식검색") or n.startswith("지식 검색"):
        q = raw.split(":",1)[1].strip() if ":" in raw else raw.replace("지식검색", "", 1).strip()
        if not q: return "지식 검색어를 입력해줘. 예: 지식검색: Rigidbody"
        _v61_log("knowledge_search", {"query":q}); return _v61_knowledge_search(q)
    if n.startswith("노트검색") or n.startswith("노트 검색"):
        q = raw.split(":",1)[1].strip() if ":" in raw else raw.replace("노트검색", "", 1).strip()
        if not q: return "노트 검색어를 입력해줘."
        _v61_log("note_search", {"query":q}); return _v61_note_search(q)
    if n in ("작업을노트로저장", "현재작업노트저장", "개발작업노트저장"):
        return _v61_job_to_note()
    if n.startswith("노트로개발") or n.startswith("노트로 개발"):
        q = raw.split(":",1)[1].strip() if ":" in raw else raw.replace("노트로개발", "", 1).strip()
        if not q: return "노트 제목이나 검색어를 입력해줘. 예: 노트로개발: 대시"
        notes = v6_load_notes(); candidates=[]
        for note in notes:
            blob=f"{note.get('title','')} {note.get('content','')}"
            candidates.append((score(q, blob), note))
        candidates.sort(key=lambda x:x[0], reverse=True)
        if not candidates or candidates[0][0] <= 0:
            return "그 검색어와 맞는 노트를 찾지 못했어."
        note=candidates[0][1]
        req=f"{note.get('title','')}: {note.get('content','')}"
        _v61_log("note_to_development", {"note_id":note.get("id")})
        return _v48_start(req)
    if n in ("통합파이프라인상태", "자동파이프라인상태"):
        try: return json.dumps(collector_status(), ensure_ascii=False, indent=2, default=str)
        except Exception as e: return f"파이프라인 상태 오류: {e}"
    return None

# Add workspace commands as the outermost chat layer so all existing features remain available.
if not globals().get("_V61_THINK_PATCHED"):
    _V61_PREV_THINK = think
    def think(text):
        r = _v61_command(text)
        if r is not None:
            return r
        return _V61_PREV_THINK(text)
    globals()["_V61_THINK_PATCHED"] = True

# Replace workspace status endpoint with the deeper unified summary and add lightweight APIs.
if not globals().get("_V61_HANDLER_PATCHED"):
    _V61_ORIG_DO_GET = Handler.do_GET
    _V61_ORIG_DO_POST = Handler.do_POST
    def _v61_do_get(self):
        path = self.path.split('?',1)[0]
        if path == "/workspace-status":
            if not _auth_ok(self):
                self._send(401, json.dumps({"error":"unauthorized"}, ensure_ascii=False), "application/json"); return
            self._send(200, json.dumps(_v61_workspace_summary(), ensure_ascii=False, default=str), "application/json"); return
        if path == "/diagnostics":
            if not _auth_ok(self):
                self._send(401, json.dumps({"error":"unauthorized"}, ensure_ascii=False), "application/json"); return
            self._send(200, json.dumps(_diagnostics(), ensure_ascii=False, default=str), "application/json"); return
        if path == "/knowledge-search":
            if not _auth_ok(self):
                self._send(401, "unauthorized", "text/plain"); return
            q=urllib.parse.parse_qs(urllib.parse.urlsplit(self.path).query).get("q", [""])[0]
            self._send(200, _v61_knowledge_search(q), "application/json"); return
        if path == "/notes-search":
            if not _auth_ok(self):
                self._send(401, "unauthorized", "text/plain"); return
            q=urllib.parse.parse_qs(urllib.parse.urlsplit(self.path).query).get("q", [""])[0]
            self._send(200, _v61_note_search(q), "application/json"); return
        return _V61_ORIG_DO_GET(self)
    def _v61_do_post(self):
        if self.path.split('?',1)[0] == "/workspace-command":
            if not _auth_ok(self):
                self._send(401, json.dumps({"error":"unauthorized"}, ensure_ascii=False), "application/json"); return
            try:
                length=int(self.headers.get('Content-Length',0)); body=json.loads(self.rfile.read(length).decode('utf-8')) if length else {}
                result=think(str(body.get('command','')))
                self._send(200, json.dumps({"ok":True,"reply":result}, ensure_ascii=False, default=str), "application/json")
            except Exception as e:
                self._send(500, json.dumps({"ok":False,"error":str(e)}, ensure_ascii=False), "application/json")
            return
        return _V61_ORIG_DO_POST(self)
    Handler.do_GET = _v61_do_get
    Handler.do_POST = _v61_do_post
    globals()["_V61_HANDLER_PATCHED"] = True

# Final build/version marker
APP_BUILD_VERSION = "6.6-diagnostics"
LOCAL_ANSWER_VERSION = "6.1"
